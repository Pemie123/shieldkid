// Cosmetic filtering: hides leftover ad containers once the network requests are blocked.
// SK_SELECTORS comes from cosmetic-list.js (loaded just before this file).
(async () => {
  try {
    const { settings, paused = [] } = await chrome.storage.local.get(['settings', 'paused']);
    if (settings && settings.ads === false) return;
    const host = location.hostname;
    if (paused.some(p => host === p || host.endsWith('.' + p))) return;

    const EXTRA = [
      'ins.adsbygoogle', '[id^="google_ads_"]', '[id^="div-gpt-ad"]', 'iframe[id^="aswift_"]',
      '[data-ad-slot]', '[data-google-query-id]', 'iframe[src*="doubleclick.net"]',
      'iframe[src*="googlesyndication.com"]', 'a[href*="doubleclick.net/"]',
      '[aria-label="Advertisement"]', '[id^="taboola-"]', '[id^="outbrain_widget"]'
    ];
    const all = EXTRA.concat(SK_SELECTORS);
    const parent = document.head || document.documentElement;
    for (let i = 0; i < all.length; i += 400) {      // chunks keep each style rule small and fast
      const style = document.createElement('style');
      style.textContent = all.slice(i, i + 400).join(',') + '{display:none!important}';
      parent.appendChild(style);
    }
  } catch (e) { /* storage unavailable in some frames */ }
})();
