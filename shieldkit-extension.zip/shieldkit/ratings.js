// Shows ONE combined rating for the site you opened (built from Trustpilot, Sitejabber, Reviews.io and Google),
// with the individual ratings underneath. Nothing in the badge is a link. The same ratings are put at the start of
// the tab title, e.g. "★4.3 Great · Trustpilot 4.3 · Sitejabber 4.0 │ Page title", which is what Chrome shows on the
// tab and in the hover card when your cursor rests on it. The lookups happen in the background script; this file
// only draws the result.
(async () => {
  if (window.__shieldkitRatingsStop) { try { window.__shieldkitRatingsStop(); } catch (e) { /* old copy is gone */ } }
  if (window.top !== window || !/^https?:$/.test(location.protocol)) return;
  if (document.contentType && !/html/i.test(document.contentType)) return;

  let settings, hidden = [];
  try { ({ settings, ratingsHidden: hidden = [] } = await chrome.storage.local.get(['settings', 'ratingsHidden'])); } catch (e) { return; }
  if (settings && settings.ratings === false) return;
  if (hidden.includes(location.hostname)) return;

  let data;
  try { data = await chrome.runtime.sendMessage({ type: 'ratings' }); } catch (e) { return; }
  if (!data || data.status !== 'ok') return;

  let stopTitle = () => {};
  if (data.title && !(settings && settings.ratingsTitle === false)) stopTitle = keepRatingInTitle(data.title);
  show(data);
  window.__shieldkitRatingsStop = () => { stopTitle(); const h = document.getElementById('shieldkit-ratings'); if (h) h.remove(); };

  // ---------------------------------------------------------------- tab title
  function keepRatingInTitle(prefix) {
    const marker = /^[★☆][^│\n]*│ /;                      // our own prefix always starts with ★/☆ and ends with " │ "
    const apply = () => {
      const current = document.title || '';
      if (current.startsWith(prefix)) return;
      document.title = prefix + (current.replace(marker, '') || location.hostname);
    };
    apply();
    let burst = 0, since = Date.now();
    const observer = new MutationObserver(() => {       // pages that rewrite their title get the rating put back
      const now = Date.now();
      if (now - since > 2000) { since = now; burst = 0; }
      if (++burst > 20) { observer.disconnect(); return; }   // the page keeps removing it: stop fighting
      apply();
    });
    observer.observe(document.head || document.documentElement, { childList: true, subtree: true, characterData: true });
    return () => { observer.disconnect(); document.title = (document.title || '').replace(marker, ''); };
  }

  // ---------------------------------------------------------------- badge
  function show({ results, combined }) {
    const el = (tag, cls, text) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; };
    const tone = s => (s >= 4 ? 'good' : s >= 3 ? 'ok' : 'bad');
    const number = n => new Intl.NumberFormat().format(n);
    const plural = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`;

    const host = document.createElement('div');
    host.id = 'shieldkit-ratings';
    host.style.cssText = 'all:initial;position:fixed;left:16px;bottom:16px;z-index:2147483647;';
    const root = host.attachShadow({ mode: 'open' });

    const style = el('style', null, `
      :host { all: initial; }
      * { box-sizing: border-box; }
      .card { position: relative; font: 13px/1.4 system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; color: #0f2a3d;
              background: #fff; border: 1px solid #dbe4ea; border-radius: 10px; padding: 10px 30px 10px 12px;
              box-shadow: 0 4px 18px rgba(15,42,61,.2); min-width: 230px; max-width: 310px; cursor: default; }
      .head { display: flex; align-items: baseline; gap: 8px; }
      .big { font-size: 24px; font-weight: 700; letter-spacing: -0.02em; }
      .lab { font-weight: 600; }
      .sub { font-size: 12px; margin-top: 1px; }
      .detail { margin-top: 8px; padding-top: 8px; border-top: 1px solid #e7eef2; }
      .row { display: flex; gap: 12px; justify-content: space-between; align-items: baseline; }
      .row + .row { margin-top: 3px; }
      .src { font-weight: 600; }
      .score { font-weight: 700; }
      .good { color: #0b7a35; } .ok { color: #9a6700; } .bad { color: #b42318; } .muted { color: #5b7083; font-weight: 400; }
      .note { margin-top: 4px; font-size: 12px; }
      .close { position: absolute; top: 4px; right: 4px; width: 22px; height: 22px; border: 0; border-radius: 50%; background: transparent; color: #5b7083; font-size: 16px; line-height: 1; cursor: pointer; }
      .close:hover { background: #eef3f6; }
      .dot { width: 42px; height: 42px; border-radius: 50%; border: 1px solid #dbe4ea; background: #fff; font: 700 14px system-ui, sans-serif; cursor: pointer; box-shadow: 0 2px 10px rgba(15,42,61,.2); }
      .dot.good { color: #0b7a35; } .dot.ok { color: #9a6700; } .dot.bad { color: #b42318; } .dot.none { color: #5b7083; }
      [hidden] { display: none !important; }
      button:focus-visible { outline: 2px solid #0b7a75; outline-offset: 2px; }
    `);

    const card = el('div', 'card');
    card.setAttribute('role', 'region'); card.setAttribute('aria-label', 'Site rating');

    // --- the one rating
    const head = el('div', 'head');
    const sub = el('div', 'sub muted');
    if (combined) {
      head.append(el('span', 'big ' + tone(combined.score), `★ ${combined.score.toFixed(1)}`), ' ', el('span', 'lab', combined.label));
      sub.textContent = combined.low
        ? `${plural(combined.sources, 'source')} · few reviews, take with care`
        : `${plural(combined.sources, 'source')} · ${number(combined.reviews)} reviews`;
    } else {
      head.append(el('span', 'lab', 'No ratings found'));
      sub.textContent = 'No public reviews were found for this site';
    }
    card.append(head, sub);

    // --- the individual ratings (plain text, nothing to click)
    const detail = el('div', 'detail');
    const none = [], failed = [];
    for (const { name, r } of results) {
      if (r.status === 'ok') {
        const row = el('div', 'row'), val = el('span');
        val.append(el('span', 'score ' + tone(r.score), `★ ${r.score.toFixed(1)}`));
        if (r.reviews != null) val.append(el('span', 'muted', ` · ${number(r.reviews)}`));
        row.append(el('span', 'src', name), ' ', val);
        detail.append(row);
      } else if (r.status === 'none') none.push(name);
      else if (r.status === 'nokey') {
        const row = el('div', 'row');
        row.append(el('span', 'src', name), ' ', el('span', 'muted', 'add a key to include it'));
        detail.append(row);
      } else failed.push(`${name} (${r.status === 'badkey' ? 'key rejected' : r.note || 'error'})`);
    }
    if (none.length) detail.append(el('div', 'note muted', `Not listed on: ${none.join(', ')}`));
    if (failed.length) detail.append(el('div', 'note muted', `Unavailable: ${failed.join(', ')}`));
    if (detail.childNodes.length) card.append(detail);

    const close = el('button', 'close', '×');
    close.type = 'button'; close.title = 'Hide ratings on this site'; close.setAttribute('aria-label', 'Hide ratings on this site');
    card.append(close);

    const dot = el('button', 'dot ' + (combined ? tone(combined.score) : 'none'), combined ? combined.score.toFixed(1) : '–');
    dot.type = 'button'; dot.hidden = true; dot.setAttribute('aria-label', 'Show site rating');

    let timer;
    const collapse = () => { card.hidden = true; dot.hidden = false; };
    const expand = () => { card.hidden = false; dot.hidden = true; arm(7000); };
    const arm = ms => { clearTimeout(timer); timer = setTimeout(collapse, ms); };

    dot.addEventListener('click', expand);
    card.addEventListener('mouseenter', () => clearTimeout(timer));
    card.addEventListener('mouseleave', () => arm(3000));
    close.addEventListener('click', async () => {
      clearTimeout(timer); host.remove(); stopTitle();
      try {
        const { ratingsHidden = [] } = await chrome.storage.local.get('ratingsHidden');
        if (!ratingsHidden.includes(location.hostname)) await chrome.storage.local.set({ ratingsHidden: [...ratingsHidden, location.hostname] });
      } catch (e) { /* ignore */ }
    });

    root.append(style, card, dot);
    document.documentElement.appendChild(host);
    arm(7000);
  }
})();
