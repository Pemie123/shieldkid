# ShieldKit – Ad Blocker & Safe Browsing (Chrome, Manifest V3)

## Install (developer mode)
1. Unzip this folder.
2. Open `chrome://extensions` and switch on **Developer mode** (top right).
3. Click **Load unpacked** and select the `shieldkit` folder.
4. Pin the shield icon. The badge shows how many requests were blocked on the current page.

## What it does
| Feature | How |
|---|---|
| Ad + tracker blocking | AdGuard Base filter (~75,000 rules, `rules/adguard.json`) plus a small extra list (`ads.json`, `trackers.json`), and CSS hiding of ~13,000 EasyList ad-container selectors (`cosmetic-list.js`) |
| Crypto-miner blocking | `rules/malware.json`; navigating to a listed domain shows a warning page |
| Phishing warnings | Local heuristics (`heuristics.js`): brand look-alikes, `user@host` tricks, raw IPs, punycode, scam-prone TLDs |
| Safe downloads | **Relaxed by default**: only blocks disguised files (`invoice.pdf.exe`), downloads from known-bad sites, and programs sent over plain HTTP. Normal installers, zips and scripts over HTTPS download untouched. A **Strict download checks** switch in the popup restores the old behaviour (every program/script, archives over HTTP). A notification always offers **Download anyway** |
| Site ratings | Trustpilot (no setup) and Google (your own Places API key) ratings in a small badge when you open a site. See below |
| Strict SafeSearch | Adds `safe=active` (Google), `adlt=strict` (Bing), `kp=1` (DuckDuckGo) and YouTube Restricted Mode |
| Force HTTPS | Upgrades http:// to https:// (local network addresses are exempt) |
| Clean links | Strips utm_*, fbclid, gclid, msclkid… |
| Privacy signals | Sends Global Privacy Control + Do Not Track, stops WebRTC local-IP leaks |
| Link checks | Right-click a link → VirusTotal or Google Safe Browsing report |
| YouTube ads | Removes ad data from player responses, auto-skips leftovers, hides feed/banner ads |
| Location (proxy/VPN) | Toolbar popup → Location. All 249 countries are listed; connect to any one you have added a server for. Verifies the connection and exit country, with a kill switch and WebRTC leak protection |
| Pause per site | Toolbar popup → Pause (also fixes any site that breaks) |

## Site ratings (one combined rating)
- **Sources:** Trustpilot, Sitejabber and Reviews.io work with no setup (ShieldKit reads each service's public page for the site's domain). Google is a fourth source if you add your own Places API key (ShieldKit → Ratings settings); Google only lists businesses with a Maps listing, bills per lookup beyond a free allowance, and answers are cached for a week. Review services keyed by shop ID or name (Kiyoh, Trusted Shops, WebwinkelKeur) can't be looked up from a domain.
- **One rating:** every service's score is first pulled toward a neutral 3.5 in proportion to how few reviews it has (one 5-star review never shows as 5.0), then the scores are averaged weighted by the square root of the review count. Shown to one decimal with a word (4.5+ Excellent, 4.0+ Great, 3.5+ Good, 3.0+ Average, 2.0+ Poor, below Bad), plus the source count and total reviews. The individual ratings are listed under it.
- **Where it shows:** the **start of the tab title**, e.g. `★4.3 Great · Trustpilot 4.3 · Sitejabber 4.0 │ Page title`, which is what Chrome displays on the tab and in the box that appears when your cursor rests on it (Chrome gives extensions no way to draw on the tab strip or that box, so the title is the only route). Sites with no reviews show `☆ Not rated │`, and if every service failed `☆ Ratings unavailable │`, so the hover is never blank. Also a badge bottom-left (collapses to a score dot after ~7 seconds, × hides it per site, nothing in it is a link), the toolbar icon's tooltip, and the popup. History and bookmarks record the title with the prefix; switch **Rating in tab title** off in the popup if you don't want that.
- **When a service says "Unavailable":** the badge says why (`blocked, HTTP 403`, `bot check page`, `page layout not recognised`, `no connection`). **Ratings settings → Test a site** shows exactly what each service returns for any domain and has a **Copy report** button.
- **Privacy:** for each new site the **domain only** (no path, no query, no cookies, no referrer) goes to each service. Never from private windows, never for IPs, intranet names, search engines or the services themselves. Cached 7 days (found), 2 days (not found), 10 minutes (error). Switch it all off with **Site ratings** in the popup.
- Pages are read, not an official API: if a service blocks the request or changes its layout, it is listed as "Unavailable" and left out of the combined rating rather than guessed.

## Location chooser: what it is and isn't
- It routes **this browser's traffic** through an HTTPS/HTTP proxy or a SOCKS5 server. It is not a system-wide VPN and does not cover other apps.
- **ShieldKit ships no servers.** Add servers from your VPN provider (many offer HTTPS/SOCKS proxy endpoints for browsers), from a server you run yourself (for example `ssh -D 1080 user@server` gives a SOCKS5 server at 127.0.0.1:1080), or import a list (`servers.example.json`). Avoid free public proxies; they can read and alter your traffic.
- Connecting runs a check: your IP is looked up before and through the server (ipinfo.io, falling back to ipwho.is). Connection is accepted only if the IP changed; a green "Verified" means it also geolocates to the chosen country. If the server doesn't respond, ShieldKit disconnects automatically.
- Kill switch (on by default): if the server later stops responding, traffic is blocked instead of falling back to your real IP.
- Chrome can't log in to SOCKS5 proxies, so SOCKS5 works only without a login.
- Logins are stored unencrypted in the browser profile. HTTP (non-S) proxies send the login unencrypted to the proxy; prefer HTTPS.
- The lookup services see your IP address (that is the point of the test). Geolocation databases can disagree, so a "warning" result isn't always a failure.

## Free servers from `Hidashimora/free-vpn-anti-rkn` (and other subscription lists)
That repo publishes VLESS / VMess / Trojan / Shadowsocks lists, not HTTP or SOCKS proxies, and Chrome extensions can't speak those protocols. So a small open-source client, **sing-box**, acts as a bridge, and ShieldKit drives it:
1. Install sing-box (https://sing-box.sagernet.org).
2. Run `python3 tools/subscription_to_singbox.py --singbox sing-box` in this folder. It downloads the repo's short lists, keeps up to 8 working-looking servers per country (sing-box validates each entry) and writes `shieldkit-singbox.json`. Add your own lists with `--url` or `--file`; see `--help`.
3. Run `sing-box run -c shieldkit-singbox.json` and leave it open. It listens on 127.0.0.1:2080 (proxy) and 127.0.0.1:9090 (controller) and picks the fastest working server in each country.
4. ShieldKit → Location → **Load countries**. Countries appear in the list; Connect selects that country in sing-box, points the browser at it and verifies the exit IP/country like any other server.
Re-run step 2 now and then; the lists change constantly and many free servers die.

Honest limits: the repo's lists are re-published automatically from other sources without vetting, the servers belong to strangers, and only entries whose names carry a country flag can be sorted by country (about a third in testing; the exit country is still verified on connect). Free servers can see which sites you visit and can tamper with plain http, so don't use them for banking or email logins. ShieldKit forces HTTPS while a free server is active. The sing-box controller on 127.0.0.1:9090 accepts requests from any web page by default, which could let a site switch your country group; restrict it with `access_control_allow_origin` in the config if that matters to you.

## Updating the filter lists
`tools/build_adguard.py` rebuilds `rules/adguard.json` and `cosmetic-list.js` from the latest upstream lists (instructions at the top of the file).
Licences: AdGuard filters are GPL-3.0, EasyList is GPL-3.0 / CC BY-SA 3.0. Fine for personal use; if you publish the extension, follow those terms.

## Customising the lists
Edit the lists at the top of `tools/generate_rules.py`, run `python3 tools/generate_rules.py`, then press the reload icon on the extension card.
Brand look-alike names live in `BRANDS` in `heuristics.js`.

## Limits worth knowing
- This complements, not replaces, Chrome's built-in Safe Browsing (keep "Enhanced protection" on). The domain lists here are starter lists, not a full filter list like EasyList.
- YouTube ads are inserted by YouTube's servers, so they can't be blocked by domain. ShieldKit strips ad entries from the data the player reads (`yt-main.js`), skips any ad that still plays and hides banner/feed ads (`yt-ui.js`). YouTube changes its code often, so this can stop working until updated; use the **YouTube ads** switch in the popup to turn it off if playback misbehaves. YouTube may also show a warning about ad blockers.
- The big list has ~75,000 rules, more than the 30,000 Chrome guarantees per extension, so it draws on a pool shared with other extensions. If that pool is full, the popup shows a notice and the small built-in list stays active.
- Heuristic phishing detection can produce false positives; "Continue anyway" or Pause handles those.
- No data leaves your browser; there is no analytics or server component.
