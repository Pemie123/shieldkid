// Pure helpers for site ratings (Trustpilot + Google). No chrome.* calls, so they can be unit-tested in Node.

// ---------- which sites get looked up, and under which name ----------
const CC_SLD = new Set(['co', 'com', 'org', 'net', 'gov', 'ac', 'edu']);
const SKIP_LABEL = /^(google|bing|duckduckgo|yahoo|ecosia|startpage|brave|trustpilot)$/;
const SKIP_TLD = new Set(['local', 'lan', 'internal', 'home', 'test', 'invalid', 'example', 'localhost', 'arpa']);

export function registrableDomain(host) {
  const labels = String(host).toLowerCase().replace(/\.$/, '').split('.');
  const n = labels.length;
  if (n <= 2) return labels.join('.');
  if (labels[n - 1].length === 2 && CC_SLD.has(labels[n - 2])) return labels.slice(-3).join('.');
  return labels.slice(-2).join('.');
}

/** Public, named websites only: no IPs, intranet names, search engines or Trustpilot itself. */
export function shouldLookup(host) {
  const h = String(host || '').toLowerCase();
  if (!h.includes('.') || h.startsWith('[') || /^\d+(\.\d+){3}$/.test(h)) return false;
  if (SKIP_TLD.has(h.split('.').pop())) return false;
  const reg = registrableDomain(h);
  return !SKIP_LABEL.test(reg.split('.')[0]);
}

// ---------- cache freshness ----------
export const TTL = { ok: 7 * 864e5, none: 2 * 864e5, nokey: 0, badkey: 10 * 6e4, error: 10 * 6e4 };
export const isFresh = (entry, now = Date.now()) =>
  !!entry && !!entry.v && now - entry.t < (TTL[entry.v.status] ?? 0);

// ---------- Trustpilot ----------
const num = v => { if (v == null || String(v).trim() === '') return null; const n = Number(String(v).replace(',', '.')); return Number.isFinite(n) ? n : null; };
const normScore = (value, best) => { const v = num(value); if (v == null) return null; const b = num(best) || 5; return b === 5 ? v : (v / b) * 5; };
const result = (score, reviews, name) =>
  score != null && score >= 0 && score <= 5
    ? { score: Math.round(score * 10) / 10, reviews: reviews != null && reviews >= 0 ? Math.round(reviews) : null, name: name || null }
    : null;

function findAggregate(node) {
  if (!node || typeof node !== 'object') return null;
  if (Array.isArray(node)) { for (const x of node) { const f = findAggregate(x); if (f) return f; } return null; }
  if (node['@type'] === 'AggregateRating' && node.ratingValue != null) return { ...node };
  if (node.aggregateRating) { const f = findAggregate(node.aggregateRating); if (f) return { ...f, name: node.name }; }
  for (const v of Object.values(node)) { const f = v && typeof v === 'object' ? findAggregate(v) : null; if (f) return f; }
  return null;
}

/** Reads a rating from embedded structured data (JSON-LD AggregateRating, then schema.org microdata). Used by every service. */
export function parseStructured(html) {
  const s = String(html || '');
  const ld = /<script[^>]*type="application\/ld\+json"[^>]*>([\s\S]*?)<\/script>/gi;
  let m;
  while ((m = ld.exec(s))) {
    try {
      const f = findAggregate(JSON.parse(m[1]));
      if (f) { const r = result(normScore(f.ratingValue, f.bestRating), num(f.reviewCount ?? f.ratingCount), f.name); if (r) return r; }
    } catch { /* next block */ }
  }
  const prop = name => {
    const a = new RegExp(`itemprop=["']${name}["'][^>]*?content=["']([^"']+)["']`, 'i').exec(s)
      || new RegExp(`content=["']([^"']+)["'][^>]*?itemprop=["']${name}["']`, 'i').exec(s)
      || new RegExp(`itemprop=["']${name}["'][^>]*>\\s*([0-9][0-9.,]*)\\s*<`, 'i').exec(s);
    return a && a[1];
  };
  const rv = prop('ratingValue');
  return rv ? result(normScore(rv, prop('bestRating')), num(prop('reviewCount') ?? prop('ratingCount'))) : null;
}

/** Reads the rating from a Trustpilot business page. Tries the embedded page data, then JSON-LD, then visible text. */
export function parseTrustpilot(html) {
  const s = String(html || '');
  let m = /<script[^>]*id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/i.exec(s);
  if (m) {
    try {
      const bu = JSON.parse(m[1])?.props?.pageProps?.businessUnit;
      if (bu) {
        const count = typeof bu.numberOfReviews === 'object' ? bu.numberOfReviews?.total : (bu.numberOfReviews ?? bu.reviewsCount);
        const r = result(num(bu.trustScore), num(count), bu.displayName);
        if (r) return r;
      }
    } catch { /* fall through */ }
  }
  const structured = parseStructured(s);
  if (structured) return structured;
  const ts = /"trustScore"\s*:\s*([0-9]+(?:\.[0-9]+)?)/.exec(s);                      // same numbers, if the page data was reshaped
  if (ts) {
    const nr = /"numberOfReviews"\s*:\s*(?:\{[^{}]*?"total"\s*:\s*)?([0-9]+)/.exec(s);
    const named = /"displayName"\s*:\s*"([^"]{1,80})"/.exec(s);
    const r = result(num(ts[1]), nr ? num(nr[1]) : null, named && named[1]);
    if (r) return r;
  }
  const text = s.replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>/gi, ' ').replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ');
  const sc = /TrustScore\s+([0-9]+(?:[.,][0-9]+)?)\s+out of\s+5/i.exec(text);
  if (sc) {
    let reviews = null;
    const exact = /All reviews\s*\(\s*([0-9][0-9.,]*)\s*\)/i.exec(text);        // "All reviews (2,041)"
    const short = /([0-9][0-9.,]*)\s*(k)?\s+(?:total\s+)?reviews/i.exec(text);      // "2k reviews" (rounded)
    if (exact) reviews = parseInt(exact[1].replace(/[.,]/g, ''), 10);
    else if (short) reviews = short[2] ? Math.round(parseFloat(short[1].replace(',', '.')) * 1000) : parseInt(short[1].replace(/[.,]/g, ''), 10);
    return result(num(sc[1]), reviews);
  }
  return null;
}

/** Reviews.io says "<name> is rated 4.9 based on 585 reviews" in the page. */
export function parseReviewsIo(html) {
  const st = parseStructured(html);
  if (st) return st;
  const text = String(html || '').replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>/gi, ' ').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ');
  const m = /is rated\s+([0-5](?:[.,][0-9]+)?)\s+based on\s+([0-9][0-9.,]*)\s+reviews/i.exec(text);
  return m ? result(num(m[1]), parseInt(m[2].replace(/[.,]/g, ''), 10)) : null;
}

/** Sitejabber: only trusted when the page carries structured data, so a wrong number is never guessed. */
export const parseSitejabber = html => parseStructured(html);

/** Review sites that can be looked up from a domain alone, with no key. */
export const SERVICES = [
  { id: 'trustpilot', name: 'Trustpilot', pathPrefix: '/review/', parse: parseTrustpilot,
    urls: d => [`https://www.trustpilot.com/review/${d}`, `https://www.trustpilot.com/review/www.${d}`] },
  { id: 'sitejabber', name: 'Sitejabber', pathPrefix: '/reviews/', parse: parseSitejabber,
    urls: d => [`https://www.sitejabber.com/reviews/${d}`] },
  { id: 'reviewsio', name: 'Reviews.io', pathPrefix: '/company-reviews/store/', parse: parseReviewsIo,
    urls: d => [`https://www.reviews.io/company-reviews/store/${d.replace(/\./g, '-')}`, `https://www.reviews.io/company-reviews/store/${d}`] }
];

const BLOCKED = new Set([401, 403, 429, 503]);
const CHALLENGE = /just a moment|cf-chl|challenge-platform|captcha|are you a robot|access denied/i;
const plain = html => String(html || '').replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>/gi, ' ').replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim();
const fail = (reason, note, extra = {}) => ({ status: 'error', reason, note, ...extra });

/** Looks a domain up on one service. Errors carry a short human reason (`note`) so "Unavailable" is never a mystery. */
export async function lookupService(service, domain, fetchFn = fetch) {
  let failure = null;
  for (const url of service.urls(domain)) {
    let res;
    try { res = await fetchFn(url, { credentials: 'omit', referrerPolicy: 'no-referrer' }); }
    catch { failure = fail('offline', 'no connection'); break; }
    if (res.status === 404 || res.status === 410) continue;
    if (!res.ok) {
      failure = BLOCKED.has(res.status) ? fail('blocked', `blocked, HTTP ${res.status}`, { httpStatus: res.status }) : fail('http', `HTTP ${res.status}`, { httpStatus: res.status });
      break;
    }
    if (res.redirected && res.url && !res.url.includes(service.pathPrefix)) continue;   // bounced to a search or home page: no such company
    const html = await res.text();
    const parsed = service.parse(html);
    if (parsed) return { status: 'ok', ...parsed, url: res.url && res.url.includes(service.pathPrefix) ? res.url : url };
    const text = plain(html);
    failure = CHALLENGE.test(text.slice(0, 600))
      ? fail('challenge', 'bot check page', { snippet: text.slice(0, 160) })
      : fail('unreadable', 'page layout not recognised', { snippet: text.slice(0, 160) });
    break;
  }
  return failure || { status: 'none' };
}

export const lookupTrustpilot = (domain, fetchFn = fetch) => lookupService(SERVICES[0], domain, fetchFn);

// ---------- one combined rating ----------
export function ratingLabel(score) {
  return score >= 4.5 ? 'Excellent' : score >= 4 ? 'Great' : score >= 3.5 ? 'Good' : score >= 3 ? 'Average' : score >= 2 ? 'Poor' : 'Bad';
}

/** Merges every service's score (already on a 0 to 5 scale) into one number.
 *  1. Each source is first pulled toward a neutral 3.5 in proportion to how few reviews it has, so one 5-star
 *     review does not look like a 5.0 while 2,000 reviews barely move.
 *  2. Sources are then averaged, weighted by the square root of their review count, so a very large source counts
 *     more but cannot drown out the others. Unknown review counts are treated as 25. */
export function combineRatings(items, prior = 3.5, strength = 10) {
  const ok = (items || []).filter(i => i && Number.isFinite(i.score));
  if (!ok.length) return null;
  let sum = 0, weight = 0, total = 0;
  for (const i of ok) {
    const n = Math.max(1, i.reviews ?? 25);
    const shrunk = (n * i.score + strength * prior) / (n + strength);
    const w = Math.sqrt(n);
    sum += w * shrunk; weight += w; total += i.reviews ?? 0;
  }
  const score = Math.round((sum / weight) * 10) / 10;
  return { score, label: ratingLabel(score), sources: ok.length, reviews: total, low: total < 10 };
}

// ---------- Google (Places API, needs the user's own key) ----------
export function parseGooglePlaces(data, domain) {
  for (const p of (data && data.places) || []) {
    let host = '';
    try { host = new URL(p.websiteUri).hostname.replace(/^www\./, ''); } catch { /* no website */ }
    if (host && registrableDomain(host) === domain && typeof p.rating === 'number') {
      return { score: p.rating, reviews: p.userRatingCount ?? null, name: (p.displayName && p.displayName.text) || null, url: p.googleMapsUri || null };
    }
  }
  return null;
}

const PLACES = 'https://places.googleapis.com/v1/places:searchText';
const placesHeaders = (key, mask) => ({ 'Content-Type': 'application/json', 'X-Goog-Api-Key': key, 'X-Goog-FieldMask': mask });

export async function lookupGoogle(domain, apiKey, fetchFn = fetch) {
  if (!apiKey) return { status: 'nokey' };
  let res;
  try {
    res = await fetchFn(PLACES, {
      method: 'POST', credentials: 'omit', referrerPolicy: 'no-referrer',
      headers: placesHeaders(apiKey, 'places.displayName,places.rating,places.userRatingCount,places.websiteUri,places.googleMapsUri'),
      body: JSON.stringify({ textQuery: domain, pageSize: 5 })
    });
  } catch { return { status: 'error' }; }
  if (res.status === 400 || res.status === 401 || res.status === 403) return { status: 'badkey' };
  if (!res.ok) return { status: 'error' };
  const hit = parseGooglePlaces(await res.json(), domain);
  return hit ? { status: 'ok', ...hit } : { status: 'none' };
}

export async function testGoogleKey(apiKey, fetchFn = fetch) {
  try {
    const res = await fetchFn(PLACES, { method: 'POST', credentials: 'omit', headers: placesHeaders(apiKey, 'places.displayName'), body: JSON.stringify({ textQuery: 'Eiffel Tower', pageSize: 1 }) });
    if (res.ok) return { ok: true, message: 'The key works.' };
    let detail = ''; try { detail = (await res.json()).error.message; } catch { /* no body */ }
    return { ok: false, message: `Google rejected the key (HTTP ${res.status}). ${detail}`.trim() };
  } catch (e) { return { ok: false, message: 'Could not reach Google: ' + e.message }; }
}

// ---------- tab title (what Chrome shows on the tab and in its hover card) ----------
/** Everything before the page's own title. Always starts with ★ or ☆ and ends with " │ " so it can be removed exactly. */
export function titlePrefix({ combined, results }) {
  if (combined) {
    const parts = results.filter(x => x.r.status === 'ok').map(x => `${x.name} ${x.r.score.toFixed(1)}`);
    return `★${combined.score.toFixed(1)} ${combined.label}${combined.low ? ' (few reviews)' : ''}${parts.length ? ' · ' + parts.join(' · ') : ''} │ `;
  }
  const checked = results.filter(x => x.r.status !== 'nokey');
  const broken = checked.filter(x => x.r.status === 'error' || x.r.status === 'badkey');
  return checked.length && broken.length === checked.length ? '☆ Ratings unavailable │ ' : '☆ Not rated │ ';
}
export const stripTitlePrefix = title => String(title || '').replace(/^[★☆][^│\n]*│ /, '');
