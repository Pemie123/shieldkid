// Runs inside YouTube's own page context (manifest "world": "MAIN") so it can intercept the data the
// player reads. It removes ad entries from player/next/browse responses before the player sees them.
(() => {
  'use strict';
  const AD_KEYS = ['adPlacements', 'playerAds', 'adSlots', 'adBreakParams', 'adBreakHeartbeatParams'];
  const API = /\/youtubei\/v1\/(player|next|browse|search|get_watch|reel\/reel_item_watch|reel\/reel_watch_sequence)/;
  const enabled = () => document.documentElement.getAttribute('data-sk-yt') !== 'off';

  const prune = (o) => {
    if (!o || typeof o !== 'object') return o;
    for (const k of AD_KEYS) {
      if (k in o) { try { o[k] = Array.isArray(o[k]) ? [] : undefined; } catch (e) { /* frozen */ } }
    }
    if (o.playerResponse && typeof o.playerResponse === 'object') prune(o.playerResponse);
    return o;
  };

  // 1) the player response embedded in the page HTML
  let initial;
  try {
    Object.defineProperty(window, 'ytInitialPlayerResponse', {
      configurable: true,
      get() { return initial; },
      set(v) { initial = enabled() ? prune(v) : v; }
    });
  } catch (e) { /* already defined */ }

  // 2) anything parsed with JSON.parse (older code paths, embedded data)
  const parse = JSON.parse;
  JSON.parse = function (...args) {
    const out = parse.apply(this, args);
    if (enabled()) { try { prune(out); } catch (e) { /* ignore */ } }
    return out;
  };

  // 3) player/next/browse API calls made with fetch()
  const nativeFetch = window.fetch;
  window.fetch = async function (...args) {
    const res = await nativeFetch.apply(this, args);
    try {
      if (!enabled()) return res;
      const url = typeof args[0] === 'string' ? args[0] : (args[0] && args[0].url) || '';
      if (!API.test(url)) return res;
      const data = prune(await res.clone().json());
      const headers = new Headers(res.headers);
      headers.delete('content-length');
      return new Response(JSON.stringify(data), { status: res.status, statusText: res.statusText, headers });
    } catch (e) {
      return res;
    }
  };
})();
