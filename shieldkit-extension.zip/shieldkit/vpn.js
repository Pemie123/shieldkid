import { countryList, countryName, validateServer, parseServers, buildPac, lookupIp, judge, bridgeCountries, bridgeSelect, bridgeServers, validApi, BRIDGE } from './vpn-core.js';

const $ = id => document.getElementById(id);
const sleep = ms => new Promise(r => setTimeout(r, ms));
const state = { servers: [], vpn: { activeId: null, killSwitch: true, last: null }, choice: {}, bridge: { api: BRIDGE.api, port: BRIDGE.port } };

// ---------------------------------------------------------------- storage
async function load() {
  const s = await chrome.storage.local.get(['vpnServers', 'vpn', 'vpnBridge']);
  state.servers = s.vpnServers || [];
  state.bridge = { api: BRIDGE.api, port: BRIDGE.port, ...(s.vpnBridge || {}) };
  state.vpn = { activeId: null, killSwitch: true, last: null, ...(s.vpn || {}) };
}
const saveServers = () => chrome.storage.local.set({ vpnServers: state.servers });
const saveVpn = () => chrome.storage.local.set({ vpn: state.vpn });
const active = () => state.servers.find(s => s.id === state.vpn.activeId) || null;

function say(text, level = '') { const el = $('msg'); el.textContent = text; el.className = level; }
function busy(on) { document.querySelectorAll('button').forEach(b => { b.disabled = on; }); }

// ---------------------------------------------------------------- proxy control
async function applyProxy(server) {
  await chrome.proxy.settings.set({
    value: { mode: 'pac_script', pacScript: { data: buildPac(server, state.vpn.killSwitch), mandatory: true } },
    scope: 'regular'
  });
}

async function disconnect(silent = false) {
  await chrome.proxy.settings.clear({ scope: 'regular' });
  state.vpn.activeId = null; state.vpn.last = null;
  await saveVpn();
  if (!silent) say('Disconnected. Your real IP address is visible again.', '');
  render();
}

async function connect(id) {
  const server = state.servers.find(s => s.id === id);
  if (!server) return;
  busy(true);
  say(`Connecting to ${countryName(server.country)} (${server.name})…`);
  try {
    const { levelOfControl } = await chrome.proxy.settings.get({});
    if (levelOfControl === 'controlled_by_other_extensions' || levelOfControl === 'not_controllable') {
      throw new Error('Another extension or a browser policy controls your proxy settings. Disable it and try again.');
    }
    await chrome.proxy.settings.clear({ scope: 'regular' });
    state.vpn.activeId = null; state.vpn.last = null;

    let baseline = null;
    try { baseline = await lookupIp(); } catch (e) { /* offline lookup service: judge without baseline */ }

    if (server.bridge) {                       // free server: tell the local client which country group to use
      try { await bridgeSelect(state.bridge.api, server.group); }
      catch (e) { throw new Error(`${e.message} Is the local client still running?`); }
    }
    state.vpn.activeId = server.id;            // background reads this to supply the proxy login
    await saveVpn();
    await applyProxy(server);
    await sleep(300);

    let via = null, error = null;
    const tries = server.bridge ? 3 : 1;       // a country group needs a moment to find a working free server
    for (let i = 0; i < tries && !via; i++) {
      if (i) { say(`Waiting for a working server in ${countryName(server.country)} (attempt ${i + 1} of ${tries})…`); await sleep(2000); }
      try { via = await lookupIp(fetch, server.bridge ? 6000 : 8000); error = null; } catch (e) { error = e; }
    }
    const verdict = error
      ? { level: 'fail', text: server.bridge ? `No free server in ${countryName(server.country)} answered right now (${error.message}). Free servers come and go; try another country.` : `The server did not respond (${error.message}). Check host, port, type and login.` }
      : judge(baseline, via, server.country);

    if (verdict.level === 'fail') {
      await disconnect(true);
      say(`${verdict.text} You are not connected.`, 'bad');
    } else {
      state.vpn.last = { ...via, verdict, baselineIp: baseline && baseline.ip, checkedAt: Date.now() };
      await saveVpn();
      say(verdict.text, verdict.level);
    }
  } catch (e) {
    await disconnect(true);
    say(e.message, 'bad');
  } finally {
    busy(false); render();
  }
}

async function retest() {
  const server = active();
  if (!server) return;
  busy(true); say('Testing the connection…');
  try {
    const via = await lookupIp();
    const baselineIp = state.vpn.last && state.vpn.last.baselineIp;
    const verdict = judge(baselineIp ? { ip: baselineIp } : null, via, server.country);
    state.vpn.last = { ...via, verdict, baselineIp, checkedAt: Date.now() };
    await saveVpn();
    say(verdict.text, verdict.level);
  } catch (e) {
    say(`No response through the server (${e.message}). ${state.vpn.killSwitch ? 'Traffic is blocked until it recovers or you disconnect.' : ''}`, 'bad');
  } finally { busy(false); render(); }
}

// ---------------------------------------------------------------- rendering
function renderStatus() {
  const server = active();
  const box = $('status');
  box.className = 'status';
  $('testBtn').hidden = $('disconnectBtn').hidden = !server;
  if (!server) {
    $('statusCode').textContent = '–';
    $('statusTitle').textContent = 'Not connected';
    $('statusDetail').textContent = 'Your real IP address is visible to websites.';
    return;
  }
  const last = state.vpn.last;
  $('statusCode').textContent = server.country;
  $('statusTitle').textContent = `${countryName(server.country)} · ${server.name}`;
  if (last) {
    box.classList.add(last.verdict.level === 'ok' ? 'ok' : 'warn');
    const where = [last.city, countryName(last.country)].filter(Boolean).join(', ');
    $('statusDetail').textContent = `${last.verdict.level === 'ok' ? 'Verified' : 'Check result'}: your IP is ${last.ip} (${where}${last.org ? ', ' + last.org : ''})`;
  } else {
    $('statusDetail').textContent = 'Connected. Press “Test again” to verify.';
  }
}

function renderCountries() {
  const q = $('search').value.trim().toLowerCase();
  const list = $('countries');
  list.replaceChildren();
  const rows = countryList()
    .map(c => ({ ...c, servers: state.servers.filter(s => s.country === c.code) }))
    .filter(c => !q || c.name.toLowerCase().includes(q) || c.code.toLowerCase() === q)
    .sort((a, b) => (b.servers.length > 0) - (a.servers.length > 0) || a.name.localeCompare(b.name));
  if (!rows.length) { const li = document.createElement('li'); li.className = 'empty'; li.textContent = 'No country matches your search.'; list.append(li); return; }

  for (const c of rows) {
    const li = document.createElement('li');
    const isActive = active() && active().country === c.code;
    li.className = isActive ? 'active' : (c.servers.length ? '' : 'none');
    const code = document.createElement('span'); code.className = 'code'; code.textContent = c.code;
    const name = document.createElement('span');
    name.textContent = c.name + (c.servers.length ? `  ·  ${c.servers.length} server${c.servers.length > 1 ? 's' : ''}` : '  ·  no server added');
    const actions = document.createElement('span'); actions.className = 'actions';

    if (c.servers.length) {
      let select = null;
      if (c.servers.length > 1) {
        select = document.createElement('select'); select.setAttribute('aria-label', `Server in ${c.name}`);
        for (const s of c.servers) { const o = document.createElement('option'); o.value = s.id; o.textContent = s.name; select.append(o); }
        select.value = (isActive && active().id) || state.choice[c.code] || c.servers[0].id;
        select.addEventListener('change', () => { state.choice[c.code] = select.value; });
        actions.append(select);
      }
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.textContent = isActive ? 'Disconnect' : 'Connect';
      btn.addEventListener('click', () => isActive ? disconnect() : connect(select ? select.value : c.servers[0].id));
      actions.append(btn);
    } else {
      const btn = document.createElement('button');
      btn.type = 'button'; btn.textContent = 'Add server';
      btn.addEventListener('click', () => { $('fCountry').value = c.name; $('fHost').focus(); $('fHost').scrollIntoView({ block: 'center' }); });
      actions.append(btn);
    }
    li.append(code, name, actions);
    list.append(li);
  }
}

function renderServers() {
  const wrap = $('serverTable');
  wrap.replaceChildren();
  const mine = state.servers.filter(s => !s.bridge);
  if (!mine.length) { const p = document.createElement('p'); p.className = 'empty'; p.textContent = 'No servers of your own yet. Add one below or import a list.'; wrap.append(p); return; }
  const table = document.createElement('table');
  const head = table.createTHead().insertRow();
  for (const h of ['Country', 'Name', 'Server', 'Login', '']) { const th = document.createElement('th'); th.textContent = h; head.append(th); }
  const body = table.createTBody();
  for (const s of mine) {
    const tr = body.insertRow();
    [countryName(s.country), s.name, `${s.scheme}://${s.host}:${s.port}`, s.username ? 'yes' : 'no'].forEach(t => { tr.insertCell().textContent = t; });
    const btn = document.createElement('button'); btn.type = 'button'; btn.textContent = 'Remove';
    btn.addEventListener('click', async () => {
      if (state.vpn.activeId === s.id) await disconnect(true);
      state.servers = state.servers.filter(x => x.id !== s.id);
      await saveServers(); render(); say(`Removed ${s.name}.`);
    });
    tr.insertCell().append(btn);
  }
  wrap.append(table);
}

function render() {
  renderStatus(); renderCountries(); renderServers();
  $('kill').checked = !!state.vpn.killSwitch;
  const n = state.servers.filter(s => s.bridge).length;
  $('bridgeInfo').textContent = n ? `${n} countries loaded from the local client.` : '';
  $('bridgeApi').value = state.bridge.api; $('bridgePort').value = state.bridge.port;
}

// ---------------------------------------------------------------- adding / importing
async function addServers(list, label) {
  let added = 0;
  for (const s of list) {
    const i = state.servers.findIndex(x => x.id === s.id);
    if (i >= 0) state.servers[i] = s; else { state.servers.push(s); added++; }
  }
  await saveServers(); render();
  say(`${label}: ${added} new server${added === 1 ? '' : 's'} added${list.length - added ? `, ${list.length - added} updated` : ''}.`, 'ok');
}

$('addBtn').addEventListener('click', async () => {
  const r = validateServer({
    country: $('fCountry').value, name: $('fName').value, scheme: $('fScheme').value,
    host: $('fHost').value, port: $('fPort').value, username: $('fUser').value, password: $('fPass').value
  });
  if (r.error) return say(r.error, 'bad');
  await addServers([r.server], 'Added');
  ['fName', 'fHost', 'fPort', 'fUser', 'fPass'].forEach(id => { $(id).value = ''; });
});

async function runImport(text) {
  const { servers, errors } = parseServers(text);
  if (servers.length) await addServers(servers, 'Imported');
  if (errors.length) say(`${servers.length ? 'Imported with problems. ' : ''}${errors.slice(0, 3).join(' · ')}${errors.length > 3 ? ` · and ${errors.length - 3} more` : ''}`, servers.length ? 'warn' : 'bad');
  if (servers.length) $('importText').value = '';
}
$('importBtn').addEventListener('click', () => runImport($('importText').value));
$('importFile').addEventListener('change', async e => { const f = e.target.files[0]; if (f) await runImport(await f.text()); e.target.value = ''; });
$('exportBtn').addEventListener('click', () => {
  const url = URL.createObjectURL(new Blob([JSON.stringify(state.servers.filter(s => !s.bridge), null, 2)], { type: 'application/json' }));
  const a = Object.assign(document.createElement('a'), { href: url, download: 'shieldkit-servers.json' });
  a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
});

$('kill').addEventListener('change', async () => {
  state.vpn.killSwitch = $('kill').checked;
  await saveVpn();
  if (active()) await applyProxy(active());       // rebuild the script with/without DIRECT fallback
});
$('bridgeLoad').addEventListener('click', async () => {
  const api = validApi($('bridgeApi').value);
  const port = Number($('bridgePort').value);
  if (!api) return say('The client address must be on this computer, for example http://127.0.0.1:9090.', 'bad');
  if (!Number.isInteger(port) || port < 1 || port > 65535) return say('The proxy port must be a number from 1 to 65535.', 'bad');
  busy(true); say('Loading countries from the local client…');
  try {
    const countries = await bridgeCountries(api);
    if (active() && active().bridge) await disconnect(true);
    state.bridge = { api, port };
    await chrome.storage.local.set({ vpnBridge: state.bridge });
    state.servers = state.servers.filter(s => !s.bridge).concat(bridgeServers(countries, port));
    await saveServers();
    say(`Loaded ${countries.length} countries. Pick one in the list above.`, 'ok');
  } catch (e) { say(e.message, 'bad'); } finally { busy(false); render(); }
});
$('bridgeClear').addEventListener('click', async () => {
  if (active() && active().bridge) await disconnect(true);
  state.servers = state.servers.filter(s => !s.bridge);
  await saveServers(); render(); say('Free servers removed.');
});
$('search').addEventListener('input', renderCountries);
$('disconnectBtn').addEventListener('click', () => disconnect());
$('testBtn').addEventListener('click', retest);

// ---------------------------------------------------------------- boot
const dl = $('countryNames');
for (const c of countryList()) { const o = document.createElement('option'); o.value = c.name; dl.append(o); }
load().then(render);
