// Pure functions (no chrome.* calls) so they can be unit-tested in Node.

// ---------- hosts ----------
export function hostInSet(host, set) {
  const parts = host.split('.');
  for (let i = 0; i < parts.length - 1; i++) {
    if (set.has(parts.slice(i).join('.'))) return true;
  }
  return false;
}

export function isPaused(host, paused) {
  return paused.some(p => host === p || host.endsWith('.' + p));
}

// ---------- phishing / look-alike detection ----------
const BRANDS = {
  paypal: ['paypal.com'], apple: ['apple.com'], icloud: ['icloud.com'],
  microsoft: ['microsoft.com', 'live.com', 'office.com'], office365: ['office.com'],
  google: ['google.com'], gmail: ['gmail.com', 'google.com'],
  amazon: ['amazon.com'], facebook: ['facebook.com'], instagram: ['instagram.com'],
  netflix: ['netflix.com'], whatsapp: ['whatsapp.com'], linkedin: ['linkedin.com'],
  dropbox: ['dropbox.com'], docusign: ['docusign.com', 'docusign.net'],
  dhl: ['dhl.com'], bpost: ['bpost.be'], belfius: ['belfius.be'], kbc: ['kbc.be'],
  itsme: ['itsme.be', 'itsme-id.com'], argenta: ['argenta.be'], bnpparibasfortis: ['bnpparibasfortis.be']
};
const CC_SLD = new Set(['co', 'com', 'org', 'net', 'gov', 'ac', 'edu']);
const RISKY_TLDS = new Set(['tk', 'ml', 'ga', 'cf', 'gq', 'zip', 'mov', 'click']);
const LOGIN_WORDS = /(login|log-in|signin|sign-in|verify|account|secure|update|password|wallet|billing|confirm)/i;
const IPV4 = /^\d{1,3}(\.\d{1,3}){3}$/;
const PRIVATE_IP = /^(10\.|127\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|169\.254\.)/;

function registrableIndex(labels) {
  const n = labels.length;
  if (n >= 3 && labels[n - 1].length === 2 && CC_SLD.has(labels[n - 2])) return n - 3;
  return Math.max(n - 2, 0);
}

/** @param {URL} u  @returns {{score:number, reasons:string[]}} */
export function assessUrl(u) {
  const host = u.hostname.toLowerCase();
  const reasons = [];
  let score = 0;
  if (host === 'localhost' || host.endsWith('.local') || PRIVATE_IP.test(host) || host.startsWith('[')) {
    return { score: 0, reasons };
  }
  const labels = host.split('.');
  const reg = registrableIndex(labels);

  if (u.username || u.password) {
    score += 3; reasons.push('The address hides its real destination behind a username (user@host trick)');
  }
  if (IPV4.test(host)) {
    score += 2; reasons.push('Uses a raw IP address instead of a domain name');
  }
  if (labels.some(l => l.startsWith('xn--'))) {
    score += 2; reasons.push('Domain uses look-alike (punycode) characters');
  }
  if (RISKY_TLDS.has(labels[labels.length - 1])) {
    score += 1; reasons.push(`The .${labels[labels.length - 1]} ending is often abused for scams`);
  }
  if (labels.length > 5) {
    score += 1; reasons.push('Unusually many subdomains');
  }
  if ((labels[reg] || '').split('-').length > 3) {
    score += 1; reasons.push('Domain name stuffed with hyphens');
  }
  if (host.length > 60) {
    score += 1; reasons.push('Extremely long domain name');
  }
  if (LOGIN_WORDS.test(host + u.pathname) && (u.protocol === 'http:' || IPV4.test(host))) {
    score += 1; reasons.push('Asks for account details on an insecure or unnamed host');
  }

  const seen = new Set();
  labels.forEach((label, i) => {
    for (const token of label.split('-')) {
      const official = BRANDS[token];
      if (!official || seen.has(token)) continue;
      if (official.some(d => host === d || host.endsWith('.' + d))) continue;
      if (i === reg && label === token) continue;      // e.g. google.be, amazon.de
      seen.add(token);
      score += 3; reasons.push(`Looks like it is imitating “${token}” but is not its official site`);
    }
  });
  return { score, reasons };
}

// ---------- dangerous downloads ----------
export const DANGEROUS_EXT = new Set([
  'exe', 'msi', 'scr', 'bat', 'cmd', 'com', 'pif', 'cpl', 'dll', 'vbs', 'vbe', 'jse',
  'wsf', 'wsh', 'ps1', 'psm1', 'hta', 'lnk', 'jar', 'reg', 'inf', 'msix', 'appx', 'apk',
  'docm', 'xlsm', 'pptm', 'vhd', 'vhdx'
]);
const ARCHIVE_EXT = new Set(['zip', 'rar', '7z', 'iso', 'img', 'dmg', 'pkg', 'gz', 'tar']);
const DANGEROUS_MIME = [/x-msdownload/, /x-msdos-program/, /portable-executable/, /x-dosexec/,
  /java-archive/, /android\.package-archive/, /x-sh$/, /x-bat/];
const DOUBLE_EXT = /\.(pdf|docx?|xlsx?|pptx?|jpe?g|png|gif|txt|mp3|mp4|rtf)\.(exe|scr|bat|cmd|com|vbs|js|jse|msi|jar|ps1|lnk|hta|pif)$/i;

const extOf = name => { const m = /\.([a-z0-9]+)$/i.exec(name || ''); return m ? m[1].toLowerCase() : ''; };

/** Default ("relaxed") only flags clear attacks: disguised files, known-bad sites and programs sent over plain HTTP.
 *  strict = also flag every program or script and archives over HTTP.
 *  @param {{url?:string, finalUrl?:string, filename?:string, mime?:string}} item */
export function assessDownload(item, malwareHosts = new Set(), strict = false) {
  const reasons = [];
  const url = item.finalUrl || item.url || '';
  let host = '', path = '';
  try { const u = new URL(url); host = u.hostname.toLowerCase(); path = decodeURIComponent(u.pathname); } catch { /* data:, blob: */ }
  const name = ((item.filename || '').split(/[\\/]/).pop()) || path.split('/').pop() || '';
  const ext = extOf(name);
  const dangerous = DANGEROUS_EXT.has(ext) || DANGEROUS_MIME.some(re => re.test(item.mime || ''));
  const insecure = url.startsWith('http:');

  if (DOUBLE_EXT.test(name)) reasons.push('Disguised as a document or image (double extension)');
  if (host && hostInSet(host, malwareHosts)) reasons.push('Comes from a known malicious domain');
  if (insecure && dangerous) reasons.push('Program sent over an insecure HTTP connection');
  if (strict) {
    if (dangerous) reasons.push(`Program or script file${ext ? ` (.${ext})` : ''}`);
    if (insecure && ARCHIVE_EXT.has(ext)) reasons.push('Archive sent over an insecure HTTP connection');
  }
  return { reasons, name: name || 'download' };
}
