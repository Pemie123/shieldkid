// Pure helpers for the Location (proxy) feature. No chrome.* calls, so they can be unit-tested in Node.
import { COUNTRY_CODES } from './countries.js';

export const SCHEMES = ['https', 'http', 'socks5'];
const HOST_RE = /^(?=.{1,253}$)[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*$/i;
const ALIASES = { UK: 'GB' };

// ---------- countries ----------
let nameMap;
function names() {
  if (!nameMap) {
    const dn = typeof Intl !== 'undefined' && Intl.DisplayNames ? new Intl.DisplayNames(['en'], { type: 'region' }) : null;
    nameMap = Object.fromEntries(COUNTRY_CODES.map(c => [c, (dn && dn.of(c)) || c]));
  }
  return nameMap;
}
export const countryName = code => names()[String(code || '').toUpperCase()] || code || '';
export const countryList = () =>
  COUNTRY_CODES.map(code => ({ code, name: countryName(code) })).sort((a, b) => a.name.localeCompare(b.name));

export function codeFromInput(value) {
  const s = String(value ?? '').trim();
  if (!s) return null;
  if (/^[A-Za-z]{2}$/.test(s)) {
    const u = ALIASES[s.toUpperCase()] || s.toUpperCase();
    return COUNTRY_CODES.includes(u) ? u : null;
  }
  const lower = s.toLowerCase();
  return COUNTRY_CODES.find(c => countryName(c).toLowerCase() === lower) || null;
}

// ---------- servers ----------
export function validateServer(raw) {
  const country = codeFromInput(raw.country ?? raw.countryCode ?? raw.cc);
  if (!country) return { error: `Unknown country “${raw.country ?? ''}”` };
  const scheme = String(raw.scheme || raw.type || 'https').toLowerCase();
  if (!SCHEMES.includes(scheme)) return { error: `Unsupported type “${scheme}” (use https, http or socks5)` };
  const host = String(raw.host || '').trim().toLowerCase();
  if (!HOST_RE.test(host)) return { error: `Invalid host “${raw.host ?? ''}”` };
  const port = Number(raw.port);
  if (!Number.isInteger(port) || port < 1 || port > 65535) return { error: `Invalid port “${raw.port ?? ''}”` };
  const username = String(raw.username || '');
  const password = String(raw.password || '');
  if (scheme === 'socks5' && username) {
    return { error: 'Chrome cannot log in to SOCKS5 proxies. Use an https proxy, or a SOCKS5 server without a login.' };
  }
  const name = String(raw.name || '').trim().slice(0, 60) || host;
  return { server: { id: `${country}-${scheme}-${host}-${port}`, country, scheme, host, port, username, password, name } };
}

/** Accepts a JSON array (or {servers:[...]}) or CSV lines: country,host,port,scheme,username,password,name */
export function parseServers(text) {
  const servers = [], errors = [], seen = new Set();
  const add = (raw, where) => {
    const r = validateServer(raw);
    if (r.error) errors.push(`${where}: ${r.error}`);
    else if (!seen.has(r.server.id)) { seen.add(r.server.id); servers.push(r.server); }
  };
  const body = String(text || '').trim();
  if (!body) return { servers, errors: ['Nothing to import'] };
  if (body[0] === '[' || body[0] === '{') {
    let data;
    try { data = JSON.parse(body); } catch (e) { return { servers, errors: ['Not valid JSON: ' + e.message] }; }
    const list = Array.isArray(data) ? data : data.servers;
    if (!Array.isArray(list)) return { servers, errors: ['Expected a JSON array of servers'] };
    list.forEach((raw, i) => add(raw || {}, `Entry ${i + 1}`));
  } else {
    body.split(/\r?\n/).forEach((line, i) => {
      const t = line.trim();
      if (!t || t.startsWith('#')) return;
      const parts = t.split(',');
      const [country, host, port, scheme, username, password] = parts.slice(0, 6).map(x => x.trim());
      if (i === 0 && /^country$/i.test(country)) return;   // header row
      add({ country, host, port, scheme, username, password, name: parts.slice(6).join(',').trim() }, `Line ${i + 1}`);
    });
  }
  return { servers, errors };
}

// ---------- proxy auto-config ----------
/** Everything except local/private destinations goes through the proxy. With killSwitch there is no
 *  DIRECT fallback, so if the proxy dies traffic stops instead of leaking from your real IP. */
export function buildPac(server, killSwitch = true) {
  const v = validateServer(server);
  if (v.error) throw new Error(v.error);
  const { scheme, host, port } = v.server;
  const kind = { https: 'HTTPS', http: 'PROXY', socks5: 'SOCKS5' }[scheme];
  const target = `${kind} ${host}:${port}${killSwitch ? '' : '; DIRECT'}`;
  return `function FindProxyForURL(url, host) {
  if (isPlainHostName(host) || host === "localhost" || shExpMatch(host, "*.local") || shExpMatch(host, "*.lan") ||
      shExpMatch(host, "*.internal") || shExpMatch(host, "*.home.arpa")) return "DIRECT";
  if (/^\\d+\\.\\d+\\.\\d+\\.\\d+$/.test(host) && (isInNet(host, "10.0.0.0", "255.0.0.0") ||
      isInNet(host, "127.0.0.0", "255.0.0.0") || isInNet(host, "169.254.0.0", "255.255.0.0") ||
      isInNet(host, "172.16.0.0", "255.240.0.0") || isInNet(host, "192.168.0.0", "255.255.0.0"))) return "DIRECT";
  return "${target}";
}`;
}

// ---------- verification ----------
const PROVIDERS = [
  { url: 'https://ipinfo.io/json', map: d => ({ ip: d.ip, country: d.country, city: d.city, org: d.org }) },
  { url: 'https://ipwho.is/', map: d => {
      if (d.success === false) throw new Error('lookup refused');
      return { ip: d.ip, country: d.country_code, city: d.city, org: d.connection && d.connection.isp };
  } }
];

export async function lookupIp(fetchFn = fetch, timeoutMs = 8000) {
  let last;
  for (const p of PROVIDERS) {
    const ac = new AbortController();
    const timer = setTimeout(() => ac.abort(), timeoutMs);
    try {
      const res = await fetchFn(p.url, { signal: ac.signal, cache: 'no-store' });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const info = p.map(await res.json());
      if (!info.ip) throw new Error('no IP in response');
      return { ...info, country: String(info.country || '').toUpperCase() };
    } catch (e) { last = e; } finally { clearTimeout(timer); }
  }
  throw last || new Error('lookup failed');
}

/** baseline = your IP before connecting, via = IP seen through the proxy, expected = ISO code */
export function judge(baseline, via, expected) {
  if (!via) return { level: 'fail', text: 'No response through the proxy.' };
  if (baseline && baseline.ip === via.ip) {
    return { level: 'fail', text: `Your IP address did not change (${via.ip}), so traffic is not going through the proxy.` };
  }
  if (via.country === expected) return { level: 'ok', text: `Verified: traffic exits in ${countryName(expected)}.` };
  return { level: 'warn', text: `Your IP changed, but it geolocates to ${countryName(via.country) || via.country || 'an unknown place'}, not ${countryName(expected)}. IP databases sometimes disagree, or the server may not be where it claims.` };
}

// ---------- free servers via a local client (sing-box) ----------
// Chrome can only talk HTTP/HTTPS/SOCKS5 proxies. VLESS/VMess/Trojan/Shadowsocks servers need a local client
// (sing-box) that exposes one SOCKS5 port and a controller API. ShieldKit switches country groups through it.
export const BRIDGE = { api: 'http://127.0.0.1:9090', port: 2080, selector: 'proxy' };

/** Only loopback controller addresses are accepted, so nothing is ever sent to a remote machine. */
export function validApi(text) {
  try {
    const u = new URL(String(text || '').trim());
    return u.protocol === 'http:' && (u.hostname === '127.0.0.1' || u.hostname === 'localhost') ? u.origin : null;
  } catch { return null; }
}

async function timed(fetchFn, url, opts = {}, ms = 4000) {
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), ms);
  try { return await fetchFn(url, { ...opts, signal: ac.signal }); } finally { clearTimeout(timer); }
}

export async function bridgeCountries(api = BRIDGE.api, fetchFn = fetch) {
  let res;
  try { res = await timed(fetchFn, `${api}/proxies`); }
  catch (e) { throw new Error(`Cannot reach the local client at ${api}. Start it first (see the steps above).`); }
  if (!res.ok) throw new Error(`The local client answered with HTTP ${res.status}.`);
  const { proxies = {} } = await res.json();
  const out = [];
  for (const [name, p] of Object.entries(proxies)) {
    const m = /^country-([A-Z]{2})$/.exec(name);
    if (m && COUNTRY_CODES.includes(m[1]) && Array.isArray(p.all) && p.all.length) out.push({ code: m[1], group: name, nodes: p.all.length });
  }
  if (!out.length) throw new Error('The local client has no country groups. Create its config with tools/subscription_to_singbox.py.');
  return out;
}

export async function bridgeSelect(api, group, fetchFn = fetch, selector = BRIDGE.selector) {
  const res = await timed(fetchFn, `${api}/proxies/${encodeURIComponent(selector)}`, {
    method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: group })
  });
  if (!res.ok) throw new Error(`The local client refused ${group} (HTTP ${res.status}).`);
}

export const bridgeServers = (countries, port) => countries.map(c => ({
  id: `BRIDGE-${c.code}`, country: c.code, scheme: 'socks5', host: '127.0.0.1', port, username: '', password: '',
  name: `Free server (${c.nodes} available)`, bridge: true, group: c.group
}));
