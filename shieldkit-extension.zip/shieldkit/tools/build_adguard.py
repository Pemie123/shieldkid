"""Rebuilds rules/adguard.json and cosmetic-list.js from upstream filters.
  npm install @adguard/dnr-rulesets   (in any folder; point SRC at it)
  python3 tools/build_adguard.py
"""
import json, re, urllib.request, os
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
SRC = os.environ.get('ADGUARD_SRC', 'node_modules/@adguard/dnr-rulesets/dist/filters/chromium-mv3/declarative/ruleset_2/ruleset_2.json')

rules = json.load(open(SRC))
for r in rules:
    r.pop('metadata', None)
    if r['action']['type'] == 'redirect' and 'extensionPath' in r['action'].get('redirect', {}):
        r['action'] = {'type': 'block'}            # neutered-script resources are not bundled
json.dump(rules, open(os.path.join(ROOT, 'rules/adguard.json'), 'w'), separators=(',', ':'))

url = 'https://raw.githubusercontent.com/easylist/easylist/master/easylist/easylist_general_hide.txt'
pat = re.compile(r'^##(\.[A-Za-z_][\w-]*|#[A-Za-z_][\w-]*)$')
sel = sorted({m.group(1) for l in urllib.request.urlopen(url).read().decode('utf-8', 'ignore').splitlines()
              if (m := pat.match(l.strip()))})
with open(os.path.join(ROOT, 'cosmetic-list.js'), 'w') as f:
    f.write('const SK_SELECTORS = ' + json.dumps(sel, separators=(',', ':')) + ';\n')
print(len(rules), 'rules,', len(sel), 'selectors')
