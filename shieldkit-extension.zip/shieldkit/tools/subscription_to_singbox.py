#!/usr/bin/env python3
"""Turn public VLESS / VMess / Trojan / Shadowsocks / Hysteria2 subscription lists into a sing-box config
that ShieldKit can drive.

  python3 tools/subscription_to_singbox.py --out shieldkit-singbox.json
  sing-box run -c shieldkit-singbox.json

The config opens a local proxy on 127.0.0.1:2080 and a controller on 127.0.0.1:9090. It has one group per
country (country-BE, country-NL, ...) that automatically uses the fastest working server in that country.
ShieldKit's Location page loads those groups, selects one and verifies the result.

By default it reads the repo https://github.com/Hidashimora/free-vpn-anti-rkn (the short lists). Use --url or
--file to add your own subscriptions. Pass --singbox /path/to/sing-box to have every server validated by
sing-box itself so entries it cannot parse are dropped.
"""
import argparse, base64, collections, concurrent.futures, json, os, re, shutil, subprocess, sys, tempfile
import urllib.request
from urllib.parse import urlsplit, parse_qs, unquote

RAW = "https://raw.githubusercontent.com/Hidashimora/free-vpn-anti-rkn/main/configs/"
DEFAULT_LISTS = [f"{i}.1" for i in range(1, 27)] + ["27", "28.1", "29", "30", "31", "32.1", "33.1", "34"]
UTLS = {"chrome", "firefox", "edge", "safari", "360", "qq", "ios", "android", "random", "randomized"}
VMESS_SEC = {"auto", "none", "zero", "aes-128-gcm", "chacha20-poly1305"}
FLAG = re.compile(r"[\U0001F1E6-\U0001F1FF]{2}")


class Unsupported(Exception):
    pass


# ------------------------------------------------------------------ helpers
def b64(s):
    s = s.strip().replace("-", "+").replace("_", "/")
    return base64.b64decode(s + "=" * (-len(s) % 4)).decode("utf-8", "ignore")


def country_of(remark):
    m = FLAG.search(remark or "")
    return "".join(chr(ord(c) - 0x1F1E6 + 65) for c in m.group(0)) if m else None


def truthy(v):
    return str(v).lower() in ("1", "true", "yes")


def tls_block(q, default_on, host_for_sni=None):
    sec = q.get("security", "tls" if default_on else "none")
    if sec in ("", "none"):
        return None
    if sec not in ("tls", "reality", "xtls"):
        raise Unsupported("security " + sec)
    tls = {"enabled": True}
    sni = q.get("sni") or q.get("peer") or host_for_sni
    if sni:
        tls["server_name"] = sni
    if truthy(q.get("allowInsecure", q.get("insecure", "0"))):
        tls["insecure"] = True
    if q.get("alpn"):
        tls["alpn"] = [a for a in q["alpn"].split(",") if a]
    fp = q.get("fp")
    if sec == "reality":
        if not q.get("pbk"):
            raise Unsupported("reality without key")
        tls["reality"] = {"enabled": True, "public_key": q["pbk"], "short_id": q.get("sid", "")}
        tls["utls"] = {"enabled": True, "fingerprint": fp if fp in UTLS else "chrome"}
    elif fp in UTLS:
        tls["utls"] = {"enabled": True, "fingerprint": fp}
    return tls


def transport_block(q):
    t = (q.get("type") or "tcp").lower()
    host, path = q.get("host"), q.get("path")
    if t in ("tcp", "raw", ""):
        if (q.get("headerType") or "none") != "none":
            raise Unsupported("tcp header obfuscation")
        return None
    if t == "ws":
        tr = {"type": "ws", "path": path or "/"}
        if host:
            tr["headers"] = {"Host": host}
        return tr
    if t == "grpc":
        return {"type": "grpc", "service_name": q.get("serviceName") or path or ""}
    if t in ("http", "h2"):
        tr = {"type": "http", "path": path or "/"}
        if host:
            tr["host"] = [h for h in host.split(",") if h]
        return tr
    if t == "httpupgrade":
        tr = {"type": "httpupgrade", "path": path or "/"}
        if host:
            tr["host"] = host
        return tr
    raise Unsupported("transport " + t)


def qparams(u):
    return {k: v[0] for k, v in parse_qs(u.query, keep_blank_values=True).items()}


# ------------------------------------------------------------------ protocol parsers -> (outbound, remark)
def parse_vless(link):
    u = urlsplit(link); q = qparams(u)
    if q.get("encryption", "none") not in ("none", ""):
        raise Unsupported("vless encryption")
    ob = {"type": "vless", "server": u.hostname, "server_port": u.port, "uuid": unquote(u.username or "")}
    if q.get("flow"):
        ob["flow"] = q["flow"]
    tls = tls_block(q, False, q.get("host") if (q.get("type") == "ws" and q.get("security") == "tls") else None)
    if tls:
        ob["tls"] = tls
    tr = transport_block(q)
    if tr:
        ob["transport"] = tr
    return ob, unquote(u.fragment)


def parse_vmess(link):
    j = json.loads(b64(link[len("vmess://"):]))
    net = (j.get("net") or "tcp").lower()
    q = {"type": net, "host": j.get("host") or None, "path": j.get("path") or None,
         "serviceName": j.get("path") or None, "headerType": j.get("type") if net == "tcp" else "none"}
    q = {k: v for k, v in q.items() if v is not None}
    scy = j.get("scy") or "auto"
    ob = {"type": "vmess", "server": j["add"], "server_port": int(j["port"]), "uuid": j["id"],
          "security": scy if scy in VMESS_SEC else "auto", "alter_id": int(j.get("aid") or 0)}
    if str(j.get("tls", "")).lower() in ("tls", "1", "true"):
        tq = {"security": "tls", "sni": j.get("sni") or j.get("host") or None, "alpn": j.get("alpn") or None,
              "fp": j.get("fp") or None, "allowInsecure": j.get("allowInsecure", "0")}
        ob["tls"] = tls_block({k: v for k, v in tq.items() if v}, True)
    tr = transport_block(q)
    if tr:
        ob["transport"] = tr
    return ob, j.get("ps", "")


def parse_trojan(link):
    u = urlsplit(link); q = qparams(u)
    ob = {"type": "trojan", "server": u.hostname, "server_port": u.port, "password": unquote(u.username or "")}
    ob["tls"] = tls_block(q, True, q.get("host") if q.get("type") == "ws" else None) or {"enabled": False}
    tr = transport_block(q)
    if tr:
        ob["transport"] = tr
    return ob, unquote(u.fragment)


def parse_ss(link):
    body = link[len("ss://"):]
    body, _, frag = body.partition("#")
    body, _, query = body.partition("?")
    if "plugin" in query:
        raise Unsupported("ss plugin")
    if "@" in body:
        userinfo, hostport = body.rsplit("@", 1)
        creds = unquote(userinfo) if ":" in unquote(userinfo) else b64(unquote(userinfo))
    else:
        decoded = b64(unquote(body))
        creds, hostport = decoded.rsplit("@", 1)
    method, password = creds.split(":", 1)
    host, port = hostport.rsplit(":", 1)
    return ({"type": "shadowsocks", "server": host.strip("[]"), "server_port": int(port),
             "method": method, "password": password}, unquote(frag))


def parse_hy2(link):
    u = urlsplit(link.replace("hy2://", "hysteria2://", 1)); q = qparams(u)
    ob = {"type": "hysteria2", "server": u.hostname, "server_port": u.port, "password": unquote(u.username or ""),
          "tls": {"enabled": True}}
    if q.get("sni"):
        ob["tls"]["server_name"] = q["sni"]
    if truthy(q.get("insecure", "0")):
        ob["tls"]["insecure"] = True
    if q.get("obfs"):
        ob["obfs"] = {"type": q["obfs"], "password": q.get("obfs-password", "")}
    return ob, unquote(u.fragment)


PARSERS = {"vless": parse_vless, "vmess": parse_vmess, "trojan": parse_trojan, "ss": parse_ss,
           "hysteria2": parse_hy2, "hy2": parse_hy2}


def parse_link(link):
    scheme = link.split("://", 1)[0].lower()
    if scheme not in PARSERS:
        raise Unsupported("protocol " + scheme)
    ob, remark = PARSERS[scheme](link)
    if not ob.get("server") or not ob.get("server_port"):
        raise Unsupported("missing host or port")
    return ob, remark


# ------------------------------------------------------------------ fetching
def fetch(src):
    if os.path.exists(src):
        return open(src, encoding="utf-8", errors="ignore").read()
    req = urllib.request.Request(src, headers={"User-Agent": "shieldkit-converter"})
    with urllib.request.urlopen(req, timeout=40) as r:
        return r.read().decode("utf-8", "ignore")


def links_from(text):
    t = text.strip()
    if t and "://" not in t.splitlines()[0]:
        try:
            t = b64(t)
        except Exception:
            pass
    return [l.strip() for l in t.splitlines() if "://" in l and not l.lstrip().startswith("#")]


# ------------------------------------------------------------------ validation with sing-box itself
def valid_with_singbox(singbox, ob):
    with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
        json.dump({"outbounds": [ob]}, f)
        path = f.name
    try:
        r = subprocess.run([singbox, "check", "-c", path], capture_output=True, timeout=20)
        return r.returncode == 0
    except Exception:
        return False
    finally:
        os.unlink(path)


# ------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--lists", default=",".join(DEFAULT_LISTS), help="repo list names, e.g. 1.1,5.1,27 (default: all short lists)")
    ap.add_argument("--url", action="append", default=[], help="extra subscription URL (repeatable)")
    ap.add_argument("--file", action="append", default=[], help="local subscription file (repeatable)")
    ap.add_argument("--per-country", type=int, default=8, help="max servers kept per country (default 8)")
    ap.add_argument("--port", type=int, default=2080, help="local proxy port (default 2080)")
    ap.add_argument("--api", default="127.0.0.1:9090", help="controller address (default 127.0.0.1:9090)")
    ap.add_argument("--singbox", default=shutil.which("sing-box"), help="sing-box binary used to validate servers")
    ap.add_argument("--out", default="shieldkit-singbox.json")
    a = ap.parse_args()

    sources = [RAW + n.strip() + ".txt" for n in a.lists.split(",") if n.strip()] + a.url + a.file
    seen, nodes, skipped = set(), [], collections.Counter()
    for src in sources:
        try:
            links = links_from(fetch(src))
        except Exception as e:
            print(f"  ! {src}: {e}", file=sys.stderr); continue
        for link in links:
            try:
                ob, remark = parse_link(link)
            except Unsupported as e:
                skipped[str(e)] += 1; continue
            except Exception:
                skipped["malformed"] += 1; continue
            cc = country_of(remark)
            if not cc:
                skipped["no country flag in name"] += 1; continue
            key = (ob["type"], ob["server"], ob["server_port"], ob.get("uuid") or ob.get("password"))
            if key in seen:
                continue
            seen.add(key); nodes.append((cc, ob))
    print(f"parsed {len(nodes)} unique servers from {len(sources)} lists; skipped: {dict(skipped)}")

    # spread picks evenly across each country's servers, then validate
    by_cc = collections.defaultdict(list)
    for cc, ob in nodes:
        by_cc[cc].append(ob)
    picked = []
    for cc, obs in by_cc.items():
        step = max(1, len(obs) // a.per_country)
        for ob in obs[::step][: a.per_country * 2]:       # take extra so validation drops don't empty a country
            picked.append((cc, ob))
    if a.singbox:
        with concurrent.futures.ThreadPoolExecutor(8) as ex:
            ok = list(ex.map(lambda p: valid_with_singbox(a.singbox, p[1]), picked))
        dropped = ok.count(False)
        picked = [p for p, good in zip(picked, ok) if good]
        print(f"sing-box validation dropped {dropped} servers it cannot use")
    else:
        print("note: sing-box not found, servers were not validated (use --singbox PATH)")

    groups = collections.defaultdict(list)
    outbounds = []
    for cc, ob in picked:
        if len(groups[cc]) >= a.per_country:
            continue
        ob = dict(ob, tag=f"{cc}-{len(groups[cc]) + 1:02d}")
        groups[cc].append(ob["tag"]); outbounds.append(ob)

    test = {"url": "https://www.gstatic.com/generate_204", "interval": "3m", "tolerance": 50}
    order = sorted(groups, key=lambda c: (-len(groups[c]), c))
    cfg = {
        "log": {"level": "warn"},
        "experimental": {"clash_api": {"external_controller": a.api}},
        "inbounds": [{"type": "mixed", "tag": "in", "listen": "127.0.0.1", "listen_port": a.port}],
        "outbounds": (
            [{"type": "selector", "tag": "proxy", "outbounds": [f"country-{c}" for c in order], "default": f"country-{order[0]}"}]
            + [dict(type="urltest", tag=f"country-{c}", outbounds=groups[c], **test) for c in order]
            + outbounds + [{"type": "direct", "tag": "direct"}]
        ),
        "route": {"final": "proxy"},
    } if order else None
    if not cfg:
        sys.exit("no usable servers found")
    with open(a.out, "w") as f:
        json.dump(cfg, f, indent=1)
    print(f"wrote {a.out}: {len(outbounds)} servers in {len(order)} countries")
    print("  " + ", ".join(f"{c}:{len(groups[c])}" for c in order[:30]) + (" ..." if len(order) > 30 else ""))
    print(f"\nRun it with:  sing-box run -c {a.out}\nThen open ShieldKit > Location > Free servers and press Load countries.")


if __name__ == "__main__":
    main()
