"""Regenerates rules/*.json. Edit the lists below, run `python3 tools/generate_rules.py`,
then click the reload icon for ShieldKit on chrome://extensions."""
import json, os

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "rules")
os.makedirs(OUT, exist_ok=True)

SUB = ["sub_frame", "script", "image", "xmlhttprequest", "stylesheet",
       "media", "font", "ping", "websocket", "other"]

ADS = """doubleclick.net googlesyndication.com googleadservices.com adservice.google.com
pagead2.googlesyndication.com adnxs.com taboola.com outbrain.com criteo.com criteo.net
pubmatic.com rubiconproject.com openx.net advertising.com adsrvr.org casalemedia.com
moatads.com amazon-adsystem.com smartadserver.com media.net revcontent.com mgid.com
popads.net popcash.net propellerads.com adsterra.com exoclick.com juicyads.com
trafficjunky.com yieldmo.com 33across.com sharethrough.com teads.tv adform.net
bidswitch.net contextweb.com lijit.com indexww.com spotxchange.com springserve.com
serving-sys.com zedo.com adcolony.com adroll.com yieldlab.net improvedigital.com
richaudience.com smaato.net inmobi.com applovin.com
ads.yahoo.com adtech.com advertising.yahoo.com tribalfusion.com undertone.com
adsafeprotected.com doubleverify.com ad.gt gumgum.com triplelift.com
onetag-sys.com id5-sync.com adition.com weborama.com""".split()

TRACKERS = """google-analytics.com scorecardresearch.com quantserve.com hotjar.com
hotjar.io fullstory.com mouseflow.com crazyegg.com luckyorange.com clicktale.net
inspectlet.com mixpanel.com segment.io heapanalytics.com amplitude.com
bluekai.com krxd.net demdex.net omtrdc.net everesttech.net bat.bing.com
analytics.tiktok.com ads-twitter.com static.ads-twitter.com snap.licdn.com
px.ads.linkedin.com tapad.com agkn.com rlcdn.com
chartbeat.net nr-data.net branch.io adjust.com appsflyer.com kochava.com
tiqcdn.com optimizely.com fingerprintjs.com statcounter.com addthis.com sharethis.com""".split()

MINERS = """coinhive.com coin-hive.com jsecoin.com cryptoloot.pro crypto-loot.com
webminepool.com minero.cc authedmine.com coinimp.com ppoi.org coinerra.com
miner.pr0gramm.com monerominer.rocks minemytraffic.com papoto.com
webmine.cz mataharirama.xyz freecontent.date""".split()

def write(name, rules):
    for i, r in enumerate(rules, 1):
        r["id"] = i
    with open(os.path.join(OUT, name), "w") as f:
        json.dump(rules, f, indent=1)

def block(domains, types=SUB, third=True):
    cond = {"requestDomains": domains, "resourceTypes": types}
    if third:
        cond["domainType"] = "thirdParty"
    return {"priority": 1, "action": {"type": "block"}, "condition": cond}

write("ads.json", [
    block(ADS),
    {"priority": 1, "action": {"type": "block"},
     "condition": {"regexFilter": r"^https?://(www\.|m\.)?youtube\.com/(api/stats/ads|pagead/|get_midroll_|youtubei/v1/player/ad_break)",
                   "resourceTypes": ["xmlhttprequest", "image", "ping", "script", "sub_frame", "other"]}},
])
write("trackers.json", [
    block(TRACKERS),
    {"priority": 1, "action": {"type": "block"},
     "condition": {"urlFilter": "||connect.facebook.net/*/fbevents.js", "resourceTypes": ["script"]}},
])
write("malware.json", [block(MINERS, third=False)])

def qt(key, value):
    return {"type": "redirect", "redirect": {"transform": {"queryTransform": {
        "addOrReplaceParams": [{"key": key, "value": value}]}}}}

write("safesearch.json", [
    {"priority": 1, "action": qt("safe", "active"),
     "condition": {"regexFilter": r"^https?://(www\.)?google\.[a-z.]{2,6}/search",
                   "resourceTypes": ["main_frame", "sub_frame", "xmlhttprequest"]}},
    {"priority": 1, "action": qt("adlt", "strict"),
     "condition": {"regexFilter": r"^https?://(www\.)?bing\.com/search",
                   "resourceTypes": ["main_frame", "sub_frame", "xmlhttprequest"]}},
    {"priority": 1, "action": qt("kp", "1"),
     "condition": {"regexFilter": r"^https?://(www\.)?duckduckgo\.com/\?",
                   "resourceTypes": ["main_frame", "sub_frame"]}},
    {"priority": 1,
     "action": {"type": "modifyHeaders", "requestHeaders": [
         {"header": "YouTube-Restrict", "operation": "set", "value": "Moderate"}]},
     "condition": {"requestDomains": ["youtube.com"],
                   "resourceTypes": ["main_frame", "sub_frame", "xmlhttprequest"]}},
])

LOCAL = (r"^http://((192\.168|10|127)\.[0-9.]+|172\.(1[6-9]|2[0-9]|3[01])\.[0-9.]+|"
         r"localhost|[^/:]*\.(local|lan|home|internal))([:/]|$)")
write("https.json", [
    {"priority": 1, "action": {"type": "upgradeScheme"},
     "condition": {"urlFilter": "|http://", "resourceTypes": ["main_frame"] + SUB}},
    {"priority": 2, "action": {"type": "allow"},
     "condition": {"regexFilter": LOCAL, "resourceTypes": ["main_frame"] + SUB}},
])

PARAMS = ["utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content", "utm_id",
          "fbclid", "gclid", "dclid", "msclkid", "mc_eid", "igshid", "yclid", "twclid",
          "ttclid", "_hsenc", "_hsmi", "ref_src"]
write("strip.json", [
    {"priority": 1,
     "action": {"type": "redirect", "redirect": {"transform": {"queryTransform": {"removeParams": PARAMS}}}},
     "condition": {"regexFilter": r"[?&](utm_(source|medium|campaign|term|content|id)|fbclid|gclid|dclid|msclkid|mc_eid|igshid|yclid|twclid|ttclid|_hsenc|_hsmi|ref_src)=",
                   "excludedRequestDomains": ["ads.google.com", "analytics.google.com"],
                   "resourceTypes": ["main_frame"]}},
])

write("privacy.json", [
    {"priority": 1,
     "action": {"type": "modifyHeaders", "requestHeaders": [
         {"header": "Sec-GPC", "operation": "set", "value": "1"},
         {"header": "DNT", "operation": "set", "value": "1"}]},
     "condition": {"resourceTypes": ["main_frame"] + SUB}},
])
print("rules written to", os.path.abspath(OUT))
