const params = new URLSearchParams(location.search);
const target = params.get('url') || '';
const reasons = (params.get('reasons') || '').split('|').filter(Boolean);

document.getElementById('target').textContent = target;
const list = document.getElementById('reasons');
for (const r of reasons) { const li = document.createElement('li'); li.textContent = r; list.appendChild(li); }

document.getElementById('back').addEventListener('click', () => {
  if (history.length > 1) history.back();
  else chrome.tabs.getCurrent(t => chrome.tabs.update(t.id, { url: 'chrome://newtab' }));
});

document.getElementById('proceed').addEventListener('click', async () => {
  try {
    const host = new URL(target).hostname.toLowerCase();
    const { allowed = [] } = await chrome.storage.session.get('allowed');
    allowed.push(host);
    await chrome.storage.session.set({ allowed });
    location.href = target;
  } catch { /* malformed URL: stay on the warning */ }
});
