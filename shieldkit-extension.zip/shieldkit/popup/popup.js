import { getSettings, setSettings, getStats } from '../shared.js';

const GROUPS = [
  { title: 'Blocking', items: [
    ['ads', 'Ads', 'Ad networks, banners and pop-under scripts'],
    ['youtube', 'YouTube ads', 'Video, banner and feed ads. Turn off if YouTube misbehaves'],
    ['trackers', 'Trackers', 'Analytics, session recorders, fingerprinting'],
    ['malware', 'Malicious domains', 'Crypto-miners and known bad hosts']
  ]},
  { title: 'Safety', items: [
    ['phishing', 'Phishing warnings', 'Look-alike and suspicious websites'],
    ['downloads', 'Safe downloads', 'Disguised files, bad sites, programs over HTTP'],
    ['downloadsStrict', 'Strict download checks', 'Also block every program, script and archive over HTTP'],
    ['https', 'Force HTTPS', 'Upgrade insecure connections']
  ]},
  { title: 'Site info', items: [
    ['ratings', 'Site ratings', 'One combined rating from Trustpilot, Sitejabber, Reviews.io and Google'],
    ['ratingsTitle', 'Rating in tab title', 'Shows ★4.3 on the tab and when you hover it']
  ]},
  { title: 'Search', items: [
    ['safesearch', 'Strict SafeSearch', 'Google, Bing, DuckDuckGo, YouTube Restricted Mode']
  ]},
  { title: 'Privacy', items: [
    ['stripParams', 'Clean links', 'Remove utm_, fbclid, gclid and similar'],
    ['privacyHeaders', 'Privacy signals', 'Send Global Privacy Control and Do Not Track'],
    ['webrtc', 'Stop IP leaks', 'Hide your local IP address from WebRTC']
  ]}
];

async function currentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function siteHost(tab) {
  try {
    const u = new URL(tab.url);
    return /^https?:$/.test(u.protocol) ? u.hostname.replace(/^www\./, '') : '';
  } catch { return ''; }
}

async function renderHero() {
  const tab = await currentTab();
  const host = tab ? siteHost(tab) : '';
  const pauseBtn = document.getElementById('pause');
  document.getElementById('host').textContent = host || 'This page can’t be filtered';
  if (!host) { pauseBtn.hidden = true; document.getElementById('count').textContent = '–'; return; }

  try {
    const { tabRatings = {} } = await chrome.storage.session.get('tabRatings');
    const r = tabRatings[tab.id];
    if (r && r.combined) document.getElementById('ratingLine').textContent = `★ ${r.combined.score.toFixed(1)} ${r.combined.label} · ${r.combined.sources} source${r.combined.sources > 1 ? 's' : ''}`;
  } catch (e) { /* session storage unavailable */ }
  const { paused = [] } = await chrome.storage.local.get('paused');
  const isPaused = paused.includes(host);
  document.body.classList.toggle('is-paused', isPaused);
  document.getElementById('countLabel').textContent = isPaused ? 'protection paused' : 'blocked on this page';
  document.getElementById('count').textContent = isPaused ? '' : (parseInt(await chrome.action.getBadgeText({ tabId: tab.id }), 10) || 0);
  pauseBtn.textContent = isPaused ? 'Resume' : 'Pause';
  pauseBtn.title = isPaused ? `Turn protection back on for ${host}` : `Turn protection off for ${host}`;

  pauseBtn.onclick = async () => {
    const next = isPaused ? paused.filter(h => h !== host) : [...paused, host];
    await chrome.storage.local.set({ paused: next });
    setTimeout(async () => { await chrome.tabs.reload(tab.id); window.close(); }, 400);
  };
}

async function renderToggles() {
  const settings = await getSettings();
  const root = document.getElementById('groups');
  for (const group of GROUPS) {
    const section = document.createElement('section');
    section.className = 'group';
    const h = document.createElement('h2'); h.textContent = group.title;
    const card = document.createElement('div'); card.className = 'card';
    for (const [key, name, desc] of group.items) {
      const row = document.createElement('label'); row.className = 'row';
      const text = document.createElement('div');
      const n = document.createElement('div'); n.className = 'name'; n.textContent = name;
      const d = document.createElement('div'); d.className = 'desc'; d.textContent = desc;
      text.append(n, d);
      const sw = document.createElement('span'); sw.className = 'switch';
      const input = document.createElement('input'); input.type = 'checkbox'; input.checked = !!settings[key];
      input.addEventListener('change', () => setSettings({ [key]: input.checked }));
      const track = document.createElement('span'); track.className = 'track';
      sw.append(input, track);
      row.append(text, sw);
      card.append(row);
    }
    section.append(h, card);
    root.append(section);
  }
}

async function renderStats() {
  const s = await getStats();
  const { heavyStatus } = await chrome.storage.local.get('heavyStatus');
  const note = document.getElementById('note');
  if (heavyStatus === 'unavailable') {
    note.hidden = false;
    note.textContent = 'The full ad list could not load (Chrome’s shared rule limit is used up by other extensions). Disable another ad blocker and reload ShieldKit.';
  }
  document.getElementById('stats').textContent =
    `${s.warnings} site warning${s.warnings === 1 ? '' : 's'} and ${s.downloads} blocked download${s.downloads === 1 ? '' : 's'} so far`;
}

async function renderLocation() {
  const { vpn, vpnServers = [] } = await chrome.storage.local.get(['vpn', 'vpnServers']);
  const server = vpn && vpnServers.find(s => s.id === vpn.activeId);
  const el = document.getElementById('locState');
  if (server) {
    const ok = vpn.last && vpn.last.verdict && vpn.last.verdict.level === 'ok';
    el.textContent = `${server.country} · ${server.name}${ok ? ' · verified' : ''}`;
  }
  document.getElementById('locBtn').textContent = server ? 'Manage' : 'Choose';
  document.getElementById('locBtn').addEventListener('click', () => { chrome.tabs.create({ url: chrome.runtime.getURL('vpn.html') }); window.close(); });
}

document.getElementById('optLink').addEventListener('click', e => { e.preventDefault(); chrome.runtime.openOptionsPage(); window.close(); });

renderHero(); renderToggles(); renderStats(); renderLocation();
