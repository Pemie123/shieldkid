import { testGoogleKey, SERVICES, lookupService, lookupGoogle, registrableDomain } from './ratings-core.js';

const $ = id => document.getElementById(id);
const say = (text, level = '') => { $('msg').textContent = text; $('msg').className = level; };

async function dropGoogleCache() {
  const { ratingsCache = {} } = await chrome.storage.local.get('ratingsCache');
  for (const k of Object.keys(ratingsCache)) if (k.startsWith('g:')) delete ratingsCache[k];
  await chrome.storage.local.set({ ratingsCache });
}

chrome.storage.local.get('googleKey').then(({ googleKey }) => { if (googleKey) $('key').placeholder = 'A key is saved (hidden)'; });

$('save').addEventListener('click', async () => {
  const key = $('key').value.trim();
  if (!/^[\w-]{20,}$/.test(key)) return say('That does not look like a Google API key.', 'bad');
  await chrome.storage.local.set({ googleKey: key });
  await dropGoogleCache();
  $('key').value = ''; $('key').placeholder = 'A key is saved (hidden)';
  say('Key saved. Google ratings appear the next time you open a site.', 'ok');
});

$('test').addEventListener('click', async () => {
  const key = $('key').value.trim() || (await chrome.storage.local.get('googleKey')).googleKey;
  if (!key) return say('Paste a key first.', 'bad');
  say('Testing…');
  const r = await testGoogleKey(key);
  say(r.message, r.ok ? 'ok' : 'bad');
});

$('remove').addEventListener('click', async () => {
  await chrome.storage.local.remove('googleKey');
  await dropGoogleCache();
  $('key').value = ''; $('key').placeholder = 'AIza…';
  say('Key removed.');
});

$('clear').addEventListener('click', async () => {
  await chrome.storage.local.remove(['ratingsCache', 'ratingsHidden']);
  say('Saved ratings and hidden sites cleared.', 'ok');
});

// ---- test lookups: what does each service really return?
function describe(name, r) {
  if (r.status === 'ok') return `${name}: ok, ${r.score.toFixed(1)} / 5${r.reviews != null ? `, ${r.reviews} reviews` : ''}`;
  if (r.status === 'none') return `${name}: not listed`;
  if (r.status === 'nokey') return `${name}: no key set`;
  if (r.status === 'badkey') return `${name}: key rejected`;
  return `${name}: FAILED, ${r.note || r.reason || 'error'}${r.snippet ? `\n    page says: "${r.snippet}"` : ''}`;
}

$('testRun').addEventListener('click', async () => {
  const raw = $('testDomain').value.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '').replace(/^www\./, '');
  if (!/^[a-z0-9-]+(\.[a-z0-9-]+)+$/.test(raw)) return say('Enter a domain such as bol.com', 'bad');
  const domain = registrableDomain(raw);
  say(`Testing ${domain}…`); $('testOut').textContent = ''; $('testCopy').hidden = true;
  const { googleKey } = await chrome.storage.local.get('googleKey');
  const lines = [`ShieldKit ratings test for ${domain}`];
  const results = await Promise.all([
    ...SERVICES.map(async sv => describe(sv.name, await lookupService(sv, domain))),
    lookupGoogle(domain, googleKey).then(r => describe('Google', r))
  ]);
  $('testOut').textContent = lines.concat(results).join('\n');
  $('testCopy').hidden = false;
  say('Done.', 'ok');
});

$('testCopy').addEventListener('click', async () => {
  try { await navigator.clipboard.writeText($('testOut').textContent); say('Report copied.', 'ok'); }
  catch (e) { say('Could not copy. Select the text and copy it by hand.', 'bad'); }
});
