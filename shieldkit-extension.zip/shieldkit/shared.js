// Settings shared by the service worker and the popup.
export const DEFAULTS = {
  ads: true,            // ad network blocking + cosmetic hiding
  youtube: true,        // YouTube video, banner and feed ads
  trackers: true,       // analytics / session recorders
  malware: true,        // crypto-miners & known bad domains
  phishing: true,       // look-alike / suspicious site warnings
  downloads: true,      // risky download blocking (relaxed: disguised files, bad sites, programs over HTTP)
  downloadsStrict: false, // strict: every program, script and archive-over-HTTP
  ratings: true,        // combined rating badge (Trustpilot, Sitejabber, Reviews.io, Google)
  ratingsTitle: true,   // put the combined rating at the start of the tab title
  safesearch: true,     // Google / Bing / DuckDuckGo / YouTube
  https: true,          // upgrade http -> https
  stripParams: true,    // remove utm_*, fbclid, gclid ...
  privacyHeaders: true, // Global Privacy Control + DNT
  webrtc: true          // stop local IP leaks
};

// settings key -> static ruleset id declared in manifest.json
export const RULESETS = {
  ads: 'ads',
  trackers: 'trackers',
  malware: 'malware',
  safesearch: 'safesearch',
  https: 'https',
  stripParams: 'strip',
  privacyHeaders: 'privacy'
};

// Large rulesets that may exceed Chrome's shared rule pool. They are enabled separately so a failure
// can never take the small rulesets down with it. settings key -> ruleset id
export const HEAVY_RULESETS = { ads: 'adguard' };

export async function getSettings() {
  const { settings } = await chrome.storage.local.get('settings');
  return { ...DEFAULTS, ...(settings || {}) };
}

export async function setSettings(patch) {
  const current = await getSettings();
  await chrome.storage.local.set({ settings: { ...current, ...patch } });
}

export async function getStats() {
  const { stats } = await chrome.storage.local.get('stats');
  return { warnings: 0, downloads: 0, ...(stats || {}) };
}

export async function bumpStat(key) {
  const stats = await getStats();
  stats[key] = (stats[key] || 0) + 1;
  await chrome.storage.local.set({ stats });
}
