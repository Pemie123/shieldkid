// YouTube, isolated world: switch on/off, hide ad containers, skip any ad that still plays,
// and dismiss the "ad blockers are not allowed" wall.
(async () => {
  const root = document.documentElement;
  let on = true;
  try {
    const { settings, paused = [] } = await chrome.storage.local.get(['settings', 'paused']);
    const h = location.hostname;
    if (settings && (settings.youtube === false || settings.ads === false)) on = false;
    if (paused.some(p => h === p || h.endsWith('.' + p))) on = false;
  } catch (e) { /* keep default */ }
  root.setAttribute('data-sk-yt', on ? 'on' : 'off');   // read by yt-main.js
  if (!on) return;

  const style = document.createElement('style');
  style.textContent = [
    '#masthead-ad', '#player-ads', 'ytd-ad-slot-renderer', 'ytd-in-feed-ad-layout-renderer',
    'ytd-banner-promo-renderer', 'ytd-statement-banner-renderer', 'ytd-primetime-promo-renderer',
    'ytd-display-ad-renderer', 'ytd-promoted-sparkles-web-renderer', 'ytd-promoted-video-renderer',
    'ytd-companion-slot-renderer', 'ytd-action-companion-ad-renderer',
    'ytd-player-legacy-desktop-watch-ads-renderer', 'ytd-rich-item-renderer:has(ytd-ad-slot-renderer)',
    'ytd-rich-section-renderer:has(ytd-statement-banner-renderer)', '.ytp-ad-overlay-container',
    '.ytp-ad-image-overlay', '.ytp-paid-content-overlay', 'ytm-promoted-sparkles-web-renderer',
    'ytm-companion-ad-renderer'
  ].join(',') + '{display:none!important}';
  root.appendChild(style);

  let saved = null;
  const tick = () => {
    const player = document.getElementById('movie_player');
    const video = document.querySelector('video.html5-main-video') || document.querySelector('video');

    if (player && video && player.classList.contains('ad-showing')) {
      if (!saved) saved = { muted: video.muted, rate: video.playbackRate };
      video.muted = true;
      try { video.playbackRate = 16; } catch (e) { /* ignore */ }
      if (isFinite(video.duration) && video.duration > 0 && video.currentTime < video.duration - 0.2) {
        try { video.currentTime = video.duration - 0.1; } catch (e) { /* ignore */ }
      }
      document.querySelectorAll(
        '.ytp-skip-ad-button, .ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-ad-overlay-close-button'
      ).forEach(b => b.click());
    } else if (saved && video) {
      video.muted = saved.muted;
      try { video.playbackRate = saved.rate; } catch (e) { /* ignore */ }
      saved = null;
    }

    const wall = document.querySelector('ytd-enforcement-message-view-model');
    if (wall) {
      const dialog = wall.closest('tp-yt-paper-dialog');
      (dialog || wall).remove();
      document.querySelectorAll('tp-yt-iron-overlay-backdrop').forEach(e => e.remove());
      if (video && video.paused) video.play().catch(() => {});
    }
  };
  setInterval(tick, 250);
})();
