import { getSettings, bumpStat, RULESETS, HEAVY_RULESETS } from './shared.js';
import { assessUrl, assessDownload, hostInSet, isPaused } from './heuristics.js';
import { registrableDomain, shouldLookup, isFresh, SERVICES, lookupService, lookupGoogle, combineRatings, titlePrefix } from './ratings-core.js';

// ------------------------------------------------------------------ setup
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({ id: 'vt', title: 'Check link on VirusTotal', contexts: ['link'] });
  chrome.contextMenus.create({ id: 'gsb', title: 'Check link with Google Safe Browsing', contexts: ['link'] });
  boot();
});
chrome.runtime.onStartup.addListener(boot);

function boot() {
  chrome.declarativeNetRequest.setExtensionActionOptions({ displayActionCountAsBadgeText: true });
  chrome.action.setBadgeBackgroundColor({ color: '#0B7A75' });
  applySettings();
  reconcileVpn();
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && (changes.settings || changes.paused || (changes.vpn && activeChanged(changes.vpn)))) applySettings();
});

function activeChanged(change) {
  return ((change.oldValue || {}).activeId || null) !== ((change.newValue || {}).activeId || null);
}

async function applySettings() {
  const s = await getSettings();
  const { vpn, vpnServers = [] } = await chrome.storage.local.get(['vpn', 'vpnServers']);
  const onFreeServer = !!(vpn && vpn.activeId && (vpnServers.find(x => x.id === vpn.activeId) || {}).bridge);
  const enable = [], disable = [];
  for (const [key, id] of Object.entries(RULESETS)) {
    const on = key === 'https' && onFreeServer ? true : s[key];   // public free servers: never allow plain http
    (on ? enable : disable).push(id);
  }
  await chrome.declarativeNetRequest.updateEnabledRulesets({ enableRulesetIds: enable, disableRulesetIds: disable });

  // Big filter list (~75k rules). Enabled on its own; if Chrome's shared rule pool is full we say so.
  for (const [key, id] of Object.entries(HEAVY_RULESETS)) {
    try {
      await chrome.declarativeNetRequest.updateEnabledRulesets(
        s[key] ? { enableRulesetIds: [id] } : { disableRulesetIds: [id] });
      await chrome.storage.local.set({ heavyStatus: s[key] ? 'on' : 'off' });
    } catch (e) {
      console.warn('ShieldKit: could not enable ' + id, e);
      await chrome.storage.local.set({ heavyStatus: 'unavailable' });
    }
  }

  // While a location is active, WebRTC must not reveal the real IP: force it through the proxy.
  try {
    if (vpn && vpn.activeId) await chrome.privacy.network.webRTCIPHandlingPolicy.set({ value: 'disable_non_proxied_udp' });
    else if (s.webrtc) await chrome.privacy.network.webRTCIPHandlingPolicy.set({ value: 'default_public_interface_only' });
    else await chrome.privacy.network.webRTCIPHandlingPolicy.clear({});
  } catch (e) { /* another extension may control this setting */ }

  // "Pause on this site" = allowAllRequests rule that overrides every other rule
  const { paused = [] } = await chrome.storage.local.get('paused');
  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: existing.map(r => r.id),
    addRules: paused.map((host, i) => ({
      id: i + 1,
      priority: 2000000,
      action: { type: 'allowAllRequests' },
      condition: { requestDomains: [host], resourceTypes: ['main_frame', 'sub_frame'] }
    }))
  });
}

// ------------------------------------------------------------------ malware host list (shared with DNR rules)
let malwareHosts = null;
async function loadMalwareHosts() {
  if (malwareHosts) return malwareHosts;
  try {
    const rules = await (await fetch(chrome.runtime.getURL('rules/malware.json'))).json();
    malwareHosts = new Set(rules.flatMap(r => r.condition.requestDomains || []));
  } catch { malwareHosts = new Set(); }
  return malwareHosts;
}

// ------------------------------------------------------------------ phishing / bad-site interstitial
chrome.webNavigation.onBeforeNavigate.addListener(async details => {
  if (details.frameId !== 0 || !/^https?:/i.test(details.url)) return;
  const s = await getSettings();
  if (!s.phishing && !s.malware) return;

  let url;
  try { url = new URL(details.url); } catch { return; }
  const host = url.hostname.toLowerCase();

  const { allowed = [] } = await chrome.storage.session.get('allowed');
  if (allowed.includes(host)) return;
  const { paused = [] } = await chrome.storage.local.get('paused');
  if (isPaused(host, paused)) return;

  const reasons = [];
  if (s.malware && hostInSet(host, await loadMalwareHosts())) reasons.push('Known malicious or crypto-mining domain');
  if (s.phishing) {
    const r = assessUrl(url);
    if (r.score >= 3) reasons.push(...r.reasons);
  }
  if (!reasons.length) return;

  await bumpStat('warnings');
  const page = chrome.runtime.getURL('warning.html') + '?' + new URLSearchParams({ url: details.url, reasons: reasons.join('|') });
  chrome.tabs.update(details.tabId, { url: page });
});

// ------------------------------------------------------------------ risky downloads
const handled = new Set();

async function inspectDownload(id) {
  if (handled.has(id)) return;
  const s = await getSettings();
  if (!s.downloads) return;
  const [item] = await chrome.downloads.search({ id });
  if (!item) return;

  const { allowedDownloads = [] } = await chrome.storage.session.get('allowedDownloads');
  if (allowedDownloads.includes(item.url) || allowedDownloads.includes(item.finalUrl)) { handled.add(id); return; }

  const { reasons, name } = assessDownload(item, await loadMalwareHosts(), s.downloadsStrict);
  if (!reasons.length) return;
  handled.add(id);

  try { await chrome.downloads.cancel(id); } catch { /* already finished */ }
  if (item.state === 'complete') { try { await chrome.downloads.removeFile(id); } catch { /* gone */ } }
  try { await chrome.downloads.erase({ id }); } catch { /* ignore */ }
  await bumpStat('downloads');

  const nid = `dl-${id}-${Date.now()}`;
  const { pendingDownloads = {} } = await chrome.storage.session.get('pendingDownloads');
  pendingDownloads[nid] = item.url;
  await chrome.storage.session.set({ pendingDownloads });
  chrome.notifications.create(nid, {
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: 'ShieldKit blocked a risky download',
    message: `${name}\n${reasons.join('\n')}`,
    buttons: [{ title: 'Download anyway' }],
    requireInteraction: true
  });
}

chrome.downloads.onCreated.addListener(item => inspectDownload(item.id));
chrome.downloads.onChanged.addListener(delta => {
  if (delta.filename || delta.mime || delta.finalUrl || delta.state) inspectDownload(delta.id);
});

chrome.notifications.onButtonClicked.addListener(async notificationId => {
  const { pendingDownloads = {} } = await chrome.storage.session.get('pendingDownloads');
  const url = pendingDownloads[notificationId];
  if (!url) return;
  const { allowedDownloads = [] } = await chrome.storage.session.get('allowedDownloads');
  allowedDownloads.push(url);
  await chrome.storage.session.set({ allowedDownloads });
  chrome.downloads.download({ url });
  chrome.notifications.clear(notificationId);
});

// ------------------------------------------------------------------ right-click link checks
chrome.contextMenus.onClicked.addListener(info => {
  if (!info.linkUrl) return;
  const target = encodeURIComponent(info.linkUrl);
  const url = info.menuItemId === 'vt'
    ? `https://www.virustotal.com/gui/search/${target}`
    : `https://transparencyreport.google.com/safe-browsing/search?url=${target}`;
  chrome.tabs.create({ url });
});

// ------------------------------------------------------------------ proxy login + state
// Supplies the saved login only to the proxy we configured, and gives up after one wrong attempt.
const authTried = new Set();
chrome.webRequest.onAuthRequired.addListener((details, callback) => {
  (async () => {
    if (!details.isProxy) return callback({});
    const { vpn, vpnServers = [] } = await chrome.storage.local.get(['vpn', 'vpnServers']);
    const server = vpnServers.find(s => vpn && s.id === vpn.activeId);
    if (!server || !server.username || (details.challenger.host || '').toLowerCase() !== server.host) return callback({});
    if (authTried.has(details.requestId)) { authTried.delete(details.requestId); return callback({ cancel: true }); }
    if (authTried.size > 200) authTried.clear();
    authTried.add(details.requestId);
    callback({ authCredentials: { username: server.username, password: server.password } });
  })();
}, { urls: ['<all_urls>'] }, ['asyncBlocking']);

// If the proxy setting was changed or taken over elsewhere, don't keep claiming we are connected.
async function reconcileVpn() {
  try {
    const { vpn } = await chrome.storage.local.get('vpn');
    if (!vpn || !vpn.activeId) return;
    const { levelOfControl, value } = await chrome.proxy.settings.get({});
    if (levelOfControl !== 'controlled_by_this_extension' || value.mode !== 'pac_script') {
      await chrome.storage.local.set({ vpn: { ...vpn, activeId: null, last: null } });
    }
  } catch (e) { /* ignore */ }
}

// ------------------------------------------------------------------ site ratings (Trustpilot + Google)
// Only the registrable domain is sent (never the full address), only for public named sites, never from
// private windows, and answers are cached (7 days when found) so a site is looked up rarely.
const inflight = new Map();

// Writes go through one queue: lookups for several services finish at the same moment, and unqueued
// read-modify-write cycles would overwrite each other's entries.
let cacheQueue = Promise.resolve();
function saveCache(key, v) {
  cacheQueue = cacheQueue.then(async () => {
    const { ratingsCache = {} } = await chrome.storage.local.get('ratingsCache');
    ratingsCache[key] = { t: Date.now(), v };
    const keys = Object.keys(ratingsCache);
    if (keys.length > 600) {                              // keep the cache small: drop the oldest entries
      keys.sort((x, y) => ratingsCache[x].t - ratingsCache[y].t).slice(0, keys.length - 500).forEach(k => delete ratingsCache[k]);
    }
    await chrome.storage.local.set({ ratingsCache });
  }).catch(() => { /* a failed cache write only means one extra lookup later */ });
  return cacheQueue;
}

async function cached(key, produce) {
  if (inflight.has(key)) return inflight.get(key);
  const job = (async () => {
    const { ratingsCache = {} } = await chrome.storage.local.get('ratingsCache');
    if (isFresh(ratingsCache[key])) return ratingsCache[key].v;
    const v = await produce();
    await saveCache(key, v);
    return v;
  })();
  inflight.set(key, job);
  try { return await job; } finally { inflight.delete(key); }
}

// Toolbar-icon tooltip and the popup line show the same combined rating as the page badge.
async function publishForTab(tab, payload) {
  if (!tab || tab.id == null) return;
  const c = payload && payload.combined;
  const detail = payload ? payload.results.filter(x => x.r.status === 'ok').map(x => `${x.name} ${x.r.score.toFixed(1)}`).join(' · ') : '';
  try {
    await chrome.action.setTitle({ tabId: tab.id, title: c ? `ShieldKit: ★${c.score.toFixed(1)} ${c.label} (${c.sources} source${c.sources > 1 ? 's' : ''})\n${detail}` : 'ShieldKit' });
    const { tabRatings = {} } = await chrome.storage.session.get('tabRatings');
    if (payload) tabRatings[tab.id] = { domain: payload.domain, combined: c }; else delete tabRatings[tab.id];
    await chrome.storage.session.set({ tabRatings });
  } catch (e) { /* tab already closed */ }
}
chrome.tabs.onRemoved.addListener(tabId => publishForTab({ id: tabId }, null));

async function handleRatings(sender) {
  if (sender.frameId !== 0 || !sender.url || (sender.tab && sender.tab.incognito)) return { status: 'skip' };
  const s = await getSettings();
  if (!s.ratings) { await publishForTab(sender.tab, null); return { status: 'off' }; }
  let url;
  try { url = new URL(sender.url); } catch { return { status: 'skip' }; }
  if (!/^https?:$/.test(url.protocol)) return { status: 'skip' };
  const host = url.hostname.toLowerCase();
  if (!shouldLookup(host)) { await publishForTab(sender.tab, null); return { status: 'skip' }; }

  const domain = registrableDomain(host.replace(/^www\./, ''));
  const { googleKey } = await chrome.storage.local.get('googleKey');
  const jobs = SERVICES.map(sv => cached(`${sv.id}:${domain}`, () => lookupService(sv, domain)).then(r => ({ id: sv.id, name: sv.name, r })));
  jobs.push(googleKey
    ? cached(`google:${domain}`, () => lookupGoogle(domain, googleKey)).then(r => ({ id: 'google', name: 'Google', r }))
    : Promise.resolve({ id: 'google', name: 'Google', r: { status: 'nokey' } }));
  const results = await Promise.all(jobs);
  const combined = combineRatings(results.filter(x => x.r.status === 'ok').map(x => ({ score: x.r.score, reviews: x.r.reviews })));
  const payload = { status: 'ok', domain, results, combined, title: titlePrefix({ combined, results }) };
  await publishForTab(sender.tab, payload);
  return payload;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== 'ratings') return false;
  handleRatings(sender).then(sendResponse, () => sendResponse({ status: 'error' }));
  return true;                                            // answer asynchronously
});
