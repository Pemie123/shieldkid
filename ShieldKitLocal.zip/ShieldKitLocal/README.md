# ShieldKit Local  (command: `shieldkid`)

The ShieldKit browser extension, as a program for your whole computer. Type **`shieldkid`** in a terminal and it turns on:

- **Ad, tracker, scam and crypto-miner blocking** (about 61,000 domains)
- **Phishing warnings** for look-alike banks and brands (bpost, KBC, Belfius, PayPal, …)
- **Strict SafeSearch** on Google, Bing and DuckDuckGo, and **YouTube Restricted Mode**
- **A location chooser**: send traffic out through a server in another country, verified, with a kill switch
- **Site ratings**: one combined rating from Trustpilot, Sitejabber and Reviews.io (and Google, with your own key)
- A **control panel** in your browser

Everything runs on your computer. Nothing is sent anywhere except the connections you make.

## Set it up once (about a minute)

Pick the file for your system from the folders next to this README:

| System | File |
|---|---|
| Windows (most PCs) | `windows-amd64/shieldkid.exe` |
| Windows on ARM | `windows-arm64/shieldkid.exe` |
| Mac with Apple chip (M1, M2, M3, M4) | `macos-apple-silicon/shieldkid` |
| Mac with Intel chip | `macos-intel/shieldkid` |
| Linux | `linux-amd64/shieldkid` (or `linux-arm64`) |

Open a terminal in that folder and run the installer. It copies the program into your own user folder and adds it to your PATH. No administrator rights are needed.

- **Windows:** in File Explorer open the folder, click the address bar, type `cmd`, press Enter, then
  `shieldkid.exe install`
  Windows may warn that the program is not signed: choose **More info → Run anyway**.
- **Mac:**
  ```
  chmod +x shieldkid
  xattr -d com.apple.quarantine shieldkid
  ./shieldkid install
  ```
  (The second line tells macOS you trust this unsigned program.)
- **Linux:** `chmod +x shieldkid && ./shieldkid install`

Then **open a new terminal window**. From now on you just type:

```
shieldkid
```

> **About the slash.** In a terminal, a leading `/` means "a file at the very top of the drive", so `/shieldkid` would look in the wrong place. The command is simply `shieldkid`, with no slash.

## What happens when you type `shieldkid`

ShieldKit starts, **and points your system's proxy settings at itself**, so apps that follow those settings (Chrome, Edge, Safari and most others) are protected without setting up each one. It tells you what it did:

```
ShieldKit is ACTIVE  (v1.0.0)
  Proxy:          127.0.0.1:8899
  Control panel:  http://127.0.0.1:8899/
  Apps:           your system's proxy settings now point at ShieldKit, so apps that follow them are protected.
                  They go back to normal when you press Ctrl+C.
```

Press **Ctrl+C** to turn it off; your settings are put back exactly as they were. Closing the window or logging out also restores them.

If it says `Apps: NOT protected yet` it explains why (for example macOS asking for permission). It never claims protection it could not confirm: after changing a setting it reads it back and only reports success if the system really kept it. You can then use the proxy by hand (below).

### Safety net for your network settings
- The original settings are saved to a backup file **before** anything changes.
- The address it sets is `proxy.pac` with a `DIRECT` fallback: if ShieldKit is ever not running, apps simply connect directly, so your internet never breaks.
- If a run ever dies without cleaning up (power cut, `kill -9`), starting `shieldkid` again restores your original settings first. Or run **`shieldkid off`**.
- A second copy started by mistake is refused and does not touch anything.

## All the commands

| Command | What it does |
|---|---|
| `shieldkid` | Turn it **on** (starts ShieldKit and sets the system proxy). Ctrl+C turns it off. |
| `shieldkid run COMMAND …` | Run **one program** protected, without changing any system setting: `shieldkid run git pull`, `shieldkid run curl https://example.com`. Works even if ShieldKit is not running (it starts a temporary one). The program's exit code is passed through. |
| `shieldkid status` | Is it running? What has it blocked? (exit code 1 if not running) |
| `shieldkid panel` | Open the control panel in your browser. |
| `shieldkid off` | Put your network settings back (only needed after a crash). |
| `shieldkid env` | Print the proxy variables for a terminal: `eval "$(shieldkid env)"` (PowerShell: `shieldkid env \| Invoke-Expression`) |
| `shieldkid check bol.com` | One combined rating for a website. |
| `shieldkid install` / `uninstall` | Make `shieldkid` work from any terminal / undo that. |
| `shieldkid pac [--strict]` | Print the automatic proxy configuration file. |

Options for turning it on: `--no-system` (do not touch system settings), `--open` / `--no-open` (control panel), `--listen 127.0.0.1:8898` (other port). The control panel opens by itself the very first time only.

## Apps that ignore the system settings

Some programs (many command-line tools, Python, Node, git, Docker, and Firefox on some systems) do not follow the system proxy. For those:

- **`shieldkid run COMMAND`** protects just that program, or
- put the proxy in the app: `127.0.0.1` port `8899` (an HTTP proxy, used for HTTP and HTTPS), or
- in a terminal: `eval "$(shieldkid env)"`

The control panel's **Use in apps** tab has copy-and-paste lines and steps for Windows, macOS and Firefox.

## What it can and cannot do

ShieldKit Local does **not** open your encrypted (HTTPS) traffic: doing that would mean installing a certificate that lets this program read everything you do, which is a serious security risk. So it works with *website names* and, for plain HTTP, full addresses.

| | Works for every app | Plain HTTP only |
|---|---|---|
| Block ad / tracker / scam / miner domains | ✔ | |
| Phishing look-alike warnings | ✔ (by site name) | full address too |
| SafeSearch and YouTube Restricted Mode | ✔ | |
| Location (send traffic through a server) | ✔ | |
| Block disguised or risky downloads | | ✔ |
| Upgrade HTTP to HTTPS, remove tracking tags, privacy headers | | ✔ |

Not possible without reading your HTTPS traffic: hiding ads that sit inside a page, removing YouTube video ads, and showing ratings on browser tabs. Those need the ShieldKit **browser extension**, which works well alongside this program.

A blocked HTTPS request shows up in the app as a connection error. If something breaks, open the control panel, find the site under *Recent activity* and press **Allow**. Updates for Windows, Apple and Ubuntu, and GitHub, are allowed by default.

### How SafeSearch works without decrypting anything
Google, Bing, DuckDuckGo and YouTube publish special "safe" servers meant for exactly this (it is what a network administrator's DNS setting does). When an app connects to `www.google.com`, ShieldKit Local connects to `forcesafesearch.google.com` instead. The app still sees Google's own certificate. Results are filtered by Google.

## Location (VPN-style)

A program cannot create a VPN by itself: it can send your traffic through a server someone runs. **Location** (in the control panel) lists every country; you add the servers.

- **Your own servers:** HTTPS or HTTP proxies (with login), or SOCKS5 servers (with or without a login; unlike Chrome, this program can log in to SOCKS5). A server you run yourself works too, for example `ssh -D 1080 user@your-server` gives a SOCKS5 server at `127.0.0.1:1080`.
- **Import** JSON or CSV (`country,host,port,type,username,password,name`).
- **Every connection is verified:** your IP address is looked up before and through the server (ipinfo.io, then ipwho.is as a fallback). If your IP did not change, or the server does not answer, ShieldKit goes back to a direct connection by itself. If your IP changed but lands in another country it warns you (IP databases sometimes disagree).
- **Kill switch (on by default):** if the server stops responding, traffic is blocked instead of falling back to your real IP.
- Local network addresses always go direct.

### Free servers (VLESS / VMess / Trojan / Shadowsocks lists)
Public lists such as `Hidashimora/free-vpn-anti-rkn` use protocols that need a small open-source client, **sing-box**:
1. Install sing-box (https://sing-box.sagernet.org).
2. In this folder run `python3 tools/subscription_to_singbox.py --singbox sing-box` (needs Python 3). It downloads the lists, keeps up to 8 working-looking servers per country, and writes `shieldkit-singbox.json`.
3. Run `sing-box run -c shieldkit-singbox.json` and leave it open.
4. In the control panel: **Location → Load countries**, then connect to any country.

**Know the risk:** these servers belong to anonymous strangers and the lists are re-published automatically with no vetting. A server's operator can see which sites you visit and can tamper with plain HTTP traffic. Do not sign in to banking, email or other important accounts through them. Many are slow or offline, and they come and go: re-run step 2 now and then.

## Site ratings

In the control panel: **Check a site**. Or: `shieldkid check bol.com`
```
bol.com: ★ 4.3 Great (3 sources, 13,704 reviews)
  Trustpilot  ★ 4.3 · 2041 reviews
  Sitejabber  ★ 4.0 · 11103 reviews
  Reviews.io  not listed
  Google      add a Google Places API key to include it
```
Each service's score is first pulled toward a neutral 3.5 in proportion to how few reviews it has (one 5-star review never shows as 5.0); the results are then averaged, weighted by the square root of the review count. 4.5+ Excellent, 4.0+ Great, 3.5+ Good, 3.0+ Average, 2.0+ Poor, below that Bad.

These read the public pages of each service. If a service blocks the request or changes its layout it is listed as unavailable, with the reason (`blocked, HTTP 403`, `bot check page`, `page layout not recognised`), and left out of the combined rating rather than guessed. Google needs your own Places API key (control panel → Protection → Google reviews key); Google bills per lookup beyond a free monthly allowance.

## Safety of the program itself

- Listens only on `127.0.0.1`. It refuses to start on any other address.
- The control panel refuses requests addressed to any other host name (stops DNS-rebinding attacks), and every change must carry a custom header and come from the panel itself, so a web page you visit cannot control it. The "Continue anyway" button of the phishing page is protected by a secret token.
- Passwords and API keys never leave the program: the panel's API never returns them. They are saved in the settings file (mode 600). The file is not encrypted.
- Settings file: Windows `%AppData%\ShieldKitLocal\config.json`, macOS `~/Library/Application Support/ShieldKitLocal/config.json`, Linux `~/.config/ShieldKitLocal/config.json`. The network-settings backup (`system-proxy-backup.json`) lives next to it while ShieldKit is on.

## What was tested, and what was not

Tested automatically (`go test -race`) and by hand with the real compiled program on Linux: the proxy with real traffic (HTTP, HTTPS tunnels, every kind of block, SafeSearch routing, SOCKS5/HTTP upstreams with logins, the kill switch), connect-and-verify, rating parsing, the control panel's security, `install`/`uninstall` in a fresh terminal, `shieldkid run`, and the whole on/off cycle against a **real GNOME settings database**, including a crash (`kill -9`), `shieldkid off`, and recovery on the next start.

**Not tested on a real machine:** the Windows and macOS parts of switching the system proxy. They use the standard system commands (`reg` and the Windows internet-settings refresh on Windows; `networksetup` on macOS); the exact commands and the parsing of their output are unit-tested, and the safety logic around them (backup first, read back, restore, crash recovery) is the same code that was verified on GNOME, but I could not run Windows or macOS here. If something goes wrong there, `shieldkid off` restores your settings, `--no-system` skips them entirely, and `shieldkid run` / the manual proxy settings always work. Also not tested against the live internet: SafeSearch against the real search engines, the rating websites, and location servers.

macOS may refuse to change network settings without permission; ShieldKit then says so and carries on without changing anything.

## Start it automatically when you log in

Add `shieldkid --no-open` to your login items:
- **Windows:** press `Win+R`, type `shell:startup`, and put a shortcut there to `%LOCALAPPDATA%\ShieldKit\shieldkid.exe` with `--no-open` added to the shortcut's *Target*.
- **macOS:** save as `~/Library/LaunchAgents/local.shieldkit.plist`, then `launchctl load ~/Library/LaunchAgents/local.shieldkit.plist` (change the path):
  ```xml
  <?xml version="1.0" encoding="UTF-8"?>
  <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
  <plist version="1.0"><dict>
    <key>Label</key><string>local.shieldkit</string>
    <key>ProgramArguments</key><array><string>/Users/YOU/.local/bin/shieldkid</string><string>--no-open</string></array>
    <key>RunAtLoad</key><true/><key>KeepAlive</key><true/>
  </dict></plist>
  ```
- **Linux (systemd):** save as `~/.config/systemd/user/shieldkid.service`, then `systemctl --user enable --now shieldkid`:
  ```ini
  [Unit]
  Description=ShieldKit Local
  [Service]
  ExecStart=%h/.local/bin/shieldkid --no-open
  Restart=on-failure
  [Install]
  WantedBy=default.target
  ```

## Uninstall

`shieldkid uninstall` removes the program and its PATH entry (it leaves your settings folder alone). Run `shieldkid off` first if you are unsure your network settings were restored.

## Build and test from source

Needs Go 1.22 or newer and nothing else (no downloads):
```
./build.sh          # vets, runs all tests, builds every platform into dist/
go test -race ./... # the test suite alone
```
To rebuild the domain lists from the browser extension's rules: `python3 tools/gen_lists.py PATH/TO/shieldkit/rules`.

## Licences

The block lists in `lists/` are derived from the AdGuard Base filter (GPL-3.0) and the ShieldKit extension's own lists. Fine for personal use; if you redistribute ShieldKit Local, follow those terms.
