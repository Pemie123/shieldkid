package main

import (
	"bufio"
	"context"
	"fmt"
	"html"
	"io"
	"net"
	"net/http"
	"net/url"
	"regexp"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

// ---------------------------------------------------------------- activity log and counters

type Event struct {
	Time     time.Time `json:"time"`
	Host     string    `json:"host"`
	Category string    `json:"category"`
	Reason   string    `json:"reason"`
	Method   string    `json:"method"`
}

type Stats struct {
	mu     sync.Mutex
	counts map[string]int
	events []Event
}

func NewStats() *Stats { return &Stats{counts: map[string]int{}} }

func (s *Stats) Count(category string) {
	s.mu.Lock()
	s.counts[category]++
	s.mu.Unlock()
}

func (s *Stats) Record(e Event) {
	s.mu.Lock()
	s.counts[e.Category]++
	e.Time = time.Now()
	s.events = append(s.events, e)
	if len(s.events) > 200 {
		s.events = s.events[len(s.events)-200:]
	}
	s.mu.Unlock()
}

func (s *Stats) Snapshot() (map[string]int, []Event) {
	s.mu.Lock()
	defer s.mu.Unlock()
	c := make(map[string]int, len(s.counts))
	for k, v := range s.counts {
		c[k] = v
	}
	ev := make([]Event, len(s.events))
	copy(ev, s.events)
	for i, j := 0, len(ev)-1; i < j; i, j = i+1, j-1 { // newest first
		ev[i], ev[j] = ev[j], ev[i]
	}
	return c, ev
}

// ---------------------------------------------------------------- the proxy

type Proxy struct {
	store  *Store
	engine *Engine
	stats  *Stats
	sess   *SessionAllow
	token  string       // secret in "continue anyway" links, so a web page cannot allow hosts on your behalf
	panel  http.Handler // control panel and API, for requests addressed to the proxy itself
	dial   DialFunc

	SystemOn atomic.Bool // the operating system's proxy setting currently points at us

	mu     sync.RWMutex
	up     *Server
	direct *http.Transport
	via    *http.Transport
}

func NewProxy(store *Store, engine *Engine) *Proxy {
	p := &Proxy{store: store, engine: engine, stats: NewStats(), sess: &SessionAllow{}, token: randomToken(), dial: baseDial}
	p.Reload()
	store.onChange = p.Reload
	return p
}

func (p *Proxy) newTransport(up *Server) *http.Transport {
	t := &http.Transport{
		DialContext:           func(ctx context.Context, n, a string) (net.Conn, error) { return p.dial(ctx, n, a) },
		DisableCompression:    true, // pass the body through exactly as received
		MaxIdleConns:          100,
		IdleConnTimeout:       30 * time.Second,
		TLSHandshakeTimeout:   10 * time.Second,
		ResponseHeaderTimeout: 60 * time.Second,
	}
	if up != nil {
		t.Proxy = http.ProxyURL(proxyURL(up))
	}
	return t
}

// Reload rebuilds the connections after the configuration (or the active server) changed.
func (p *Proxy) Reload() {
	up := p.store.Get().activeServer()
	direct := p.newTransport(nil)
	via := direct
	if up != nil {
		via = p.newTransport(up)
	}
	p.mu.Lock()
	oldD, oldV := p.direct, p.via
	p.up, p.direct, p.via = up, direct, via
	p.mu.Unlock()
	for _, t := range []*http.Transport{oldD, oldV} {
		if t != nil {
			t.CloseIdleConnections()
		}
	}
}

func (p *Proxy) current() (*Server, *http.Transport, *http.Transport) {
	p.mu.RLock()
	defer p.mu.RUnlock()
	return p.up, p.direct, p.via
}

// Client returns an HTTP client that goes out the same way the proxy does (through the active server, or direct).
func (p *Proxy) Client(viaServer bool) *http.Client {
	_, direct, via := p.current()
	t := direct
	if viaServer {
		t = via
	}
	return &http.Client{Transport: t, Timeout: 12 * time.Second}
}

func (p *Proxy) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	switch {
	case r.Method == http.MethodConnect:
		p.handleConnect(w, r)
	case r.URL.IsAbs():
		p.handleHTTP(w, r)
	case p.panel != nil:
		p.panel.ServeHTTP(w, r)
	default:
		http.NotFound(w, r)
	}
}

// ---------------------------------------------------------------- SafeSearch through the connection target
// Instead of decrypting HTTPS, the proxy connects to the search engines' own "safe" servers, which is exactly what the
// official DNS method (a CNAME record) does: same name, same certificate, but results are filtered.

var googleHostRe = regexp.MustCompile(`^(www\.)?google\.(com|[a-z]{2}|co\.[a-z]{2}|com\.[a-z]{2})$`)

func safeSearchTarget(host string, cfg *Config) (string, bool) {
	h := normalizeHost(host)
	if cfg.SafeSearch {
		switch {
		case googleHostRe.MatchString(h):
			return "forcesafesearch.google.com", true
		case h == "bing.com" || h == "www.bing.com":
			return "strict.bing.com", true
		case h == "duckduckgo.com" || h == "www.duckduckgo.com":
			return "safe.duckduckgo.com", true
		}
	}
	if cfg.YouTube == "moderate" || cfg.YouTube == "strict" {
		switch h {
		case "www.youtube.com", "m.youtube.com", "youtubei.googleapis.com", "youtube.googleapis.com", "www.youtube-nocookie.com":
			if cfg.YouTube == "strict" {
				return "restrict.youtube.com", true
			}
			return "restrictmoderate.youtube.com", true
		}
	}
	return "", false
}

// ---------------------------------------------------------------- HTTPS tunnels (CONNECT)

func (p *Proxy) dialTarget(ctx context.Context, target string, cfg *Config) (net.Conn, error) {
	host, _, err := net.SplitHostPort(target)
	if err != nil {
		return nil, err
	}
	up, _, _ := p.current()
	if up == nil || isLocalHost(host) {
		return p.dial(ctx, "tcp", target)
	}
	conn, err := dialVia(ctx, up, target, p.dial)
	if err != nil && !cfg.KillSwitch {
		return p.dial(ctx, "tcp", target) // kill switch off: fall back to the direct connection
	}
	return conn, err
}

func (p *Proxy) handleConnect(w http.ResponseWriter, r *http.Request) {
	host, port, err := net.SplitHostPort(r.Host)
	if err != nil {
		host, port = r.Host, "443"
	}
	cfg := p.store.Get()

	if d := p.engine.DecideHost(host, &cfg, p.sess); d.Block {
		p.stats.Record(Event{Host: host, Category: d.Category, Reason: d.Reason, Method: "CONNECT"})
		w.Header().Set("X-ShieldKit-Blocked", d.Category)
		http.Error(w, "Blocked by ShieldKit Local: "+d.Reason, http.StatusForbidden)
		return
	}
	// phishing look-alikes are judged on the host name here; the full address is not visible inside HTTPS
	if cfg.Phishing && cfg.Enabled && !isLocalHost(host) && !hostAllowed(host, cfg.Allow) && !p.sess.Has(host) {
		if score, reasons := assessURL(&url.URL{Scheme: "https", Host: normalizeHost(host), Path: "/"}); score >= 3 {
			why := strings.Join(reasons, "; ")
			p.stats.Record(Event{Host: host, Category: "phishing", Reason: why, Method: "CONNECT"})
			w.Header().Set("X-ShieldKit-Blocked", "phishing")
			http.Error(w, "Blocked by ShieldKit Local: possible phishing site ("+why+"). Allow it in the control panel if you trust it.", http.StatusForbidden)
			return
		}
	}

	target := net.JoinHostPort(host, port)
	if cfg.Enabled && !isLocalHost(host) && !hostAllowed(host, cfg.Allow) {
		if safe, ok := safeSearchTarget(host, &cfg); ok {
			target = net.JoinHostPort(safe, port)
			p.stats.Record(Event{Host: host, Category: "safesearch", Reason: "connected to " + safe, Method: "CONNECT"})
		}
	}

	ctx, cancel := context.WithTimeout(r.Context(), 20*time.Second)
	upstream, err := p.dialTarget(ctx, target, &cfg)
	cancel()
	if err != nil {
		http.Error(w, "ShieldKit Local could not connect: "+err.Error(), http.StatusBadGateway)
		return
	}
	hj, ok := w.(http.Hijacker)
	if !ok {
		upstream.Close()
		http.Error(w, "tunnelling is not supported here", http.StatusInternalServerError)
		return
	}
	client, buf, err := hj.Hijack()
	if err != nil {
		upstream.Close()
		return
	}
	if _, err := io.WriteString(client, "HTTP/1.1 200 Connection Established\r\n\r\n"); err != nil {
		client.Close()
		upstream.Close()
		return
	}
	pipe(client, buf.Reader, upstream)
}

func pipe(client net.Conn, clientReader *bufio.Reader, upstream net.Conn) {
	var wg sync.WaitGroup
	wg.Add(2)
	half := func(dst net.Conn, src io.Reader) {
		defer wg.Done()
		_, _ = io.Copy(dst, src)
		if cw, ok := dst.(interface{ CloseWrite() error }); ok {
			_ = cw.CloseWrite()
		} else {
			_ = dst.Close()
		}
	}
	go half(upstream, clientReader) // clientReader also holds any bytes the client sent early
	go half(client, upstream)
	wg.Wait()
	client.Close()
	upstream.Close()
}

// ---------------------------------------------------------------- plain HTTP requests

var hopHeaders = []string{"Connection", "Proxy-Connection", "Keep-Alive", "Proxy-Authenticate", "Proxy-Authorization", "Te", "Trailer", "Transfer-Encoding", "Upgrade"}

func removeHopHeaders(h http.Header) {
	for _, f := range h.Values("Connection") {
		for _, name := range strings.Split(f, ",") {
			h.Del(strings.TrimSpace(name))
		}
	}
	for _, name := range hopHeaders {
		h.Del(name)
	}
}

var trackingParams = map[string]bool{
	"utm_source": true, "utm_medium": true, "utm_campaign": true, "utm_term": true, "utm_content": true, "utm_id": true,
	"fbclid": true, "gclid": true, "dclid": true, "msclkid": true, "mc_eid": true, "igshid": true, "yclid": true,
	"twclid": true, "ttclid": true, "_hsenc": true, "_hsmi": true, "ref_src": true,
}

// stripTrackingParams removes tracking parameters but keeps every other parameter byte for byte.
func stripTrackingParams(rawQuery string) string {
	if rawQuery == "" {
		return ""
	}
	var keep []string
	for _, part := range strings.Split(rawQuery, "&") {
		key := part
		if i := strings.IndexByte(part, '='); i >= 0 {
			key = part[:i]
		}
		if k, err := url.QueryUnescape(key); err == nil {
			key = k
		}
		if !trackingParams[key] {
			keep = append(keep, part)
		}
	}
	return strings.Join(keep, "&")
}

func (p *Proxy) handleHTTP(w http.ResponseWriter, r *http.Request) {
	u := r.URL
	host := u.Hostname()
	cfg := p.store.Get()

	d := p.engine.DecideURL(u, &cfg, p.sess)
	if !d.Block && cfg.Enabled && cfg.Downloads && !isLocalHost(host) && !hostAllowed(host, cfg.Allow) && !p.sess.Has(host) {
		if reasons := assessDownloadURL(u, cfg.DownloadsStrict); len(reasons) > 0 {
			d = Decision{Block: true, Category: "download", Reason: strings.Join(reasons, "; ")}
		}
	}
	if d.Block {
		p.stats.Record(Event{Host: host, Category: d.Category, Reason: d.Reason, Method: r.Method})
		p.writeBlocked(w, r, d, &cfg)
		return
	}

	if cfg.Enabled && cfg.UpgradeHTTP && u.Scheme == "http" && (r.Method == http.MethodGet || r.Method == http.MethodHead) &&
		!isLocalHost(host) && !hostAllowed(host, cfg.Allow) {
		up := *u
		up.Scheme = "https"
		if up.Port() == "80" {
			up.Host = u.Hostname()
		}
		p.stats.Record(Event{Host: host, Category: "upgraded", Reason: "http to https", Method: r.Method})
		http.Redirect(w, r, up.String(), http.StatusPermanentRedirect)
		return
	}

	out := r.Clone(r.Context())
	out.RequestURI = ""
	outURL := *u
	if cfg.Enabled && cfg.StripParams && !isLocalHost(host) {
		if q := stripTrackingParams(outURL.RawQuery); q != outURL.RawQuery {
			outURL.RawQuery = q
			p.stats.Count("stripped")
		}
	}
	out.URL = &outURL
	removeHopHeaders(out.Header)
	if cfg.Enabled && cfg.PrivacyHeaders && !isLocalHost(host) {
		out.Header.Set("Sec-GPC", "1")
		out.Header.Set("DNT", "1")
	}

	up, direct, via := p.current()
	tr := direct
	if up != nil && !isLocalHost(host) {
		tr = via
	}
	resp, err := tr.RoundTrip(out)
	if err != nil && tr != direct && !cfg.KillSwitch && (r.Method == http.MethodGet || r.Method == http.MethodHead) {
		resp, err = direct.RoundTrip(out) // kill switch off: fall back to the direct connection
	}
	if err != nil {
		http.Error(w, "ShieldKit Local could not reach the server: "+err.Error(), http.StatusBadGateway)
		return
	}
	defer resp.Body.Close()
	removeHopHeaders(resp.Header)
	for k, vs := range resp.Header {
		for _, v := range vs {
			w.Header().Add(k, v)
		}
	}
	w.WriteHeader(resp.StatusCode)
	flusher, _ := w.(http.Flusher)
	buf := make([]byte, 32*1024)
	for {
		n, rerr := resp.Body.Read(buf)
		if n > 0 {
			if _, werr := w.Write(buf[:n]); werr != nil {
				return
			}
			if flusher != nil {
				flusher.Flush()
			}
		}
		if rerr != nil {
			return
		}
	}
}

func (p *Proxy) writeBlocked(w http.ResponseWriter, r *http.Request, d Decision, cfg *Config) {
	w.Header().Set("X-ShieldKit-Blocked", d.Category)
	if d.Quiet {
		w.WriteHeader(http.StatusNoContent)
		return
	}
	title := map[string]string{"malware": "Malicious site blocked", "phishing": "This site looks unsafe", "download": "Risky download blocked"}[d.Category]
	if title == "" {
		title = "Blocked"
	}
	host := r.URL.Hostname()
	cont := ""
	if d.Category == "phishing" {
		link := "http://" + cfg.Listen + "/__shieldkit/allow?" + url.Values{"host": {host}, "token": {p.token}, "next": {r.URL.String()}}.Encode()
		cont = `<p><a href="` + html.EscapeString(link) + `">Continue anyway</a> (until ShieldKit Local is closed)</p>`
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(http.StatusForbidden)
	fmt.Fprintf(w, `<!doctype html><meta charset="utf-8"><title>%s</title>
<body style="font:16px system-ui,sans-serif;max-width:560px;margin:15vh auto;padding:0 20px;color:#1f1410">
<h1 style="color:#b42318">%s</h1><p>ShieldKit Local stopped this request to <b>%s</b>.</p><p>Reason: %s.</p>%s
<p style="color:#5b7083;font-size:14px">To always allow a site, add it under Allowed sites in the ShieldKit Local control panel.</p></body>`,
		html.EscapeString(title), html.EscapeString(title), html.EscapeString(host), html.EscapeString(d.Reason), cont)
}
