package main

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"
	"time"
)

func TestCountryTable(t *testing.T) {
	if len(countryNames) != 249 || len(countryCodes) != 249 {
		t.Fatalf("expected 249 countries, got %d / %d", len(countryNames), len(countryCodes))
	}
	for in, want := range map[string]string{"BE": "BE", "be": "BE", "UK": "GB", "Belgium": "BE", "belgium": "BE", "Netherlands": "NL", "Narnia": "", "": "", "XX": ""} {
		if got := countryCode(in); got != want {
			t.Errorf("countryCode(%q) = %q, want %q", in, got, want)
		}
	}
}

func TestValidateServer(t *testing.T) {
	ok, err := validateServer(rawServer{Country: "BE", Host: "BE1.Example.com", Port: float64(443)})
	if err != nil || ok.ID != "BE-https-be1.example.com-443" || ok.Name != "be1.example.com" {
		t.Fatalf("%+v %v", ok, err)
	}
	if s, err := validateServer(rawServer{Country: "NL", Host: "127.0.0.1", Port: "1080", Scheme: "socks5", Username: "u", Password: "p"}); err != nil || s.Username != "u" {
		t.Errorf("socks5 with a login is allowed here (unlike in Chrome): %+v %v", s, err)
	}
	for _, bad := range []rawServer{
		{Country: "XX", Host: "a.com", Port: 1}, {Country: "BE", Host: `a"; evil()//`, Port: 1}, {Country: "BE", Host: "a.com", Port: 70000},
		{Country: "BE", Host: "a.com", Port: "x"}, {Country: "BE", Host: "a.com", Port: 1, Scheme: "ftp"}, {Country: "BE", Host: "", Port: 1},
	} {
		if _, err := validateServer(bad); err == nil {
			t.Errorf("should be rejected: %+v", bad)
		}
	}
}

func TestParseServers(t *testing.T) {
	csv := "country,host,port,type,username,password,name\nBE,be1.example.com,443,https,u,p,Brussels, centre\n# comment\nXX,bad.example.com,1,https\nNL,nl1.example.com,8080,http\n"
	s, errs := parseServers(csv)
	if len(s) != 2 || len(errs) != 1 || s[0].Name != "Brussels, centre" || s[0].Username != "u" {
		t.Fatalf("%+v %v", s, errs)
	}
	j, errs := parseServers(`[{"country":"DE","host":"de.example.com","port":443},{"country":"DE","host":"de.example.com","port":"443"}]`)
	if len(j) != 1 || len(errs) != 0 {
		t.Fatalf("dedup: %+v %v", j, errs)
	}
	w, _ := parseServers(`{"servers":[{"country":"Belgium","host":"x.example.com","port":1,"type":"socks5"}]}`)
	if len(w) != 1 || w[0].Scheme != "socks5" || w[0].Country != "BE" {
		t.Errorf("wrapped json: %+v", w)
	}
	if _, errs := parseServers("  "); len(errs) != 1 {
		t.Error("empty import")
	}
	if _, errs := parseServers("[oops"); len(errs) != 1 {
		t.Error("bad json")
	}
}

// ---------------------------------------------------------------- sing-box controller (fake)

type fakeController struct {
	*httptest.Server
	mu       sync.Mutex
	selected []string
	failPut  bool
}

func newFakeController(t *testing.T) *fakeController {
	fc := &fakeController{}
	fc.Server = httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == "GET" && r.URL.Path == "/proxies":
			json.NewEncoder(w).Encode(map[string]any{"proxies": map[string]any{
				"proxy":      map[string]any{"type": "Selector", "all": []string{"country-BE", "country-NL"}},
				"country-NL": map[string]any{"type": "URLTest", "all": []string{"NL-01", "NL-02"}},
				"country-BE": map[string]any{"type": "URLTest", "all": []string{"BE-01"}},
				"country-ZZ": map[string]any{"type": "URLTest", "all": []string{"ZZ-01"}}, // not a real country
				"country-DE": map[string]any{"type": "URLTest", "all": []string{}},        // empty group
				"BE-01":      map[string]any{"type": "VLESS"},
			}})
		case r.Method == "PUT" && r.URL.Path == "/proxies/proxy":
			var b struct{ Name string }
			json.NewDecoder(r.Body).Decode(&b)
			if fc.failPut {
				http.Error(w, "nope", 400)
				return
			}
			fc.mu.Lock()
			fc.selected = append(fc.selected, b.Name)
			fc.mu.Unlock()
			w.WriteHeader(204)
		default:
			http.NotFound(w, r)
		}
	}))
	t.Cleanup(fc.Close)
	return fc
}

func TestValidAPI(t *testing.T) {
	for in, ok := range map[string]bool{"http://127.0.0.1:9090": true, "http://localhost:9090/": true, "http://203.0.113.5:9090": false, "https://127.0.0.1:9090": false, "ftp://127.0.0.1": false, "nonsense": false} {
		if _, got := validAPI(in); got != ok {
			t.Errorf("validAPI(%q) = %v", in, got)
		}
	}
}

func TestBridgeCountriesAndSelect(t *testing.T) {
	fc := newFakeController(t)
	cs, err := bridgeCountries(context.Background(), fc.URL)
	if err != nil || len(cs) != 2 || cs[0].Code != "BE" || cs[1].Code != "NL" || cs[1].Nodes != 2 {
		t.Fatalf("%+v %v", cs, err)
	}
	if err := bridgeSelect(context.Background(), fc.URL, "country-NL"); err != nil || fc.selected[0] != "country-NL" {
		t.Fatalf("select: %v %v", err, fc.selected)
	}
	fc.failPut = true
	if err := bridgeSelect(context.Background(), fc.URL, "country-BE"); err == nil {
		t.Error("a refused selection must be an error")
	}
	if _, err := bridgeCountries(context.Background(), "http://127.0.0.1:1"); err == nil || !strings.Contains(err.Error(), "cannot reach") {
		t.Errorf("unreachable client: %v", err)
	}
	srv := bridgeServers(cs, 2080)
	if srv[0].ID != "BRIDGE-BE" || srv[0].Scheme != "socks5" || srv[0].Port != 2080 || !srv[0].Bridge || srv[0].Group != "country-BE" {
		t.Errorf("%+v", srv[0])
	}
}

// ---------------------------------------------------------------- connect + verify

type mgrRig struct {
	store   *Store
	mgr     *Manager
	lookups int
	via     func() (IPInfo, error) // what a lookup sees while a server is active
}

func newMgrRig(t *testing.T) *mgrRig {
	store, _ := LoadStore("")
	p := NewProxy(store, testEngine())
	r := &mgrRig{store: store, mgr: NewManager(store, p)}
	r.mgr.retryDelay = time.Millisecond
	r.mgr.lookup = func(ctx context.Context, c *http.Client) (IPInfo, error) {
		r.lookups++
		if store.Get().Active == "" {
			return IPInfo{IP: "81.1.1.1", Country: "BE"}, nil
		}
		return r.via()
	}
	return r
}

func (r *mgrRig) withServers(servers ...Server) {
	_ = r.store.Update(func(c *Config) error { c.Servers = servers; return nil })
}

var srvBE = Server{ID: "BE-s", Country: "BE", Name: "Brussels", Scheme: "socks5", Host: "127.0.0.1", Port: 1}

func TestConnectVerified(t *testing.T) {
	r := newMgrRig(t)
	r.withServers(srvBE)
	r.via = func() (IPInfo, error) { return IPInfo{IP: "5.5.5.5", Country: "BE", City: "Brussels"}, nil }
	info, err := r.mgr.Connect(context.Background(), "BE-s")
	if err != nil || info.Verdict.Level != "ok" || info.IP.IP != "5.5.5.5" || info.BaselineIP != "81.1.1.1" {
		t.Fatalf("%+v %v", info, err)
	}
	if r.store.Get().Active != "BE-s" || r.mgr.Last() == nil {
		t.Error("should be connected")
	}
	r.mgr.Disconnect()
	if r.store.Get().Active != "" || r.mgr.Last() != nil {
		t.Error("should be disconnected")
	}
}

func TestConnectFailuresRevertToDirect(t *testing.T) {
	r := newMgrRig(t)
	r.withServers(srvBE)

	r.via = func() (IPInfo, error) { return IPInfo{IP: "81.1.1.1", Country: "BE"}, nil }
	if _, err := r.mgr.Connect(context.Background(), "BE-s"); err == nil || !strings.Contains(err.Error(), "did not change") {
		t.Fatalf("unchanged IP: %v", err)
	}
	if r.store.Get().Active != "" {
		t.Error("must revert to direct when the IP did not change")
	}

	r.via = func() (IPInfo, error) { return IPInfo{}, errors.New("timeout") }
	if _, err := r.mgr.Connect(context.Background(), "BE-s"); err == nil || !strings.Contains(err.Error(), "did not respond") {
		t.Fatalf("dead server: %v", err)
	}
	if r.store.Get().Active != "" {
		t.Error("must revert to direct when the server is dead")
	}
	if _, err := r.mgr.Connect(context.Background(), "nope"); err == nil {
		t.Error("unknown server")
	}
}

func TestConnectWrongCountryWarnsButStays(t *testing.T) {
	r := newMgrRig(t)
	r.withServers(srvBE)
	r.via = func() (IPInfo, error) { return IPInfo{IP: "7.7.7.7", Country: "DE"}, nil }
	info, err := r.mgr.Connect(context.Background(), "BE-s")
	if err != nil || info.Verdict.Level != "warn" || !strings.Contains(info.Verdict.Text, "Germany") {
		t.Fatalf("%+v %v", info, err)
	}
	if r.store.Get().Active != "BE-s" {
		t.Error("a warning keeps the connection")
	}
}

func TestConnectBridgeSelectsGroupAndRetries(t *testing.T) {
	fc := newFakeController(t)
	r := newMgrRig(t)
	_ = r.store.Update(func(c *Config) error {
		c.BridgeAPI = fc.URL
		c.Servers = bridgeServers([]BridgeCountry{{Code: "NL", Group: "country-NL", Nodes: 2}}, 2080)
		return nil
	})
	attempt := 0
	r.via = func() (IPInfo, error) {
		attempt++
		if attempt < 3 {
			return IPInfo{}, errors.New("no working server yet")
		}
		return IPInfo{IP: "8.8.4.4", Country: "NL"}, nil
	}
	info, err := r.mgr.Connect(context.Background(), "BRIDGE-NL")
	if err != nil || info.Verdict.Level != "ok" || attempt != 3 {
		t.Fatalf("%+v %v attempts=%d", info, err, attempt)
	}
	if len(fc.selected) != 1 || fc.selected[0] != "country-NL" {
		t.Errorf("group selected before connecting: %v", fc.selected)
	}

	r.mgr.Disconnect()
	r.via = func() (IPInfo, error) { return IPInfo{}, errors.New("nothing works") }
	_, err = r.mgr.Connect(context.Background(), "BRIDGE-NL")
	if err == nil || !strings.Contains(err.Error(), "try another country") || r.store.Get().Active != "" {
		t.Fatalf("all free servers dead: %v active=%q", err, r.store.Get().Active)
	}

	fc.failPut = true
	if _, err := r.mgr.Connect(context.Background(), "BRIDGE-NL"); err == nil || !strings.Contains(err.Error(), "refused") || r.store.Get().Active != "" {
		t.Fatalf("controller refuses: %v", err)
	}
	_ = r.store.Update(func(c *Config) error { c.BridgeAPI = "http://203.0.113.9:9090"; return nil })
	if _, err := r.mgr.Connect(context.Background(), "BRIDGE-NL"); err == nil || !strings.Contains(err.Error(), "on this computer") {
		t.Fatalf("remote controller must be refused: %v", err)
	}
}

func TestResumeReselectsGroup(t *testing.T) {
	fc := newFakeController(t)
	r := newMgrRig(t)
	_ = r.store.Update(func(c *Config) error {
		c.BridgeAPI = fc.URL
		c.Servers = bridgeServers([]BridgeCountry{{Code: "BE", Group: "country-BE", Nodes: 1}}, 2080)
		c.Active = "BRIDGE-BE"
		return nil
	})
	r.mgr.Resume(context.Background())
	if len(fc.selected) != 1 || fc.selected[0] != "country-BE" {
		t.Errorf("%v", fc.selected)
	}
}

func TestJudge(t *testing.T) {
	be, de := &IPInfo{IP: "2.2.2.2", Country: "BE"}, &IPInfo{IP: "3.3.3.3", Country: "DE"}
	base := &IPInfo{IP: "1.1.1.1"}
	if judge(base, be, "BE").Level != "ok" || judge(base, de, "BE").Level != "warn" || judge(base, nil, "BE").Level != "fail" || judge(&IPInfo{IP: "2.2.2.2"}, be, "BE").Level != "fail" || judge(nil, be, "BE").Level != "ok" {
		t.Error("verdicts wrong")
	}
}

func TestLookupIPFallsBackToSecondProvider(t *testing.T) {
	bad := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { http.Error(w, "x", 500) }))
	good := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte(`{"success":true,"ip":"9.9.9.9","country_code":"be","city":"Brussels","connection":{"isp":"X"}}`))
	}))
	defer bad.Close()
	defer good.Close()
	saved := ipProviders
	defer func() { ipProviders = saved }()
	ipProviders = []ipProvider{{bad.URL, saved[0].parse}, {good.URL, saved[1].parse}}
	ip, err := lookupIP(context.Background(), http.DefaultClient)
	if err != nil || ip.IP != "9.9.9.9" || ip.Country != "BE" || ip.Org != "X" {
		t.Fatalf("%+v %v", ip, err)
	}
	ipProviders = []ipProvider{{bad.URL, saved[0].parse}}
	if _, err := lookupIP(context.Background(), http.DefaultClient); err == nil {
		t.Error("all providers failing must be an error")
	}
}

func TestConfigSaveAndLoad(t *testing.T) {
	path := t.TempDir() + "/sub/config.json"
	s, err := LoadStore(path)
	if err != nil {
		t.Fatal(err)
	}
	changed := 0
	s.onChange = func() { changed++ }
	_ = s.Update(func(c *Config) error { c.Ads = false; c.Servers = []Server{srvBE}; c.Active = "BE-s"; return nil })
	if changed != 1 {
		t.Error("onChange not called")
	}
	s2, err := LoadStore(path)
	if err != nil || s2.Get().Ads || s2.Get().activeServer() == nil || !s2.Get().Trackers {
		t.Fatalf("reload: %+v %v", s2.Get(), err)
	}
	if err := s.Update(func(c *Config) error { return errors.New("refuse") }); err == nil {
		t.Error("an error from the update function must be returned")
	}
	if s.Get().Ads {
		t.Error("a failed update must not change anything")
	}
}
