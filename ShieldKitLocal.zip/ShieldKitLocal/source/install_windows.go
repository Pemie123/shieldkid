//go:build windows

package main

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
)

func platformInstallDir() (string, error) {
	base := os.Getenv("LOCALAPPDATA")
	if base == "" {
		return "", fmt.Errorf("cannot find your LOCALAPPDATA folder")
	}
	return filepath.Join(base, "ShieldKit"), nil
}

func powershell(script, dir string) (string, error) {
	cmd := exec.Command("powershell", "-NoProfile", "-NonInteractive", "-Command", script)
	cmd.Env = append(os.Environ(), "SHIELDKID_DIR="+dir) // passed as a variable, never pasted into the script
	out, err := cmd.CombinedOutput()
	return strings.TrimSpace(string(out)), err
}

func platformEnsureOnPath(dir string) (string, error) {
	const script = `$d = $env:SHIELDKID_DIR; $p = [Environment]::GetEnvironmentVariable('Path','User'); if ($null -eq $p) { $p = '' }
if (($p -split ';') -contains $d) { 'already' } else { [Environment]::SetEnvironmentVariable('Path', (($p.TrimEnd(';') + ';' + $d).TrimStart(';')), 'User'); 'added' }`
	out, err := powershell(script, dir)
	if err != nil {
		return "", fmt.Errorf("%v %s", err, out)
	}
	if strings.HasSuffix(out, "already") {
		return dir + " is already on your PATH.", nil
	}
	return "Added " + dir + " to your user PATH.", nil
}

func platformRemoveFromPath(dir string) error {
	const script = `$d = $env:SHIELDKID_DIR; $p = [Environment]::GetEnvironmentVariable('Path','User'); if ($null -ne $p) { $q = (($p -split ';') | Where-Object { $_ -and $_ -ne $d }) -join ';'; [Environment]::SetEnvironmentVariable('Path', $q, 'User') }`
	if out, err := powershell(script, dir); err != nil {
		return fmt.Errorf("%v %s", err, out)
	}
	return nil
}
