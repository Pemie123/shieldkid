//go:build !windows

package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func fakeHome(t *testing.T, shell string) string {
	home := t.TempDir()
	t.Setenv("HOME", home)
	t.Setenv("SHELL", shell)
	t.Setenv("PATH", "/usr/bin:/bin")
	return home
}

func read(t *testing.T, path string) string {
	b, _ := os.ReadFile(path)
	return string(b)
}

func TestInstallPathZsh(t *testing.T) {
	home := fakeHome(t, "/bin/zsh")
	dir, _ := platformInstallDir()
	if dir != filepath.Join(home, ".local", "bin") {
		t.Fatalf("dir %s", dir)
	}
	note, err := platformEnsureOnPath(dir)
	if err != nil || !strings.Contains(note, ".zshrc") {
		t.Fatalf("%q %v", note, err)
	}
	rc := read(t, filepath.Join(home, ".zshrc"))
	if !strings.Contains(rc, `export PATH="$HOME/.local/bin:$PATH"`) || !strings.Contains(rc, pathStart) {
		t.Errorf(".zshrc:\n%s", rc)
	}
	platformEnsureOnPath(dir) // running install twice must not stack up lines
	if strings.Count(read(t, filepath.Join(home, ".zshrc")), pathStart) != 1 {
		t.Error("not idempotent")
	}
	if err := platformRemoveFromPath(dir); err != nil {
		t.Fatal(err)
	}
	if strings.Contains(read(t, filepath.Join(home, ".zshrc")), "shieldkid") {
		t.Error("uninstall must remove our lines")
	}
}

func TestInstallKeepsExistingStartupFileContent(t *testing.T) {
	home := fakeHome(t, "/usr/bin/bash")
	rc := filepath.Join(home, ".bashrc")
	os.WriteFile(rc, []byte("alias ll='ls -l'\nexport EDITOR=vim\n"), 0o644)
	dir, _ := platformInstallDir()
	platformEnsureOnPath(dir)
	got := read(t, rc)
	if !strings.HasPrefix(got, "alias ll='ls -l'\nexport EDITOR=vim\n") || !strings.Contains(got, pathStart) {
		t.Errorf("existing content must be kept:\n%s", got)
	}
	platformRemoveFromPath(dir)
	if after := read(t, rc); !strings.Contains(after, "export EDITOR=vim") || strings.Contains(after, "shieldkid") {
		t.Errorf("uninstall must only remove our block:\n%s", after)
	}
}

func TestInstallLeavesPathAloneWhenAlreadyThere(t *testing.T) {
	home := fakeHome(t, "/bin/bash")
	dir, _ := platformInstallDir()
	t.Setenv("PATH", "/usr/bin:"+dir)
	note, err := platformEnsureOnPath(dir)
	if err != nil || !strings.Contains(note, "already on your PATH") {
		t.Fatalf("%q %v", note, err)
	}
	if _, err := os.Stat(filepath.Join(home, ".bashrc")); err == nil {
		t.Error("nothing should be written when the folder is already on the PATH")
	}
}

func TestInstallAndUninstallEndToEnd(t *testing.T) {
	home := fakeHome(t, "/bin/zsh")
	if err := runInstall(nil); err != nil {
		t.Fatal(err)
	}
	dst := filepath.Join(home, ".local", "bin", "shieldkid")
	fi, err := os.Stat(dst)
	if err != nil || fi.Mode().Perm()&0o111 == 0 {
		t.Fatalf("installed program missing or not executable: %v", err)
	}
	if err := runInstall(nil); err != nil { // second run: must work and not duplicate anything
		t.Fatal(err)
	}
	if strings.Count(read(t, filepath.Join(home, ".zshrc")), pathStart) != 1 {
		t.Error("PATH block duplicated")
	}
	if err := runUninstall(nil); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(dst); err == nil {
		t.Error("program not removed")
	}
	if strings.Contains(read(t, filepath.Join(home, ".zshrc")), "shieldkid") {
		t.Error("PATH block not removed")
	}
}
