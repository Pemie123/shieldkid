//go:build darwin

package main

func newSysProxy() sysProxy { return macProxy{run: execRun} }
