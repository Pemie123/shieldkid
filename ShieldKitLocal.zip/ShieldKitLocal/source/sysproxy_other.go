//go:build !windows && !darwin && !linux

package main

func newSysProxy() sysProxy { return nil }
