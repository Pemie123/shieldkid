package main

import (
	_ "embed"
	"net"
	"net/url"
	"strings"
	"sync"
)

//go:embed lists/ads.txt
var adsList string

//go:embed lists/trackers.txt
var trackersList string

//go:embed lists/malware.txt
var malwareList string

// Never listed as blocked, even if a list contains them by mistake: blocking these would break sign-in and updates.
var protectedDomains = map[string]bool{
	"google.com": true, "googleapis.com": true, "gstatic.com": true, "youtube.com": true, "microsoft.com": true,
	"windows.com": true, "live.com": true, "office.com": true, "apple.com": true, "icloud.com": true,
	"amazon.com": true, "amazonaws.com": true, "cloudfront.net": true, "cloudflare.com": true, "facebook.com": true,
	"github.com": true, "githubusercontent.com": true, "paypal.com": true, "mozilla.org": true,
}

// Decision says whether a request should be stopped, and why.
type Decision struct {
	Block    bool
	Category string // ads, trackers, malware, phishing, download
	Reason   string
	Quiet    bool // for ads and trackers: answer "204 No Content" instead of an error page
}

type Engine struct {
	ads, trackers, malware map[string]struct{}
}

func loadSet(text string) map[string]struct{} {
	set := make(map[string]struct{}, strings.Count(text, "\n"))
	for _, line := range strings.Split(text, "\n") {
		d := strings.ToLower(strings.TrimSpace(line))
		if d == "" || strings.HasPrefix(d, "#") || protectedDomains[d] {
			continue
		}
		set[d] = struct{}{}
	}
	return set
}

func NewEngine() *Engine {
	return &Engine{ads: loadSet(adsList), trackers: loadSet(trackersList), malware: loadSet(malwareList)}
}

func (e *Engine) Counts() (ads, trackers, malware int) {
	return len(e.ads), len(e.trackers), len(e.malware)
}

// inSet reports whether host or any parent domain of it is in the set (ads.example.com matches example.com).
func inSet(set map[string]struct{}, host string) bool {
	for {
		if _, ok := set[host]; ok {
			return true
		}
		i := strings.IndexByte(host, '.')
		if i < 0 {
			return false
		}
		host = host[i+1:]
	}
}

func normalizeHost(h string) string {
	return strings.TrimSuffix(strings.ToLower(strings.TrimSpace(h)), ".")
}

// isLocalHost: this computer and the local network are never filtered and never sent through an upstream server.
func isLocalHost(host string) bool {
	h := normalizeHost(host)
	if h == "" || h == "localhost" || !strings.Contains(h, ".") && net.ParseIP(h) == nil {
		return true
	}
	for _, suffix := range []string{".local", ".lan", ".internal", ".home.arpa", ".localhost"} {
		if strings.HasSuffix(h, suffix) {
			return true
		}
	}
	if ip := net.ParseIP(strings.Trim(h, "[]")); ip != nil {
		return ip.IsLoopback() || ip.IsPrivate() || ip.IsLinkLocalUnicast() || ip.IsUnspecified()
	}
	return false
}

func hostAllowed(host string, allow []string) bool {
	h := normalizeHost(host)
	for _, a := range allow {
		a = normalizeHost(a)
		if a != "" && (h == a || strings.HasSuffix(h, "."+a)) {
			return true
		}
	}
	return false
}

// SessionAllow holds hosts the user chose to let through once; it is forgotten when the program closes.
type SessionAllow struct {
	mu    sync.RWMutex
	hosts map[string]bool
}

func (s *SessionAllow) Add(host string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.hosts == nil {
		s.hosts = map[string]bool{}
	}
	s.hosts[normalizeHost(host)] = true
}

func (s *SessionAllow) Has(host string) bool {
	if s == nil {
		return false
	}
	s.mu.RLock()
	defer s.mu.RUnlock()
	h := normalizeHost(host)
	for {
		if s.hosts[h] {
			return true
		}
		i := strings.IndexByte(h, '.')
		if i < 0 {
			return false
		}
		h = h[i+1:]
	}
}

func (e *Engine) exempt(host string, cfg *Config, sess *SessionAllow) bool {
	return !cfg.Enabled || isLocalHost(host) || hostAllowed(host, cfg.Allow) || sess.Has(host)
}

// DecideHost checks a host name against the lists (used for HTTPS tunnels, where only the name is visible).
func (e *Engine) DecideHost(host string, cfg *Config, sess *SessionAllow) Decision {
	h := normalizeHost(host)
	if e.exempt(h, cfg, sess) {
		return Decision{}
	}
	switch {
	case cfg.Malware && inSet(e.malware, h):
		return Decision{Block: true, Category: "malware", Reason: "known malicious or crypto-mining domain"}
	case cfg.Ads && inSet(e.ads, h):
		return Decision{Block: true, Category: "ads", Reason: "ad or unwanted-content domain", Quiet: true}
	case cfg.Trackers && inSet(e.trackers, h):
		return Decision{Block: true, Category: "trackers", Reason: "tracker", Quiet: true}
	}
	return Decision{}
}

// DecideURL does everything DecideHost does, then runs the look-alike / phishing checks on the address.
func (e *Engine) DecideURL(u *url.URL, cfg *Config, sess *SessionAllow) Decision {
	if d := e.DecideHost(u.Hostname(), cfg, sess); d.Block {
		return d
	}
	if cfg.Phishing && !e.exempt(u.Hostname(), cfg, sess) {
		if score, reasons := assessURL(u); score >= 3 {
			return Decision{Block: true, Category: "phishing", Reason: strings.Join(reasons, "; ")}
		}
	}
	return Decision{}
}
