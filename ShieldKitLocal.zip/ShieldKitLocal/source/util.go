package main

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"sort"
	"time"
)

func randomToken() string {
	b := make([]byte, 16)
	if _, err := rand.Read(b); err != nil {
		panic(err)
	}
	return hex.EncodeToString(b)
}

func sortStrings(s []string) { sort.Strings(s) }

func contextWithTimeout(d time.Duration) (context.Context, context.CancelFunc) {
	return context.WithTimeout(context.Background(), d)
}
