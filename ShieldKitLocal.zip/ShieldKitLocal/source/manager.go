package main

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"sync"
	"time"
)

type ConnInfo struct {
	ServerID   string    `json:"serverId"`
	Verdict    Verdict   `json:"verdict"`
	IP         IPInfo    `json:"ip"`
	BaselineIP string    `json:"baselineIp,omitempty"`
	CheckedAt  time.Time `json:"checkedAt"`
}

// Manager connects to, checks and disconnects from servers ("locations").
type Manager struct {
	store *Store
	proxy *Proxy

	mu         sync.Mutex
	last       *ConnInfo
	retryDelay time.Duration
	lookup     func(ctx context.Context, c *http.Client) (IPInfo, error)
}

func NewManager(store *Store, proxy *Proxy) *Manager {
	return &Manager{store: store, proxy: proxy, retryDelay: 2 * time.Second, lookup: lookupIP}
}

func (m *Manager) Last() *ConnInfo {
	m.mu.Lock()
	defer m.mu.Unlock()
	if m.last == nil {
		return nil
	}
	c := *m.last
	return &c
}

func (m *Manager) setActive(id string) {
	_ = m.store.Update(func(c *Config) error { c.Active = id; return nil })
}

func (m *Manager) Disconnect() {
	m.setActive("")
	m.mu.Lock()
	m.last = nil
	m.mu.Unlock()
}

func (m *Manager) lookupVia(ctx context.Context, tries int) (*IPInfo, error) {
	var last error
	for i := 0; i < tries; i++ {
		if i > 0 {
			select {
			case <-time.After(m.retryDelay):
			case <-ctx.Done():
				return nil, ctx.Err()
			}
		}
		ip, err := m.lookup(ctx, m.proxy.Client(true))
		if err == nil {
			return &ip, nil
		}
		last = err
	}
	return nil, last
}

// Connect switches to a server, then proves it works: your address must change and (ideally) land in the right country.
// If it does not work, ShieldKit Local goes back to a direct connection instead of leaving you stuck.
func (m *Manager) Connect(ctx context.Context, id string) (*ConnInfo, error) {
	cfg := m.store.Get()
	var srv *Server
	for i := range cfg.Servers {
		if cfg.Servers[i].ID == id {
			s := cfg.Servers[i]
			srv = &s
		}
	}
	if srv == nil {
		return nil, errors.New("unknown server")
	}
	if srv.Bridge {
		api, ok := validAPI(cfg.BridgeAPI)
		if !ok {
			return nil, errors.New("the local client address must be on this computer, for example http://127.0.0.1:9090")
		}
		if err := bridgeSelect(ctx, api, srv.Group); err != nil {
			return nil, fmt.Errorf("%w. Is the local client still running?", err)
		}
	}

	m.setActive("") // measure the baseline on a direct connection
	var baseline *IPInfo
	if ip, err := m.lookup(ctx, m.proxy.Client(false)); err == nil {
		baseline = &ip
	}
	m.setActive(id)

	tries := 1
	if srv.Bridge {
		tries = 3 // a country group needs a moment to find a working free server
	}
	via, err := m.lookupVia(ctx, tries)
	var verdict Verdict
	switch {
	case err != nil && srv.Bridge:
		verdict = Verdict{"fail", fmt.Sprintf("No free server in %s answered right now (%v). Free servers come and go; try another country.", name(srv.Country), err)}
	case err != nil:
		verdict = Verdict{"fail", fmt.Sprintf("The server did not respond (%v). Check host, port, type and login.", err)}
	default:
		verdict = judge(baseline, via, srv.Country)
	}
	if verdict.Level == "fail" {
		m.Disconnect()
		return nil, errors.New(verdict.Text + " You are not connected.")
	}
	info := &ConnInfo{ServerID: id, Verdict: verdict, IP: *via, CheckedAt: time.Now()}
	if baseline != nil {
		info.BaselineIP = baseline.IP
	}
	m.mu.Lock()
	m.last = info
	m.mu.Unlock()
	return info, nil
}

// Retest checks the current connection again.
func (m *Manager) Retest(ctx context.Context) (*ConnInfo, error) {
	cfg := m.store.Get()
	srv := cfg.activeServer()
	if srv == nil {
		return nil, errors.New("not connected")
	}
	via, err := m.lookupVia(ctx, 1)
	if err != nil {
		return nil, fmt.Errorf("no response through the server (%v)", err)
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	var baseline *IPInfo
	if m.last != nil && m.last.BaselineIP != "" {
		baseline = &IPInfo{IP: m.last.BaselineIP}
	}
	info := &ConnInfo{ServerID: srv.ID, Verdict: judge(baseline, via, srv.Country), IP: *via, CheckedAt: time.Now()}
	if baseline != nil {
		info.BaselineIP = baseline.IP
	}
	m.last = info
	return info, nil
}

// Resume re-selects the country group of a free server after a restart (sing-box forgets it when it restarts).
func (m *Manager) Resume(ctx context.Context) {
	cfg := m.store.Get()
	if srv := cfg.activeServer(); srv != nil && srv.Bridge {
		if api, ok := validAPI(cfg.BridgeAPI); ok {
			_ = bridgeSelect(ctx, api, srv.Group)
		}
	}
}
