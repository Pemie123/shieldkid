package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sync"
)

// sysProxy changes the operating system's "automatic proxy configuration" so every app that follows the system
// settings uses ShieldKit Local without being set up one by one.
//
// Safety rules, because this touches your network settings:
//   - the original settings are saved to a backup file BEFORE anything is changed;
//   - they are restored when ShieldKit Local stops (Ctrl+C, closing the window, logging out);
//   - if a run ever dies without restoring, the next start or `shieldkid off` restores the backup;
//   - the address set is the DIRECT-fallback proxy.pac, so if ShieldKit Local is not running apps simply connect directly.
type sysProxy interface {
	Name() string
	Capture() (map[string]string, error) // what the settings are right now
	Apply(pacURL string) error
	// Verify reads the settings back and fails unless they really point at pacURL. A command that says "OK" proves nothing.
	Verify(pacURL string) error
	Restore(saved map[string]string) error
}

// sysProxyFactory picks the implementation for this operating system. Tests replace it.
var sysProxyFactory = newSysProxy

type sysState struct {
	Platform string            `json:"platform"`
	PAC      string            `json:"pac"`
	Saved    map[string]string `json:"saved"`
}

func writeState(path string, st sysState) error {
	if err := os.MkdirAll(filepath.Dir(path), 0o700); err != nil {
		return err
	}
	data, _ := json.MarshalIndent(st, "", "  ")
	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, data, 0o600); err != nil {
		return err
	}
	return os.Rename(tmp, path)
}

// restoreBackup puts back the settings saved by an earlier run. It reports whether there was anything to restore.
func restoreBackup(sp sysProxy, path string) (bool, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return false, nil
	}
	var st sysState
	if json.Unmarshal(data, &st) != nil || st.Platform != sp.Name() {
		_ = os.Remove(path) // not ours or unreadable: nothing safe to restore
		return false, nil
	}
	if err := sp.Restore(st.Saved); err != nil {
		return false, fmt.Errorf("could not restore your earlier settings: %w", err)
	}
	_ = os.Remove(path)
	return true, nil
}

// activateSystemProxy points the system at pacURL. The returned function restores the original settings (safe to call twice).
func activateSystemProxy(sp sysProxy, statePath, pacURL string, log func(string)) (func(), error) {
	if ok, err := restoreBackup(sp, statePath); err != nil {
		log(err.Error() + ". Run: shieldkid off")
	} else if ok {
		log("Restored your earlier network settings (a previous run did not close cleanly).")
	}
	saved, err := sp.Capture()
	if err != nil {
		return nil, err
	}
	if err := writeState(statePath, sysState{Platform: sp.Name(), PAC: pacURL, Saved: saved}); err != nil {
		return nil, fmt.Errorf("cannot save a backup of your settings, so they were not changed: %w", err)
	}
	if err := sp.Apply(pacURL); err != nil {
		_ = sp.Restore(saved) // undo any half-applied change
		_ = os.Remove(statePath)
		return nil, err
	}
	if err := sp.Verify(pacURL); err != nil {
		_ = sp.Restore(saved)
		_ = os.Remove(statePath)
		return nil, fmt.Errorf("the system did not keep the change (%v), so nothing was changed", err)
	}
	var once sync.Once
	return func() {
		once.Do(func() {
			if err := sp.Restore(saved); err != nil {
				log("Could not restore your network settings automatically: " + err.Error() + ". Run: shieldkid off")
				return
			}
			_ = os.Remove(statePath)
		})
	}, nil
}
