package main

import (
	"net"
	"net/url"
	"regexp"
	"strings"
)

// Same heuristics as the browser extension: look-alike brands, user@host tricks, raw IPs, punycode, scam-prone endings.
var brands = map[string][]string{
	"paypal": {"paypal.com"}, "apple": {"apple.com"}, "icloud": {"icloud.com"},
	"microsoft": {"microsoft.com", "live.com", "office.com"}, "office365": {"office.com"},
	"google": {"google.com"}, "gmail": {"gmail.com", "google.com"},
	"amazon": {"amazon.com"}, "facebook": {"facebook.com"}, "instagram": {"instagram.com"},
	"netflix": {"netflix.com"}, "whatsapp": {"whatsapp.com"}, "linkedin": {"linkedin.com"},
	"dropbox": {"dropbox.com"}, "docusign": {"docusign.com", "docusign.net"},
	"dhl": {"dhl.com"}, "bpost": {"bpost.be"}, "belfius": {"belfius.be"}, "kbc": {"kbc.be"},
	"itsme": {"itsme.be", "itsme-id.com"}, "argenta": {"argenta.be"}, "bnpparibasfortis": {"bnpparibasfortis.be"},
}

var (
	ccSLD      = map[string]bool{"co": true, "com": true, "org": true, "net": true, "gov": true, "ac": true, "edu": true}
	riskyTLD   = map[string]bool{"tk": true, "ml": true, "ga": true, "cf": true, "gq": true, "zip": true, "mov": true, "click": true}
	loginWords = regexp.MustCompile(`(?i)(login|log-in|signin|sign-in|verify|account|secure|update|password|wallet|billing|confirm)`)
	ipv4Re     = regexp.MustCompile(`^\d{1,3}(\.\d{1,3}){3}$`)
)

func registrableIndex(labels []string) int {
	n := len(labels)
	if n >= 3 && len(labels[n-1]) == 2 && ccSLD[labels[n-2]] {
		return n - 3
	}
	if n-2 < 0 {
		return 0
	}
	return n - 2
}

// assessURL returns a suspicion score (3 or more is treated as phishing) and the reasons.
func assessURL(u *url.URL) (int, []string) {
	host := normalizeHost(u.Hostname())
	if isLocalHost(host) || net.ParseIP(host) != nil && !ipv4Re.MatchString(host) {
		return 0, nil
	}
	var reasons []string
	score := 0
	labels := strings.Split(host, ".")
	reg := registrableIndex(labels)
	add := func(n int, why string) { score += n; reasons = append(reasons, why) }

	if u.User != nil {
		add(3, "the address hides its real destination behind a username (user@host trick)")
	}
	if ipv4Re.MatchString(host) {
		add(2, "uses a raw IP address instead of a domain name")
	}
	for _, l := range labels {
		if strings.HasPrefix(l, "xn--") {
			add(2, "domain uses look-alike (punycode) characters")
			break
		}
	}
	if tld := labels[len(labels)-1]; riskyTLD[tld] {
		add(1, "the ."+tld+" ending is often abused for scams")
	}
	if len(labels) > 5 {
		add(1, "unusually many subdomains")
	}
	if len(strings.Split(labels[reg], "-")) > 3 {
		add(1, "domain name stuffed with hyphens")
	}
	if len(host) > 60 {
		add(1, "extremely long domain name")
	}
	if loginWords.MatchString(host+u.Path) && (u.Scheme == "http" || ipv4Re.MatchString(host)) {
		add(1, "asks for account details on an insecure or unnamed host")
	}

	seen := map[string]bool{}
	for i, label := range labels {
		for _, token := range strings.Split(label, "-") {
			official, ok := brands[token]
			if !ok || seen[token] {
				continue
			}
			isOfficial := false
			for _, d := range official {
				if host == d || strings.HasSuffix(host, "."+d) {
					isOfficial = true
				}
			}
			if isOfficial || (i == reg && label == token) { // e.g. google.be, amazon.de
				continue
			}
			seen[token] = true
			add(3, "looks like it is imitating “"+token+"” but is not its official site")
		}
	}
	return score, reasons
}
