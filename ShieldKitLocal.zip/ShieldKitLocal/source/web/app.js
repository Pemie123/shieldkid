(() => {
  'use strict';
  const $ = (s, el = document) => el.querySelector(s);
  // Builds elements with textContent only, so nothing from a website or a server list can ever become HTML.
  const h = (tag, props, ...kids) => {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(props || {})) {
      if (k === 'class') el.className = v;
      else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else if (v === true) el.setAttribute(k, '');
      else if (v !== false && v != null) el.setAttribute(k, v);
    }
    for (const kid of kids.flat()) if (kid != null && kid !== false) el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
    return el;
  };
  async function api(path, body) {
    const opt = body === undefined ? {} : { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-ShieldKit': '1' }, body: JSON.stringify(body) };
    const res = await fetch(path, opt);
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || res.statusText);
    return data;
  }
  const regionNames = new Intl.DisplayNames(['en'], { type: 'region' });
  const cname = c => { try { return regionNames.of(c) || c; } catch (e) { return c; } };
  const fmt = n => new Intl.NumberFormat().format(n);

  let S = null, tab = 'overview', filter = '';

  function banner(text, level) {
    const b = $('#banner');
    b.textContent = text || '';
    b.className = 'banner' + (level ? ' ' + level : '');
    b.hidden = !text;
  }
  async function guarded(button, fn) {
    if (button) button.disabled = true;
    try { await fn(); } catch (e) { banner(e.message, 'bad'); } finally { if (button) button.disabled = false; }
  }
  async function set(patch) { await api('/api/settings', patch); await load(); }

  // ---------------------------------------------------------------- shared pieces
  function toggle(key, name, desc) {
    const input = h('input', { type: 'checkbox' });
    input.checked = !!S.settings[key];
    input.addEventListener('change', () => guarded(null, () => set({ [key]: input.checked })));
    return h('label', { class: 'row' }, h('div', null, h('div', { class: 'name' }, name), h('div', { class: 'desc' }, desc)),
      h('span', { class: 'switch' }, input, h('span', { class: 'track' })));
  }
  function copyRow(text) {
    const b = h('button', { class: 'small', type: 'button' }, 'Copy');
    b.addEventListener('click', async () => { try { await navigator.clipboard.writeText(text); b.textContent = 'Copied'; setTimeout(() => (b.textContent = 'Copy'), 1500); } catch (e) { banner('Could not copy; select the text and copy it by hand.', 'bad'); } });
    return h('div', { class: 'copy' }, h('code', null, text), b);
  }

  // ---------------------------------------------------------------- header
  function renderHeader() {
    $('#ver').textContent = ' v' + S.version;
    $('#master').checked = S.settings.enabled;
    $('#masterText').textContent = S.settings.enabled ? 'Protection on' : 'Protection off';
  }

  // ---------------------------------------------------------------- overview
  const STATS = [['ads', 'Ads blocked'], ['trackers', 'Trackers blocked'], ['malware', 'Malicious sites blocked'], ['phishing', 'Phishing sites blocked'],
    ['download', 'Downloads blocked'], ['safesearch', 'SafeSearch applied'], ['upgraded', 'Links upgraded'], ['stripped', 'Tracking tags removed']];
  const BLOCKS = new Set(['ads', 'trackers', 'malware', 'phishing', 'download']);

  async function renderOverview() {
    const el = $('#tab-overview');
    const log = await api('/api/log');
    const rows = log.events.slice(0, 30).map(e => h('tr', null,
      h('td', { class: 'muted' }, new Date(e.time).toLocaleTimeString()),
      h('td', { class: 'mono' }, e.host),
      h('td', null, h('span', { class: 'tag ' + e.category }, e.category)),
      h('td', { class: 'muted' }, e.reason),
      h('td', null, BLOCKS.has(e.category) ? h('button', { class: 'small', type: 'button', title: 'Never block this site', onclick: ev => guarded(ev.target, async () => { await api('/api/allow', { action: 'add', host: e.host }); banner(e.host + ' is now allowed.', 'ok'); await load(); }) }, 'Allow') : null)));
    el.replaceChildren(
      h('h2', null, 'What ShieldKit Local is doing'),
      h('p', { class: 'muted' }, `Listening on ${S.listen}. Using ${fmt(S.lists.ads)} ad and unwanted-site domains, ${S.lists.trackers} trackers and ${S.lists.malware} crypto-miner domains. `,
        S.active ? 'Traffic goes through a server (see Location). ' : 'Traffic goes out directly. ',
        S.systemProxy ? 'Your system settings point at ShieldKit Local, so apps that follow them are protected.' : 'Your system settings are not changed: point an app at it (see “Use in apps”) or start the app with “shieldkid run”.'),
      h('div', { class: 'cards' }, STATS.map(([k, label]) => h('div', { class: 'card stat' }, h('b', null, fmt(log.counts[k] || 0)), h('span', { class: 'muted' }, label)))),
      h('h3', null, 'Recent activity'),
      rows.length ? h('div', { class: 'card' }, h('table', null, h('thead', null, h('tr', null, ['Time', 'Site', 'What', 'Why', ''].map(t => h('th', null, t)))), h('tbody', null, rows)))
        : h('p', { class: 'muted' }, 'Nothing yet. Point an app at this proxy (see “Use in apps”) and blocked requests will appear here.'));
  }

  // ---------------------------------------------------------------- protection
  function renderProtection() {
    const el = $('#tab-protection');
    const yt = h('select', { 'aria-label': 'YouTube Restricted Mode' }, ['off', 'moderate', 'strict'].map(v => h('option', { value: v }, v === 'off' ? 'Off' : v[0].toUpperCase() + v.slice(1))));
    yt.value = S.settings.youtube;
    yt.addEventListener('change', () => guarded(null, () => set({ youtube: yt.value })));
    const allowInput = h('input', { type: 'text', placeholder: 'example.com', 'aria-label': 'Site to always allow', autocomplete: 'off', spellcheck: 'false' });
    const keyInput = h('input', { type: 'password', placeholder: S.hasGoogleKey ? 'A key is saved (hidden)' : 'AIza…', autocomplete: 'off', 'aria-label': 'Google Places API key' });
    el.replaceChildren(
      h('h2', null, 'Protection'),
      h('p', { class: 'muted' }, 'Because ShieldKit Local does not open your encrypted (HTTPS) traffic, it works with website names and, for plain HTTP, addresses. See “Use in apps” for what that means.'),
      h('h3', null, 'Blocking'),
      h('div', { class: 'card' }, toggle('ads', 'Ads and unwanted sites', 'About 61,000 ad, scam and unwanted-content domains'), toggle('trackers', 'Trackers', 'Analytics and session recorders'), toggle('malware', 'Malicious domains', 'Crypto-miners and known bad hosts')),
      h('h3', null, 'Safety'),
      h('div', { class: 'card' },
        toggle('phishing', 'Phishing warnings', 'Look-alike banks and brands, user@host tricks, raw IP addresses'),
        toggle('downloads', 'Safe downloads (plain HTTP)', 'Blocks disguised files (invoice.pdf.exe) and programs sent over unencrypted HTTP'),
        toggle('downloadsStrict', 'Strict download checks', 'Also blocks archives sent over plain HTTP'),
        toggle('upgradeHttp', 'Upgrade HTTP to HTTPS', 'Redirects plain-HTTP page loads to HTTPS. Can break apps that only speak HTTP, so it is off by default')),
      h('h3', null, 'Search'),
      h('div', { class: 'card' }, toggle('safeSearch', 'Strict SafeSearch', 'Google, Bing and DuckDuckGo via their official safe servers'),
        h('div', { class: 'row' }, h('div', null, h('div', { class: 'name' }, 'YouTube Restricted Mode'), h('div', { class: 'desc' }, 'Uses YouTube’s official restricted servers')), yt)),
      h('h3', null, 'Privacy (plain HTTP only)'),
      h('div', { class: 'card' }, toggle('stripParams', 'Clean links', 'Removes utm_, fbclid, gclid and similar. Off by default so app requests are never altered'), toggle('privacyHeaders', 'Privacy signals', 'Sends Global Privacy Control and Do Not Track')),
      h('h3', null, 'Allowed sites'),
      h('p', { class: 'muted' }, 'These are never blocked or rewritten (updates for Windows, Apple and Ubuntu are in the list by default).'),
      h('div', { class: 'card' },
        S.allow.map(a => h('div', { class: 'row' }, h('span', { class: 'mono' }, a), h('button', { class: 'small', type: 'button', onclick: ev => guarded(ev.target, async () => { await api('/api/allow', { action: 'remove', host: a }); await load(); }) }, 'Remove'))),
        h('div', { class: 'row' }, allowInput, h('button', { class: 'primary', type: 'button', onclick: ev => guarded(ev.target, async () => { await api('/api/allow', { action: 'add', host: allowInput.value }); await load(); }) }, 'Add'))),
      h('h3', null, 'Google reviews key (optional)'),
      h('p', { class: 'muted' }, 'Adds Google as a fourth source for site ratings. Google only provides ratings through its paid Places API, so you need your own key (Google Cloud → “Places API (New)”).'),
      h('div', { class: 'form' }, h('label', null, 'Places API key', keyInput),
        h('button', { class: 'primary', type: 'button', onclick: ev => guarded(ev.target, async () => { await set({ googleKey: keyInput.value.trim() }); banner('Key saved.', 'ok'); }) }, 'Save key'),
        h('button', { type: 'button', onclick: ev => guarded(ev.target, async () => { await set({ googleKey: '' }); banner('Key removed.'); }) }, 'Remove key')));
  }

  // ---------------------------------------------------------------- location
  function renderLocation() {
    const el = $('#tab-location');
    const active = S.servers.find(s => s.id === S.active);
    const conn = S.connection && S.connection.serverId === S.active ? S.connection : null;
    const status = h('div', { class: 'status' + (conn ? (conn.verdict.level === 'ok' ? ' ok' : ' warn') : '') },
      h('div', { class: 'badge' }, active ? active.country : '–'),
      h('div', null, h('strong', null, active ? `${cname(active.country)} · ${active.name}` : 'Not connected'),
        h('div', { class: 'muted' }, active ? (conn ? `${conn.verdict.level === 'ok' ? 'Verified' : 'Check result'}: your IP is ${conn.ip.ip}${conn.ip.city ? ' (' + conn.ip.city + ', ' + cname(conn.ip.country) + (conn.ip.org ? ', ' + conn.ip.org : '') + ')' : ''}` : 'Connected. Press “Test again” to verify.') : 'Traffic goes out directly from this computer.')),
      active ? h('div', { class: 'actions' },
        h('button', { type: 'button', onclick: ev => guarded(ev.target, async () => { const i = await api('/api/retest', {}); banner(i.verdict.text, i.verdict.level === 'ok' ? 'ok' : ''); await load(); }) }, 'Test again'),
        h('button', { type: 'button', onclick: ev => guarded(ev.target, async () => { await api('/api/disconnect', {}); banner('Disconnected. Traffic goes out directly.'); await load(); }) }, 'Disconnect')) : null);

    const search = h('input', { type: 'search', placeholder: 'Search countries', 'aria-label': 'Search countries', autocomplete: 'off', value: filter });
    const list = h('ul', { class: 'countries' });
    const fillList = () => {
      const q = filter.trim().toLowerCase();
      const rows = S.countries.map(code => ({ code, name: cname(code), servers: S.servers.filter(s => s.country === code) }))
        .filter(c => !q || c.name.toLowerCase().includes(q) || c.code.toLowerCase() === q)
        .sort((a, b) => (b.servers.length > 0) - (a.servers.length > 0) || a.name.localeCompare(b.name));
      list.replaceChildren(...(rows.length ? rows.map(c => {
        const isActive = active && active.country === c.code;
        const actions = h('span', { class: 'actions' });
        if (c.servers.length) {
          let pick = null;
          if (c.servers.length > 1) { pick = h('select', { 'aria-label': 'Server in ' + c.name }, c.servers.map(s => h('option', { value: s.id }, s.name))); if (isActive) pick.value = active.id; actions.append(pick); }
          actions.append(h('button', { type: 'button', class: 'small', onclick: ev => guarded(ev.target, async () => {
            if (isActive) { await api('/api/disconnect', {}); banner('Disconnected.'); }
            else { banner(`Connecting to ${c.name}…`); const i = await api('/api/connect', { id: pick ? pick.value : c.servers[0].id }); banner(i.verdict.text, i.verdict.level === 'ok' ? 'ok' : ''); }
            await load();
          }) }, isActive ? 'Disconnect' : 'Connect'));
        } else {
          actions.append(h('button', { type: 'button', class: 'small', onclick: () => { $('#fCountry').value = c.name; $('#fHost').focus(); $('#fHost').scrollIntoView({ block: 'center' }); } }, 'Add server'));
        }
        return h('li', { class: isActive ? 'active' : c.servers.length ? '' : 'none' }, h('span', { class: 'code' }, c.code),
          h('span', null, c.name + (c.servers.length ? `  ·  ${c.servers.length} server${c.servers.length > 1 ? 's' : ''}` : '  ·  no server added')), actions);
      }) : [h('li', null, 'No country matches your search.')]));
    };
    search.addEventListener('input', () => { filter = search.value; fillList(); });
    fillList();

    const mine = S.servers.filter(s => !s.bridge);
    const bridgeCount = S.servers.filter(s => s.bridge).length;
    const f = {};
    const field = (id, label, props) => { f[id] = h('input', Object.assign({ id, type: 'text', autocomplete: 'off', spellcheck: 'false' }, props)); return h('label', null, label, f[id]); };
    const scheme = h('select', { id: 'fScheme' }, h('option', { value: 'https' }, 'HTTPS proxy'), h('option', { value: 'http' }, 'HTTP proxy'), h('option', { value: 'socks5' }, 'SOCKS5 (login supported)'));
    const importText = h('textarea', { rows: 5, spellcheck: 'false', 'aria-label': 'Servers to import' });
    const apiInput = h('input', { type: 'text', value: S.settings.bridgeApi, spellcheck: 'false', 'aria-label': 'Local client address' });
    const portInput = h('input', { type: 'number', value: S.settings.bridgePort, 'aria-label': 'Local client proxy port' });

    el.replaceChildren(
      h('h2', null, 'Location'),
      h('p', { class: 'muted' }, 'Send everything that goes through ShieldKit Local out through a server in another country. Every country is listed; connect to any one you have a server for. Connecting is verified: your IP address must change, and ideally land in the right country.'),
      status,
      h('h3', null, 'Choose a location'), search, h('div', { class: 'card' }, list),
      h('h3', null, 'Free servers from a local client (sing-box)'),
      h('p', { class: 'muted' }, 'For public VLESS, VMess, Trojan and Shadowsocks lists such as Hidashimora/free-vpn-anti-rkn. A small open-source client (sing-box) speaks those protocols; ShieldKit Local sends traffic to it and switches its country groups.'),
      h('ol', { class: 'steps' }, h('li', null, 'Install sing-box (sing-box.sagernet.org).'),
        h('li', null, 'Run ', h('code', null, 'python3 tools/subscription_to_singbox.py --singbox sing-box'), ' in the ShieldKit Local folder (python3 is needed).'),
        h('li', null, 'Run ', h('code', null, 'sing-box run -c shieldkit-singbox.json'), ' and leave it open, then press Load countries.')),
      h('div', { class: 'form' }, h('label', null, 'Client address', apiInput), h('label', null, 'Client proxy port', portInput),
        h('button', { class: 'primary', type: 'button', onclick: ev => guarded(ev.target, async () => { banner('Loading countries…'); const r = await api('/api/bridge/load', { api: apiInput.value, port: Number(portInput.value) }); banner(`Loaded ${r.countries} countries. Pick one in the list above.`, 'ok'); await load(); }) }, 'Load countries'),
        h('button', { type: 'button', onclick: ev => guarded(ev.target, async () => { await api('/api/bridge/clear', {}); banner('Free servers removed.'); await load(); }) }, 'Remove free servers')),
      h('p', { class: 'muted' }, bridgeCount ? `${bridgeCount} countries loaded from the local client.` : ''),
      h('div', { class: 'caution' }, h('b', null, 'Know the risk. '), 'These servers belong to anonymous strangers and the lists are re-published automatically without vetting. A server’s operator can see which sites you visit and can tamper with plain HTTP traffic. Do not sign in to banking, email or other important accounts through them.'),
      h('h3', null, 'Your servers'),
      h('p', { class: 'muted' }, 'HTTPS or HTTP proxies (with login if needed), or SOCKS5 servers, with or without a login. ShieldKit Local does not supply servers.'),
      mine.length ? h('div', { class: 'card' }, h('table', null, h('thead', null, h('tr', null, ['Country', 'Name', 'Server', 'Login', ''].map(t => h('th', null, t)))),
        h('tbody', null, mine.map(s => h('tr', null, h('td', null, cname(s.country)), h('td', null, s.name), h('td', { class: 'mono' }, `${s.scheme}://${s.host}:${s.port}`), h('td', null, s.hasLogin ? 'yes' : 'no'),
          h('td', null, h('button', { class: 'small', type: 'button', onclick: ev => guarded(ev.target, async () => { await api('/api/servers', { action: 'remove', id: s.id }); await load(); }) }, 'Remove'))))))) : h('p', { class: 'muted' }, 'No servers of your own yet.'),
      h('h3', null, 'Add a server'),
      h('div', { class: 'form' }, field('fCountry', 'Country', { placeholder: 'Belgium or BE' }), field('fName', 'Name (optional)', { placeholder: 'Brussels 1' }),
        h('label', null, 'Type', scheme), field('fHost', 'Host', { placeholder: 'be1.proxy.example.com' }), field('fPort', 'Port', { placeholder: '443', inputmode: 'numeric' }),
        field('fUser', 'Username'), h('label', null, 'Password', (f.fPass = h('input', { id: 'fPass', type: 'password', autocomplete: 'new-password' }))),
        h('button', { class: 'primary', type: 'button', onclick: ev => guarded(ev.target, async () => {
          await api('/api/servers', { action: 'add', server: { country: f.fCountry.value, name: f.fName.value, scheme: scheme.value, host: f.fHost.value, port: f.fPort.value, username: f.fUser.value, password: f.fPass.value } });
          banner('Server added.', 'ok'); await load();
        }) }, 'Add server')),
      h('h3', null, 'Import'),
      h('p', { class: 'muted' }, 'Paste JSON or CSV lines: ', h('code', null, 'country,host,port,type,username,password,name')),
      importText,
      h('div', { class: 'actions' }, h('button', { type: 'button', onclick: ev => guarded(ev.target, async () => {
        const r = await api('/api/servers', { action: 'import', text: importText.value });
        banner(`${r.added} added, ${r.updated} updated.` + (r.errors && r.errors.length ? ' Problems: ' + r.errors.slice(0, 3).join(' · ') : ''), r.ok ? (r.errors && r.errors.length ? '' : 'ok') : 'bad');
        if (r.ok) { await load(); }
      }) }, 'Import')),
      h('h3', null, 'Options'),
      h('div', { class: 'card' }, toggle('killSwitch', 'Block traffic if the server stops responding', 'Without this, apps would quietly fall back to your real IP address')),
      h('p', { class: 'muted' }, 'Local network addresses always go direct. Logins are stored unencrypted in ShieldKit Local’s settings file (readable only by you).'));
  }

  // ---------------------------------------------------------------- check a site
  function renderCheck() {
    const el = $('#tab-check');
    const input = h('input', { type: 'text', placeholder: 'bol.com', autocomplete: 'off', spellcheck: 'false', 'aria-label': 'Website to check' });
    const out = h('div', { 'aria-live': 'polite' });
    const run = async btn => {
      out.replaceChildren(h('p', { class: 'muted' }, 'Checking…'));
      await guarded(btn, async () => {
        const r = await api('/api/check', { domain: input.value });
        const tone = s => (s >= 4 ? 'good' : s >= 3 ? 'ok' : 'bad');
        const c = r.combined;
        out.replaceChildren(h('div', { class: 'card', style: 'padding:16px' },
          c ? h('div', null, h('span', { class: 'big ' + tone(c.score) }, `★ ${c.score.toFixed(1)}`), ' ', h('b', null, c.label), h('div', { class: 'muted' }, `${r.domain} · ${c.sources} source${c.sources === 1 ? '' : 's'} · ${c.low ? 'few reviews, take with care' : fmt(c.reviews) + ' reviews'}`))
            : h('div', null, h('b', null, 'No ratings found'), h('div', { class: 'muted' }, r.domain)),
          h('table', { style: 'margin-top:12px' }, h('tbody', null, r.results.map(n => {
            const x = n.result;
            let value;
            if (x.status === 'ok') value = h('span', null, h('b', { class: tone(x.score) }, `★ ${x.score.toFixed(1)}`), x.reviews != null ? h('span', { class: 'muted' }, ` · ${fmt(x.reviews)} reviews`) : null);
            else if (x.status === 'none') value = h('span', { class: 'muted' }, 'Not listed');
            else if (x.status === 'nokey') value = h('span', { class: 'muted' }, 'Add a Google key under Protection to include it');
            else if (x.status === 'badkey') value = h('span', { class: 'bad' }, 'Key rejected');
            else value = h('span', { class: 'muted' }, 'Unavailable: ' + (x.note || 'error') + (x.snippet ? ` (page says: “${x.snippet}”)` : ''));
            return h('tr', null, h('td', null, h('b', null, n.name)), h('td', null, value));
          })))));
      });
    };
    input.addEventListener('keydown', e => { if (e.key === 'Enter') run($('#checkBtn')); });
    el.replaceChildren(h('h2', null, 'Check a site'),
      h('p', { class: 'muted' }, 'One combined rating from Trustpilot, Sitejabber and Reviews.io (and Google if you added a key). Services that fail say why. Lookups go out directly from this computer, not through a location server.'),
      h('div', { class: 'form' }, h('label', null, 'Website', input), h('button', { id: 'checkBtn', class: 'primary', type: 'button', onclick: ev => run(ev.target) }, 'Check')), out);
  }

  // ---------------------------------------------------------------- use in apps
  function renderSetup() {
    const el = $('#tab-setup');
    const addr = S.listen, [host, port] = [addr.split(':')[0], addr.split(':').pop()];
    el.replaceChildren(
      h('h2', null, 'Use ShieldKit Local in your apps'),
      h('h3', null, 'Easiest: turn it on from a terminal'),
      h('p', { class: 'muted' }, 'Type this in a terminal. ShieldKit starts and points your system\u2019s proxy settings at itself, so every app that follows them (Chrome, Edge, Safari and most others) is protected. Press Ctrl+C to turn it off; your settings are restored.'),
      copyRow('shieldkid'),
      h('p', { class: 'muted' }, 'To protect one program only, without touching any setting:'), copyRow('shieldkid run git pull'),
      h('p', { class: 'muted' }, S.systemProxy ? 'Right now: your system settings point at ShieldKit Local.' : 'Right now: your system settings are not changed (it was started with --no-system, or your system does not allow it).'),
      h('p', { class: 'muted' }, 'If you ever need to put your network settings back by hand: ', h('code', null, 'shieldkid off')),
      h('h3', null, 'Or set it up by hand'),
      h('p', { class: 'muted' }, 'ShieldKit Local is a proxy that runs on this computer. Any app that supports an HTTP proxy gets the protections once you point it here. Keep ShieldKit running while you use it.'),
      h('h3', null, '1. The proxy address'),
      copyRow(addr), h('p', { class: 'muted' }, `Host ${host}, port ${port}. It is an HTTP proxy and is used for both HTTP and HTTPS.`),
      h('h3', null, '2. Or: automatic configuration (works for the whole system)'),
      copyRow(S.pac),
      h('p', { class: 'muted' }, 'If ShieldKit Local is closed, apps fall back to a direct connection. For the stricter version that stops all internet instead of skipping protection, use:'), copyRow(S.pacStrict),
      h('h3', null, '3. Where to put it'),
      h('ul', { class: 'steps' },
        h('li', null, h('b', null, 'Windows: '), 'Settings → Network & internet → Proxy. Either “Use setup script” with the automatic configuration address, or “Manual proxy setup” with the host and port above. Chrome and Edge follow this.'),
        h('li', null, h('b', null, 'macOS: '), 'System Settings → Network → your connection → Details → Proxies. Either “Automatic proxy configuration” with the address above, or turn on Web Proxy (HTTP) and Secure Web Proxy (HTTPS) with the host and port.'),
        h('li', null, h('b', null, 'Linux (GNOME): '), 'Settings → Network → Network Proxy → Automatic, with the configuration address above.'),
        h('li', null, h('b', null, 'Firefox: '), 'Settings → General → Network Settings → Manual proxy configuration. HTTP Proxy host and port above, tick “Also use this proxy for HTTPS”.'),
        h('li', null, h('b', null, 'Command line, git, npm, pip and similar: '), 'set the proxy variables for that terminal:')),
      copyRow(`export HTTP_PROXY=http://${addr} HTTPS_PROXY=http://${addr}`),
      copyRow(`$env:HTTP_PROXY="http://${addr}"; $env:HTTPS_PROXY="http://${addr}"`),
      h('p', { class: 'muted' }, 'The first line is for macOS/Linux shells, the second for Windows PowerShell. Test with:'), copyRow(`curl -x http://${addr} https://example.com`),
      h('h3', null, 'What it can and cannot do'),
      h('ul', { class: 'steps' },
        h('li', null, h('b', null, 'Works everywhere: '), 'blocking ad, tracker, scam and crypto-miner domains; phishing look-alike warnings; strict SafeSearch and YouTube Restricted Mode; sending traffic through a location server; checking site ratings.'),
        h('li', null, h('b', null, 'Plain HTTP only: '), 'download checks, upgrading to HTTPS, removing tracking tags, privacy headers. Inside HTTPS these are invisible without decrypting your traffic, which ShieldKit Local deliberately does not do.'),
        h('li', null, h('b', null, 'Not possible here: '), 'hiding ads that are part of a page, removing YouTube video ads, and showing ratings on browser tabs. Those need the ShieldKit browser extension, which works well alongside this program.')),
      h('div', { class: 'caution' }, 'A blocked HTTPS request shows up in the app as a connection error. If something breaks, open Overview, find the site in Recent activity, and press Allow.'));
  }

  // ---------------------------------------------------------------- wiring
  const renderers = { overview: renderOverview, protection: renderProtection, location: renderLocation, check: renderCheck, setup: renderSetup };
  async function render() {
    renderHeader();
    for (const t of Object.keys(renderers)) $('#tab-' + t).hidden = t !== tab;
    document.querySelectorAll('.tabs button').forEach(b => b.setAttribute('aria-selected', String(b.dataset.tab === tab)));
    await renderers[tab]();
  }
  async function load() { S = await api('/api/state'); await render(); }

  document.querySelectorAll('.tabs button').forEach(b => b.addEventListener('click', () => { tab = b.dataset.tab; banner(''); render(); }));
  $('#master').addEventListener('change', e => guarded(null, () => set({ enabled: e.target.checked })));
  load().catch(e => banner('Cannot reach ShieldKit Local: ' + e.message, 'bad'));
  setInterval(() => { if (tab === 'overview' && !document.hidden) load().catch(() => {}); }, 4000);
})();
