package main

import (
	"errors"
	"flag"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"os/exec"
	"os/signal"
	"runtime"
	"strings"
	"syscall"
	"time"
)

const usage = `ShieldKit Local %s: ad, tracker and malware blocking, phishing warnings, SafeSearch and a location chooser
for every app on this computer.

  shieldkid                   turn it ON: starts ShieldKit and points your system's proxy settings at it, so apps that
                              follow them are protected. Press Ctrl+C to turn it off; your settings are restored.
  shieldkid run COMMAND ...   run one program protected, without touching any system setting (e.g. shieldkid run git pull)
  shieldkid status            is it running, and what has it blocked?
  shieldkid panel             open the control panel in your browser
  shieldkid off               put your network settings back (only needed if a run ever stopped without restoring them)
  shieldkid env               print the proxy variables for a terminal:  eval "$(shieldkid env)"
  shieldkid check DOMAIN      one combined rating from Trustpilot, Sitejabber, Reviews.io (and Google with a key)
  shieldkid install           make "shieldkid" work from any terminal (adds it to your PATH; no admin rights needed)
  shieldkid uninstall         undo "install"
  shieldkid pac [--strict]    print the automatic proxy configuration file
  shieldkid version

Options for turning it on:  --no-system (do not change system settings)  --open / --no-open (control panel)
                            --listen 127.0.0.1:8898  --config FILE
`

func newFlags(name string) *flag.FlagSet {
	fs := flag.NewFlagSet(name, flag.ContinueOnError)
	fs.SetOutput(io.Discard)
	return fs
}

func main() {
	args := os.Args[1:]
	cmd := "start"
	if len(args) > 0 && !strings.HasPrefix(args[0], "-") {
		cmd, args = args[0], args[1:]
	}
	var err error
	switch cmd {
	case "start", "on":
		err = runStart(args)
	case "off":
		err = runOff(args)
	case "status":
		err = runStatus(args)
	case "panel":
		err = runPanel(args)
	case "env":
		err = runEnv(args)
	case "run":
		err = runWrapped(args)
	case "install":
		err = runInstall(args)
	case "uninstall":
		err = runUninstall(args)
	case "check":
		err = runCheck(args)
	case "pac":
		err = runPAC(args)
	case "version":
		fmt.Println("ShieldKit Local", version)
	case "help":
		fmt.Printf(usage, version)
	default:
		fmt.Fprintf(os.Stderr, "unknown command %q\n\n"+usage, cmd, version)
		os.Exit(2)
	}
	if err != nil {
		var ee exitError
		switch {
		case errors.As(err, &ee):
			os.Exit(int(ee))
		case errors.Is(err, flag.ErrHelp):
			fmt.Printf(usage, version)
		default:
			fmt.Fprintln(os.Stderr, "error:", err)
			os.Exit(1)
		}
	}
}

func directClient() *http.Client {
	return &http.Client{Timeout: 15 * time.Second, Transport: &http.Transport{Proxy: nil, TLSHandshakeTimeout: 10 * time.Second}}
}

func runCheck(args []string) error {
	fs := newFlags("check")
	configPath := fs.String("config", defaultConfigPath(), "settings file")
	key := fs.String("google-key", "", "Google Places API key (default: the one saved in the settings)")
	var domain string
	rest := args
	if len(rest) > 0 && !strings.HasPrefix(rest[0], "-") { // the domain may come before or after the options
		domain, rest = rest[0], rest[1:]
	}
	if err := fs.Parse(rest); err != nil {
		return err
	}
	if domain == "" && fs.NArg() > 0 {
		domain = fs.Arg(0)
	}
	domain = normalizeHost(strings.TrimPrefix(strings.TrimPrefix(domain, "https://"), "http://"))
	if i := strings.IndexAny(domain, "/:?#"); i >= 0 {
		domain = domain[:i]
	}
	if !hostRe.MatchString(domain) || !strings.Contains(domain, ".") {
		return errors.New("usage: shieldkid check DOMAIN   (for example: shieldkid check bol.com)")
	}
	if *key == "" {
		if store, err := LoadStore(*configPath); err == nil {
			*key = store.Get().GoogleKey
		}
	}
	ctx, cancel := contextWithTimeout(30 * time.Second)
	defer cancel()
	fmt.Print(NewRatings(directClient()).Check(ctx, domain, *key).Describe())
	return nil
}

func runPAC(args []string) error {
	fs := newFlags("pac")
	configPath := fs.String("config", defaultConfigPath(), "settings file")
	strict := fs.Bool("strict", false, "no DIRECT fallback")
	if err := fs.Parse(args); err != nil {
		return err
	}
	listen, err := listenFromConfig(*configPath)
	if err != nil {
		return err
	}
	fmt.Print(pacScript(listen, *strict))
	return nil
}

func loopbackOnly(addr string) error {
	host, _, err := net.SplitHostPort(addr)
	if err != nil {
		return fmt.Errorf("%q is not a valid address like 127.0.0.1:8899", addr)
	}
	if ip := net.ParseIP(host); (ip == nil || !ip.IsLoopback()) && host != "localhost" {
		return fmt.Errorf("ShieldKit Local only listens on this computer (127.0.0.1); %q would expose it to your network", host)
	}
	return nil
}

// runStart turns ShieldKit on and keeps it on until you press Ctrl+C.
func runStart(args []string) error {
	fs := newFlags("start")
	configPath := fs.String("config", defaultConfigPath(), "settings file")
	listen := fs.String("listen", "", "address to listen on (default 127.0.0.1:8899)")
	noSystem := fs.Bool("no-system", false, "do not change the system's proxy settings")
	open := fs.Bool("open", false, "open the control panel in the browser")
	noOpen := fs.Bool("no-open", false, "never open the control panel by itself")
	if err := fs.Parse(args); err != nil {
		return err
	}
	a, err := startApp(startOptions{configPath: *configPath, listen: *listen, system: !*noSystem, log: func(m string) { fmt.Println("  note:", m) }})
	if err != nil {
		return err
	}
	ads, trackers, malware := a.engine.Counts()
	panelURL := "http://" + a.cfg.Listen + "/"
	fmt.Printf("\nShieldKit is ACTIVE  (v%s)\n", version)
	fmt.Printf("  Proxy:          %s\n", a.cfg.Listen)
	fmt.Printf("  Control panel:  %s\n", panelURL)
	fmt.Printf("  Lists:          %d ad/unwanted domains, %d trackers, %d crypto-miner domains\n", ads, trackers, malware)
	if srv := a.cfg.activeServer(); srv != nil {
		fmt.Printf("  Location:       %s (%s)\n", name(srv.Country), srv.Name)
	}
	switch {
	case a.proxy.SystemOn.Load():
		fmt.Println("  Apps:           your system's proxy settings now point at ShieldKit, so apps that follow them are protected.")
		fmt.Println("                  They go back to normal when you press Ctrl+C.")
	case *noSystem:
		fmt.Println("  Apps:           system settings left alone (--no-system). Point an app at " + a.cfg.Listen + ", or use:  shieldkid run <command>")
	default:
		fmt.Println("  Apps:           NOT protected yet: " + a.systemNote)
		fmt.Println("                  Point an app at " + a.cfg.Listen + " (see the control panel, tab \"Use in apps\"), or use:  shieldkid run <command>")
	}
	if _, err := exec.LookPath("shieldkid"); err != nil {
		exe, _ := os.Executable()
		fmt.Printf("  Tip:            run   %s install   once, then you can just type   shieldkid   in any terminal.\n", exe)
	}
	fmt.Println("\nPress Ctrl+C to turn it off.")

	if !*noOpen && (*open || a.firstRun || a.cfg.OpenBrowser) {
		go func() { time.Sleep(400 * time.Millisecond); openBrowser(panelURL) }()
	}
	stop := make(chan os.Signal, 1)
	signal.Notify(stop, os.Interrupt, syscall.SIGTERM, syscall.SIGHUP) // Ctrl+C, closing the window, logging out
	select {
	case err := <-a.serveErr:
		a.Stop()
		return err
	case <-stop:
		fmt.Println("\nTurning off…")
		a.Stop()
		fmt.Println("ShieldKit is off. Your network settings are back to normal.")
		return nil
	}
}

func openBrowser(url string) {
	var cmd *exec.Cmd
	switch runtime.GOOS {
	case "windows":
		cmd = exec.Command("rundll32", "url.dll,FileProtocolHandler", url)
	case "darwin":
		cmd = exec.Command("open", url)
	default:
		cmd = exec.Command("xdg-open", url)
	}
	_ = cmd.Start()
}
