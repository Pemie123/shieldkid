package main

import (
	"io"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func freePort(t *testing.T) string {
	t.Helper()
	l, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	addr := l.Addr().String()
	l.Close()
	return addr
}

func withFakeSystem(t *testing.T, f *fakeSys) {
	t.Helper()
	saved := sysProxyFactory
	sysProxyFactory = func() sysProxy {
		if f == nil {
			return nil
		}
		return f
	}
	t.Cleanup(func() { sysProxyFactory = saved })
}

func opts(t *testing.T, listen string, system bool, log func(string)) startOptions {
	return startOptions{configPath: filepath.Join(t.TempDir(), "cfg", "config.json"), listen: listen, system: system, log: log}
}

func TestTurningOnAndOff(t *testing.T) {
	fake := newFake()
	withFakeSystem(t, fake)
	o := opts(t, freePort(t), true, nil)
	a, err := startApp(o)
	if err != nil {
		t.Fatal(err)
	}
	pac := "http://" + a.cfg.Listen + "/proxy.pac"
	if fake.current["pac"] != pac || !a.proxy.SystemOn.Load() || a.systemNote != "" {
		t.Fatalf("not activated: %v on=%v note=%q", fake.current, a.proxy.SystemOn.Load(), a.systemNote)
	}
	resp, err := http.Get(pac) // the system fetches exactly this address
	if err != nil {
		t.Fatal(err)
	}
	body, _ := io.ReadAll(resp.Body)
	resp.Body.Close()
	if resp.StatusCode != 200 || !strings.Contains(string(body), "PROXY "+a.cfg.Listen+"; DIRECT") {
		t.Errorf("the PAC address must work and fall back to DIRECT: %d %s", resp.StatusCode, body)
	}
	if _, err := os.Stat(backupPath(o.configPath)); err != nil {
		t.Error("the backup of the original settings must exist while it is on")
	}
	if !a.firstRun {
		t.Error("first run not detected")
	}
	a.Stop()
	if fake.current["pac"] != "original" || a.proxy.SystemOn.Load() {
		t.Errorf("not restored on stop: %v", fake.current)
	}
	if _, err := os.Stat(backupPath(o.configPath)); err == nil {
		t.Error("backup should be removed after a clean stop")
	}
	if _, err := http.Get(pac); err == nil {
		t.Error("the server should be closed after Stop")
	}
}

func TestSecondCopyNeverTouchesSettings(t *testing.T) {
	fake := newFake()
	withFakeSystem(t, fake)
	listen := freePort(t)
	first, err := startApp(opts(t, listen, true, nil))
	if err != nil {
		t.Fatal(err)
	}
	defer first.Stop()
	applied := len(fake.applied)
	o2 := opts(t, listen, true, nil)
	if _, err := startApp(o2); err == nil || !strings.Contains(err.Error(), "already running") {
		t.Fatalf("second copy should be refused with a clear message: %v", err)
	}
	if len(fake.applied) != applied || fake.restores != 0 {
		t.Errorf("the second copy changed the system settings: applied=%d restores=%d", len(fake.applied), fake.restores)
	}
	if fake.current["pac"] != "http://"+listen+"/proxy.pac" {
		t.Error("the first copy's settings were disturbed")
	}
}

func TestCrashThenRestart(t *testing.T) {
	fake := newFake()
	withFakeSystem(t, fake)
	listen := freePort(t)
	o := opts(t, listen, true, nil)
	a, err := startApp(o)
	if err != nil {
		t.Fatal(err)
	}
	a.srv.Close()              // the process dies: no restore happens
	for i := 0; i < 100; i++ { // a dead process frees its port; wait until the closing has finished
		if l, err := net.Listen("tcp", listen); err == nil {
			l.Close()
			break
		}
		time.Sleep(10 * time.Millisecond)
	}
	if fake.current["pac"] == "original" {
		t.Fatal("setup: settings should still point at the dead ShieldKit")
	}
	var msgs []string
	o.log = func(m string) { msgs = append(msgs, m) }
	b, err := startApp(o)
	if err != nil {
		t.Fatal(err)
	}
	if len(msgs) != 1 || !strings.Contains(msgs[0], "did not close cleanly") {
		t.Errorf("should tell the user: %v", msgs)
	}
	b.Stop()
	if fake.current["pac"] != "original" {
		t.Errorf("the ORIGINAL settings must come back after a crash and a clean second run: %v", fake.current)
	}
}

func TestNoSystemOptionAndUnsupportedSystems(t *testing.T) {
	fake := newFake()
	withFakeSystem(t, fake)
	a, err := startApp(opts(t, freePort(t), false, nil))
	if err != nil {
		t.Fatal(err)
	}
	if len(fake.applied) != 0 || a.proxy.SystemOn.Load() {
		t.Error("--no-system must leave the system alone")
	}
	a.Stop()

	withFakeSystem(t, nil)
	a, err = startApp(opts(t, freePort(t), true, nil))
	if err != nil || a.systemNote == "" || a.proxy.SystemOn.Load() {
		t.Fatalf("unsupported system: the proxy must still run and say why: %v %q", err, a.systemNote)
	}
	if resp, err := http.Get("http://" + a.cfg.Listen + "/api/state"); err != nil || resp.StatusCode != 200 {
		t.Error("the proxy must still be up when system settings are unavailable")
	}
	a.Stop()
}

func TestSystemFailureKeepsProxyUpAndSettingsIntact(t *testing.T) {
	fake := newFake()
	fake.applyErr = io.ErrClosedPipe
	withFakeSystem(t, fake)
	a, err := startApp(opts(t, freePort(t), true, nil))
	if err != nil {
		t.Fatal(err)
	}
	defer a.Stop()
	if a.systemNote == "" || a.proxy.SystemOn.Load() || fake.current["pac"] != "original" {
		t.Errorf("a failed system change must be reported and undone: note=%q %v", a.systemNote, fake.current)
	}
}

func TestNonLoopbackIsRefused(t *testing.T) {
	withFakeSystem(t, newFake())
	if _, err := startApp(opts(t, "0.0.0.0:0", true, nil)); err == nil || !strings.Contains(err.Error(), "only listens on this computer") {
		t.Fatalf("%v", err)
	}
}

func TestStateReportsSystemProxy(t *testing.T) {
	withFakeSystem(t, newFake())
	a, err := startApp(opts(t, freePort(t), true, nil))
	if err != nil {
		t.Fatal(err)
	}
	defer a.Stop()
	st, err := instanceState(a.cfg.Listen)
	if err != nil || st["systemProxy"] != true {
		t.Fatalf("%v %v", st, err)
	}
	if _, err := instanceState(freePort(t)); err == nil {
		t.Error("nothing is listening there")
	}
}

func TestEnvLines(t *testing.T) {
	posix := envLines("127.0.0.1:8899", "posix")
	for _, want := range []string{"export HTTP_PROXY='http://127.0.0.1:8899'", "export https_proxy='http://127.0.0.1:8899'", "export NO_PROXY='localhost,127.0.0.1,::1,.local'"} {
		if !strings.Contains(posix, want) {
			t.Errorf("posix missing %q:\n%s", want, posix)
		}
	}
	if ps := envLines("127.0.0.1:8899", "powershell"); !strings.Contains(ps, "$env:HTTPS_PROXY='http://127.0.0.1:8899'") {
		t.Errorf("powershell:\n%s", ps)
	}
	if c := envLines("127.0.0.1:8899", "cmd"); !strings.Contains(c, "set HTTP_PROXY=http://127.0.0.1:8899") {
		t.Errorf("cmd:\n%s", c)
	}
	if len(proxyEnv("x:1")) != 6 {
		t.Error("proxyEnv")
	}
}
