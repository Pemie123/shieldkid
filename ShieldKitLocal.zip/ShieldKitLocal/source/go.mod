module shieldkitlocal

go 1.22
