package main

import (
	"net/url"
	"testing"
)

func mustURL(t *testing.T, s string) *url.URL {
	t.Helper()
	u, err := url.Parse(s)
	if err != nil {
		t.Fatal(err)
	}
	return u
}

func TestListsLoaded(t *testing.T) {
	e := NewEngine()
	ads, trackers, malware := e.Counts()
	if ads < 50000 || trackers < 30 || malware < 10 {
		t.Fatalf("lists look too small: ads=%d trackers=%d malware=%d", ads, trackers, malware)
	}
}

func TestSuffixMatching(t *testing.T) {
	set := map[string]struct{}{"adserver.example": {}}
	for host, want := range map[string]bool{
		"adserver.example": true, "x.adserver.example": true, "a.b.adserver.example": true,
		"example": false, "notadserver.example": false, "adserver.example.org": false,
	} {
		if got := inSet(set, host); got != want {
			t.Errorf("inSet(%q) = %v, want %v", host, got, want)
		}
	}
}

func TestProtectedDomainsNeverBlocked(t *testing.T) {
	set := loadSet("google.com\nads.google.com\nevil-ads.example\n")
	if _, ok := set["google.com"]; ok {
		t.Error("google.com must be protected")
	}
	if _, ok := set["ads.google.com"]; !ok {
		t.Error("a listed subdomain of a protected domain stays blocked")
	}
}

func TestIsLocalHost(t *testing.T) {
	for _, h := range []string{"localhost", "127.0.0.1", "192.168.1.5", "10.0.0.2", "172.20.1.1", "172.31.255.255", "printer", "nas.local", "x.lan", "::1", "[::1]", "169.254.1.1", "fd00::1"} {
		if !isLocalHost(h) {
			t.Errorf("%q should be local", h)
		}
	}
	for _, h := range []string{"example.com", "8.8.8.8", "172.32.0.1", "172.15.0.1", "2606:4700::1111", "co.uk"} {
		if isLocalHost(h) {
			t.Errorf("%q should not be local", h)
		}
	}
}

func testEngine() *Engine {
	return &Engine{
		ads:      loadSet("adnet.test\nads.shop.test\n"),
		trackers: loadSet("tracker.test\n"),
		malware:  loadSet("miner.test\n"),
	}
}

func TestDecideHost(t *testing.T) {
	e, cfg := testEngine(), DefaultConfig()
	cases := []struct {
		host     string
		block    bool
		category string
	}{
		{"adnet.test", true, "ads"}, {"cdn.adnet.test", true, "ads"}, {"ADNET.TEST.", true, "ads"},
		{"tracker.test", true, "trackers"}, {"miner.test", true, "malware"},
		{"shop.test", false, ""}, {"ads.shop.test", true, "ads"}, {"example.org", false, ""},
		{"192.168.1.1", false, ""}, {"localhost", false, ""},
	}
	for _, c := range cases {
		d := e.DecideHost(c.host, &cfg, nil)
		if d.Block != c.block || d.Category != c.category {
			t.Errorf("%s: got %+v", c.host, d)
		}
	}
	if d := e.DecideHost("adnet.test", &cfg, nil); !d.Quiet {
		t.Error("ads should be answered quietly")
	}
	if d := e.DecideHost("miner.test", &cfg, nil); d.Quiet {
		t.Error("malware should show a real block page")
	}
}

func TestTogglesAllowlistAndSession(t *testing.T) {
	e := testEngine()
	cfg := DefaultConfig()
	cfg.Ads = false
	if e.DecideHost("adnet.test", &cfg, nil).Block {
		t.Error("ads toggle off should let ads through")
	}
	cfg = DefaultConfig()
	cfg.Enabled = false
	if e.DecideHost("miner.test", &cfg, nil).Block {
		t.Error("master switch off should let everything through")
	}
	cfg = DefaultConfig()
	cfg.Allow = append(cfg.Allow, "adnet.test")
	if e.DecideHost("cdn.adnet.test", &cfg, nil).Block {
		t.Error("allow-listed domain (and its subdomains) must pass")
	}
	cfg = DefaultConfig()
	sess := &SessionAllow{}
	sess.Add("miner.test")
	if e.DecideHost("x.miner.test", &cfg, sess).Block {
		t.Error("session allow must pass")
	}
	if !e.DecideHost("miner.test", &cfg, nil).Block {
		t.Error("without session allow it stays blocked")
	}
}

func TestDefaultAllowKeepsUpdatesWorking(t *testing.T) {
	e := &Engine{ads: loadSet("download.windowsupdate.com\n")}
	cfg := DefaultConfig()
	if e.DecideHost("download.windowsupdate.com", &cfg, nil).Block {
		t.Error("windowsupdate.com is allow-listed by default")
	}
}

// Same cases as the browser extension's tests.
func TestPhishingFlagged(t *testing.T) {
	for _, s := range []string{
		"https://paypal-login.com/signin", "https://paypal.com.evil.xyz/", "https://google.com@evil.example/",
		"https://bpost-tracking.top/", "http://45.12.9.8/login", "http://xn--pple-43d.com/login",
	} {
		if score, _ := assessURL(mustURL(t, s)); score < 3 {
			t.Errorf("%s should be flagged, score %d", s, score)
		}
	}
}

func TestPhishingSafe(t *testing.T) {
	for _, s := range []string{
		"https://www.google.com/search?q=x", "https://accounts.google.be/", "https://www.amazon.de/", "https://mail.google.com/",
		"https://www.paypal.com/signin", "https://itsme.be/", "https://www.kbc.be/", "https://example.co.uk/",
		"http://192.168.1.10/login", "http://localhost:3000/", "https://applepie.com/", "https://github.com/", "https://www.vrt.be/vrtnws/nl/",
	} {
		if score, r := assessURL(mustURL(t, s)); score >= 3 {
			t.Errorf("%s should be safe, score %d %v", s, score, r)
		}
	}
}

func TestDecideURLPhishing(t *testing.T) {
	e, cfg := testEngine(), DefaultConfig()
	d := e.DecideURL(mustURL(t, "http://paypal-login.com/signin"), &cfg, nil)
	if !d.Block || d.Category != "phishing" || d.Quiet {
		t.Fatalf("got %+v", d)
	}
	cfg.Phishing = false
	if e.DecideURL(mustURL(t, "http://paypal-login.com/signin"), &cfg, nil).Block {
		t.Error("phishing toggle off")
	}
}

func TestDownloads(t *testing.T) {
	cases := []struct {
		url    string
		strict bool
		block  bool
	}{
		{"http://x.com/setup.exe", false, true}, {"http://x.com/a/b/install.msi", false, true},
		{"http://x.com/invoice.pdf.exe", false, true}, {"http://x.com/photo.jpg.scr", false, true},
		{"http://x.com/report.pdf", false, false}, {"http://x.com/f.zip", false, false}, {"http://x.com/f.zip", true, true},
		{"http://x.com/", false, false}, {"http://x.com/page.html", true, false}, {"http://x.com/data.json?x=a.exe", false, false},
		{"http://x.com/readme", true, false}, {"http://x.com/file.", false, false},
	}
	for _, c := range cases {
		got := len(assessDownloadURL(mustURL(t, c.url), c.strict)) > 0
		if got != c.block {
			t.Errorf("%s strict=%v: blocked=%v, want %v", c.url, c.strict, got, c.block)
		}
	}
}
