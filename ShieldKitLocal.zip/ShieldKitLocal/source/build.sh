#!/bin/sh
# Builds ShieldKit Local for every platform into dist/. Needs Go 1.22 or newer; no other downloads.
set -e
cd "$(dirname "$0")"
go vet ./...
go test ./...
rm -rf dist
build() { # os arch folder file
  mkdir -p "dist/$3"
  CGO_ENABLED=0 GOOS=$1 GOARCH=$2 go build -trimpath -ldflags "-s -w" -o "dist/$3/$4" .
  echo "built dist/$3/$4"
}
build windows amd64 windows-amd64 shieldkid.exe
build windows arm64 windows-arm64 shieldkid.exe
build darwin  arm64 macos-apple-silicon shieldkid
build darwin  amd64 macos-intel shieldkid
build linux   amd64 linux-amd64 shieldkid
build linux   arm64 linux-arm64 shieldkid
