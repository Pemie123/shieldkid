package main

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"testing"
	"time"
)

type panelRig struct {
	t      *testing.T
	srv    *httptest.Server
	store  *Store
	proxy  *Proxy
	mgr    *Manager
	client *http.Client
}

func newPanelRig(t *testing.T) *panelRig {
	t.Helper()
	store, _ := LoadStore("")
	proxy := NewProxy(store, testEngine())
	mgr := NewManager(store, proxy)
	mgr.retryDelay = time.Millisecond
	mgr.lookup = func(ctx context.Context, c *http.Client) (IPInfo, error) {
		if store.Get().Active == "" {
			return IPInfo{IP: "81.1.1.1", Country: "BE"}, nil
		}
		return IPInfo{IP: "5.5.5.5", Country: store.Get().activeServer().Country, City: "Somewhere"}, nil
	}
	ratings := NewRatings(http.DefaultClient)
	site := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if strings.HasPrefix(r.URL.Path, "/sj/") {
			fmt.Fprint(w, ldPage("4.0", "120"))
			return
		}
		http.NotFound(w, r)
	}))
	t.Cleanup(site.Close)
	ratings.services = []ServiceDef{{"sitejabber", "Sitejabber", "/sj/", func(d string) []string { return []string{site.URL + "/sj/" + d} }, parseStructured}}
	proxy.panel = NewPanel(store, proxy, testEngine(), mgr, ratings).Handler()
	srv := httptest.NewServer(proxy)
	t.Cleanup(srv.Close)
	_ = store.Update(func(c *Config) error { c.Listen = strings.TrimPrefix(srv.URL, "http://"); return nil })
	return &panelRig{t: t, srv: srv, store: store, proxy: proxy, mgr: mgr, client: &http.Client{CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}}
}

func (r *panelRig) do(method, path string, body any, mutate func(*http.Request)) (*http.Response, string) {
	r.t.Helper()
	var rd io.Reader
	if body != nil {
		b, _ := json.Marshal(body)
		rd = bytes.NewReader(b)
	}
	req, _ := http.NewRequest(method, r.srv.URL+path, rd)
	if mutate != nil {
		mutate(req)
	}
	resp, err := r.client.Do(req)
	if err != nil {
		r.t.Fatal(err)
	}
	defer resp.Body.Close()
	b, _ := io.ReadAll(resp.Body)
	return resp, string(b)
}

func (r *panelRig) get(path string) (*http.Response, string) { return r.do("GET", path, nil, nil) }

func (r *panelRig) post(path string, body any) (*http.Response, map[string]any) {
	r.t.Helper()
	resp, text := r.do("POST", path, body, func(req *http.Request) {
		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("X-ShieldKit", "1")
	})
	var m map[string]any
	_ = json.Unmarshal([]byte(text), &m)
	return resp, m
}

func TestPanelServesUI(t *testing.T) {
	r := newPanelRig(t)
	resp, body := r.get("/")
	if resp.StatusCode != 200 || !strings.Contains(body, "ShieldKit Local") {
		t.Fatalf("index: %d", resp.StatusCode)
	}
	if resp.Header.Get("Cache-Control") != "no-store" || !strings.Contains(resp.Header.Get("Content-Security-Policy"), "frame-ancestors 'none'") {
		t.Error("security headers missing")
	}
	if resp, _ := r.get("/app.js"); resp.StatusCode != 200 {
		t.Error("app.js")
	}
	if resp, _ := r.get("/style.css"); resp.StatusCode != 200 {
		t.Error("style.css")
	}
	for _, p := range []string{"/secret", "/config.json", "/web/app.js"} {
		if resp, _ := r.get(p); resp.StatusCode != 404 {
			t.Errorf("%s should be 404, got %d", p, resp.StatusCode)
		}
	}
	// path tricks never serve anything: the router redirects to the cleaned path, which does not exist
	if resp, body := r.get("/../etc/passwd"); resp.StatusCode == 200 || strings.Contains(body, "root:") {
		t.Errorf("path traversal: %d", resp.StatusCode)
	}
}

func TestPanelRefusesOtherHostsAndOrigins(t *testing.T) {
	r := newPanelRig(t)
	withHost := func(h string) func(*http.Request) { return func(req *http.Request) { req.Host = h } }
	for _, h := range []string{"evil.example", "evil.example:8899", "127.0.0.1:1", "192.168.1.5:" + strings.Split(r.srv.URL, ":")[2]} {
		if resp, _ := r.do("GET", "/api/state", nil, withHost(h)); resp.StatusCode != 403 {
			t.Errorf("Host %q (DNS rebinding) must be refused, got %d", h, resp.StatusCode)
		}
	}
	port := strings.Split(r.srv.URL, ":")[2]
	for _, h := range []string{"127.0.0.1:" + port, "localhost:" + port} {
		if resp, _ := r.do("GET", "/api/state", nil, withHost(h)); resp.StatusCode != 200 {
			t.Errorf("Host %q should work, got %d", h, resp.StatusCode)
		}
	}
	// a web page on another site cannot change settings
	noHeader := func(req *http.Request) { req.Header.Set("Content-Type", "application/json") }
	if resp, _ := r.do("POST", "/api/settings", map[string]any{"enabled": false}, noHeader); resp.StatusCode != 403 {
		t.Errorf("missing X-ShieldKit header: %d", resp.StatusCode)
	}
	evil := func(req *http.Request) {
		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("X-ShieldKit", "1")
		req.Header.Set("Origin", "https://evil.example")
	}
	if resp, _ := r.do("POST", "/api/settings", map[string]any{"enabled": false}, evil); resp.StatusCode != 403 {
		t.Errorf("foreign Origin: %d", resp.StatusCode)
	}
	form := func(req *http.Request) {
		req.Header.Set("Content-Type", "text/plain")
		req.Header.Set("X-ShieldKit", "1")
	}
	if resp, _ := r.do("POST", "/api/settings", map[string]any{"enabled": false}, form); resp.StatusCode != 415 {
		t.Errorf("wrong content type: %d", resp.StatusCode)
	}
	if !r.store.Get().Enabled {
		t.Error("a refused request changed a setting")
	}
	own := func(req *http.Request) {
		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("X-ShieldKit", "1")
		req.Header.Set("Origin", r.srv.URL)
	}
	if resp, _ := r.do("POST", "/api/settings", map[string]any{"enabled": false}, own); resp.StatusCode != 200 || r.store.Get().Enabled {
		t.Errorf("the panel's own origin must work: %d", resp.StatusCode)
	}
}

func TestStateNeverRevealsSecrets(t *testing.T) {
	r := newPanelRig(t)
	_ = r.store.Update(func(c *Config) error {
		c.GoogleKey = "AIzaSECRETKEY1234567890"
		c.Servers = []Server{{ID: "x", Country: "NL", Name: "N", Scheme: "https", Host: "h.example", Port: 443, Username: "bob", Password: "hunter2"}}
		return nil
	})
	_, body := r.get("/api/state")
	for _, secret := range []string{"hunter2", "AIzaSECRETKEY", "bob"} {
		if strings.Contains(body, secret) {
			t.Errorf("state leaks %q", secret)
		}
	}
	var st map[string]any
	json.Unmarshal([]byte(body), &st)
	if st["hasGoogleKey"] != true || len(st["countries"].([]any)) != 249 {
		t.Errorf("state: %v", st)
	}
	if s := st["servers"].([]any)[0].(map[string]any); s["hasLogin"] != true {
		t.Error("hasLogin missing")
	}
}

func TestSettingsValidation(t *testing.T) {
	r := newPanelRig(t)
	if resp, _ := r.post("/api/settings", map[string]any{"ads": false, "youtube": "strict", "bridgePort": 2081, "googleKey": "AIzaKEY"}); resp.StatusCode != 200 {
		t.Fatalf("valid: %d", resp.StatusCode)
	}
	c := r.store.Get()
	if c.Ads || c.YouTube != "strict" || c.BridgePort != 2081 || c.GoogleKey != "AIzaKEY" {
		t.Errorf("not applied: %+v", c)
	}
	for _, bad := range []map[string]any{
		{"ads": "yes"}, {"youtube": "extreme"}, {"googleKey": "has space"}, {"bridgeApi": "http://203.0.113.5:9090"},
		{"bridgePort": 0}, {"bridgePort": 70000}, {"bridgePort": 1.5}, {"nonsense": true}, {"listen": "0.0.0.0:80"}, {"servers": []any{}},
	} {
		if resp, m := r.post("/api/settings", bad); resp.StatusCode != 400 || m["error"] == nil {
			t.Errorf("%v should be rejected, got %d", bad, resp.StatusCode)
		}
	}
	if r.store.Get().Listen == "0.0.0.0:80" {
		t.Error("the listen address must not be changeable from the panel")
	}
	if resp, _ := r.post("/api/settings", map[string]any{"bridgeApi": "http://localhost:9091/x"}); resp.StatusCode != 200 || r.store.Get().BridgeAPI != "http://localhost:9091" {
		t.Errorf("valid local api: %s", r.store.Get().BridgeAPI)
	}
}

func TestAllowList(t *testing.T) {
	r := newPanelRig(t)
	r.post("/api/allow", map[string]any{"action": "add", "host": "https://Ads.Example.com/page"})
	if !hostAllowed("cdn.ads.example.com", r.store.Get().Allow) {
		t.Error("add failed")
	}
	r.post("/api/allow", map[string]any{"action": "remove", "host": "ads.example.com"})
	if hostAllowed("ads.example.com", r.store.Get().Allow) {
		t.Error("remove failed")
	}
	for _, bad := range []string{"", "nodot", "bad host.com", "a;b.com"} {
		if resp, _ := r.post("/api/allow", map[string]any{"action": "add", "host": bad}); resp.StatusCode != 400 {
			t.Errorf("%q should be rejected", bad)
		}
	}
}

func TestServersConnectAndRemove(t *testing.T) {
	r := newPanelRig(t)
	resp, m := r.post("/api/servers", map[string]any{"action": "add", "server": map[string]any{"country": "Belgium", "host": "be1.example.com", "port": "443", "scheme": "https", "username": "u", "password": "p"}})
	if resp.StatusCode != 200 || len(r.store.Get().Servers) != 1 {
		t.Fatalf("add: %d %v", resp.StatusCode, m)
	}
	if resp, _ := r.post("/api/servers", map[string]any{"action": "add", "server": map[string]any{"country": "Narnia", "host": "x.example.com", "port": 1}}); resp.StatusCode != 400 {
		t.Error("bad server accepted")
	}
	_, m = r.post("/api/servers", map[string]any{"action": "import", "text": "NL,nl1.example.com,443,https\nXX,bad.example.com,1"})
	if m["added"] != float64(1) || len(m["errors"].([]any)) != 1 {
		t.Errorf("import: %v", m)
	}
	id := "BE-https-be1.example.com-443"
	resp, m = r.post("/api/connect", map[string]any{"id": id})
	if resp.StatusCode != 200 || m["verdict"].(map[string]any)["level"] != "ok" || r.store.Get().Active != id {
		t.Fatalf("connect: %d %v", resp.StatusCode, m)
	}
	if resp, m := r.post("/api/retest", map[string]any{}); resp.StatusCode != 200 || m["verdict"] == nil {
		t.Errorf("retest: %v", m)
	}
	r.post("/api/servers", map[string]any{"action": "remove", "id": id})
	if r.store.Get().Active != "" || len(r.store.Get().Servers) != 1 {
		t.Errorf("removing the active server must disconnect: %+v", r.store.Get())
	}
	if resp, m := r.post("/api/connect", map[string]any{"id": "nope"}); resp.StatusCode != 400 || m["error"] == nil {
		t.Error("unknown server")
	}
	if resp, _ := r.post("/api/retest", map[string]any{}); resp.StatusCode != 400 {
		t.Error("retest while disconnected")
	}
	r.post("/api/disconnect", map[string]any{})
}

func TestBridgeLoadAndClear(t *testing.T) {
	r := newPanelRig(t)
	fc := newFakeController(t)
	resp, m := r.post("/api/bridge/load", map[string]any{"api": fc.URL, "port": 2081})
	if resp.StatusCode != 200 || m["countries"] != float64(2) {
		t.Fatalf("load: %d %v", resp.StatusCode, m)
	}
	c := r.store.Get()
	if len(c.Servers) != 2 || c.BridgePort != 2081 || c.BridgeAPI != fc.URL || c.Servers[0].Port != 2081 || !c.Servers[0].Bridge {
		t.Errorf("%+v", c)
	}
	resp, m = r.post("/api/connect", map[string]any{"id": "BRIDGE-NL"})
	if resp.StatusCode != 200 || len(fc.selected) != 1 || fc.selected[0] != "country-NL" {
		t.Fatalf("connect: %d %v selected=%v", resp.StatusCode, m, fc.selected)
	}
	r.post("/api/bridge/clear", map[string]any{})
	if len(r.store.Get().Servers) != 0 || r.store.Get().Active != "" {
		t.Error("clear must remove free servers and disconnect")
	}
	if resp, _ := r.post("/api/bridge/load", map[string]any{"api": "http://203.0.113.9:9090"}); resp.StatusCode != 400 {
		t.Error("remote controller accepted")
	}
	if resp, m := r.post("/api/bridge/load", map[string]any{"api": "http://127.0.0.1:1"}); resp.StatusCode != 400 || !strings.Contains(m["error"].(string), "cannot reach") {
		t.Errorf("unreachable: %v", m)
	}
}

func TestCheckEndpoint(t *testing.T) {
	r := newPanelRig(t)
	resp, m := r.post("/api/check", map[string]any{"domain": "https://www.shop.bol.com/some/page?x=1"})
	if resp.StatusCode != 200 || m["domain"] != "bol.com" || m["combined"] == nil {
		t.Fatalf("%d %v", resp.StatusCode, m)
	}
	for _, bad := range []string{"", "nodot", "bad host.com"} {
		if resp, _ := r.post("/api/check", map[string]any{"domain": bad}); resp.StatusCode != 400 {
			t.Errorf("%q", bad)
		}
	}
}

func TestContinueAnywayLink(t *testing.T) {
	r := newPanelRig(t)
	good := "/__shieldkit/allow?" + url.Values{"host": {"paypal-login.com"}, "token": {r.proxy.token}, "next": {"http://paypal-login.com/signin"}}.Encode()
	if resp, _ := r.get("/__shieldkit/allow?" + url.Values{"host": {"paypal-login.com"}, "token": {"wrong"}, "next": {"http://paypal-login.com/"}}.Encode()); resp.StatusCode != 403 {
		t.Errorf("wrong token: %d", resp.StatusCode)
	}
	if r.proxy.sess.Has("paypal-login.com") {
		t.Fatal("a wrong token allowed the host")
	}
	bad := "/__shieldkit/allow?" + url.Values{"host": {"paypal-login.com"}, "token": {r.proxy.token}, "next": {"http://other.example/"}}.Encode()
	if resp, _ := r.get(bad); resp.StatusCode != 400 {
		t.Errorf("redirecting to a different host: %d", resp.StatusCode)
	}
	jsAddr := "/__shieldkit/allow?" + url.Values{"host": {"x.com"}, "token": {r.proxy.token}, "next": {"javascript:alert(1)"}}.Encode()
	if resp, _ := r.get(jsAddr); resp.StatusCode != 400 {
		t.Errorf("javascript: target: %d", resp.StatusCode)
	}
	resp, _ := r.get(good)
	if resp.StatusCode != 303 || resp.Header.Get("Location") != "http://paypal-login.com/signin" || !r.proxy.sess.Has("paypal-login.com") {
		t.Fatalf("good link: %d %q", resp.StatusCode, resp.Header.Get("Location"))
	}
}

func TestPACFiles(t *testing.T) {
	r := newPanelRig(t)
	resp, body := r.get("/proxy.pac")
	if resp.Header.Get("Content-Type") != "application/x-ns-proxy-autoconfig" || !strings.Contains(body, "PROXY "+r.store.Get().Listen+"; DIRECT") {
		t.Errorf("proxy.pac: %q", body)
	}
	_, strict := r.get("/proxy-strict.pac")
	if strings.Contains(strict, "; DIRECT") || !strings.Contains(strict, `return "PROXY `+r.store.Get().Listen+`";`) {
		t.Errorf("strict pac must not fall back to DIRECT: %q", strict)
	}
	if !strings.Contains(body, `isInNet(host, "192.168.0.0"`) || !strings.Contains(body, "isPlainHostName") {
		t.Error("local addresses must bypass the proxy")
	}
}

func TestProxyRequestsAreNotConfusedWithPanel(t *testing.T) {
	r := newPanelRig(t)
	// An absolute-form request is proxied (here: to a blocked ad host => 204), never answered by the panel.
	pu, _ := url.Parse(r.srv.URL)
	c := &http.Client{Transport: &http.Transport{Proxy: http.ProxyURL(pu)}}
	resp, err := c.Get("http://adnet.test/state")
	if err != nil || resp.StatusCode != 204 {
		t.Fatalf("%v %v", err, resp)
	}
}
