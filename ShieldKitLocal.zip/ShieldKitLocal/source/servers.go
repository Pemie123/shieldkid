package main

import (
	"encoding/json"
	"fmt"
	"regexp"
	"strconv"
	"strings"
)

var hostRe = regexp.MustCompile(`(?i)^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*$`)

type rawServer struct {
	Country  string `json:"country"`
	Name     string `json:"name"`
	Scheme   string `json:"scheme"`
	Type     string `json:"type"`
	Host     string `json:"host"`
	Port     any    `json:"port"`
	Username string `json:"username"`
	Password string `json:"password"`
}

func countryCode(in string) string {
	s := strings.TrimSpace(in)
	if len(s) == 2 {
		u := strings.ToUpper(s)
		if u == "UK" {
			u = "GB"
		}
		if _, ok := countryNames[u]; ok {
			return u
		}
		return ""
	}
	for code, name := range countryNames {
		if strings.EqualFold(name, s) {
			return code
		}
	}
	return ""
}

func validateServer(r rawServer) (Server, error) {
	cc := countryCode(r.Country)
	if cc == "" {
		return Server{}, fmt.Errorf("unknown country %q", r.Country)
	}
	scheme := strings.ToLower(strings.TrimSpace(r.Scheme))
	if scheme == "" {
		scheme = strings.ToLower(strings.TrimSpace(r.Type))
	}
	if scheme == "" {
		scheme = "https"
	}
	if scheme != "https" && scheme != "http" && scheme != "socks5" {
		return Server{}, fmt.Errorf("unsupported type %q (use https, http or socks5)", scheme)
	}
	host := strings.ToLower(strings.TrimSpace(r.Host))
	if !hostRe.MatchString(host) {
		return Server{}, fmt.Errorf("invalid host %q", r.Host)
	}
	var port int
	switch v := r.Port.(type) {
	case float64:
		port = int(v)
	case string:
		port, _ = strconv.Atoi(strings.TrimSpace(v))
	case int:
		port = v
	}
	if port < 1 || port > 65535 {
		return Server{}, fmt.Errorf("invalid port %v", r.Port)
	}
	name := strings.TrimSpace(r.Name)
	if len(name) > 60 {
		name = name[:60]
	}
	if name == "" {
		name = host
	}
	return Server{
		ID: fmt.Sprintf("%s-%s-%s-%d", cc, scheme, host, port), Country: cc, Name: name, Scheme: scheme,
		Host: host, Port: port, Username: r.Username, Password: r.Password,
	}, nil
}

// parseServers reads a JSON array (or {"servers":[...]}) or CSV lines: country,host,port,type,username,password,name
func parseServers(text string) ([]Server, []string) {
	var servers []Server
	var errs []string
	seen := map[string]bool{}
	add := func(r rawServer, where string) {
		s, err := validateServer(r)
		switch {
		case err != nil:
			errs = append(errs, where+": "+err.Error())
		case !seen[s.ID]:
			seen[s.ID] = true
			servers = append(servers, s)
		}
	}
	body := strings.TrimSpace(text)
	if body == "" {
		return nil, []string{"nothing to import"}
	}
	if body[0] == '[' || body[0] == '{' {
		var list []rawServer
		if body[0] == '[' {
			if err := json.Unmarshal([]byte(body), &list); err != nil {
				return nil, []string{"not valid JSON: " + err.Error()}
			}
		} else {
			var wrap struct {
				Servers []rawServer `json:"servers"`
			}
			if err := json.Unmarshal([]byte(body), &wrap); err != nil {
				return nil, []string{"not valid JSON: " + err.Error()}
			}
			list = wrap.Servers
		}
		for i, r := range list {
			add(r, fmt.Sprintf("entry %d", i+1))
		}
		return servers, errs
	}
	for i, line := range strings.Split(body, "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		parts := strings.Split(line, ",")
		for len(parts) < 6 {
			parts = append(parts, "")
		}
		if i == 0 && strings.EqualFold(strings.TrimSpace(parts[0]), "country") {
			continue
		}
		add(rawServer{
			Country: strings.TrimSpace(parts[0]), Host: strings.TrimSpace(parts[1]), Port: strings.TrimSpace(parts[2]),
			Scheme: strings.TrimSpace(parts[3]), Username: strings.TrimSpace(parts[4]), Password: strings.TrimSpace(parts[5]),
			Name: strings.TrimSpace(strings.Join(parts[6:], ",")),
		}, fmt.Sprintf("line %d", i+1))
	}
	return servers, errs
}
