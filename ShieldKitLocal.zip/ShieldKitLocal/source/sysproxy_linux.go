//go:build linux

package main

import "os/exec"

func newSysProxy() sysProxy {
	if _, err := exec.LookPath("gsettings"); err != nil {
		return nil // not a GNOME-style desktop: nothing automatic to do
	}
	return gnomeProxy{run: execRun}
}
