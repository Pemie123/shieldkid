package main

import (
	"errors"
	"fmt"
	"os/exec"
	"regexp"
	"strings"
)

// Command-building and output-parsing for each operating system. They are kept free of OS-specific code so they can
// be tested everywhere with a fake command runner.

type runner func(name string, args ...string) (string, error)

func execRun(name string, args ...string) (string, error) {
	out, err := exec.Command(name, args...).CombinedOutput()
	return string(out), err
}

func tidy(out string) string {
	out = strings.TrimSpace(out)
	if len(out) > 200 {
		out = out[:200]
	}
	return out
}

// ---------------------------------------------------------------- Windows: the "Use setup script" address

const winKey = `HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings`

var winValueRe = regexp.MustCompile(`(?m)^\s*AutoConfigURL\s+REG_SZ\s*(.*?)\s*$`)

type windowsProxy struct {
	run    runner
	notify func() // tells running programs the setting changed
}

func (w windowsProxy) Name() string { return "windows-internet-settings" }

func (w windowsProxy) Capture() (map[string]string, error) {
	out, err := w.run("reg", "query", winKey, "/v", "AutoConfigURL")
	if err != nil {
		if errors.Is(err, exec.ErrNotFound) {
			return nil, err
		}
		return map[string]string{"had": "0"}, nil // the value does not exist yet
	}
	if m := winValueRe.FindStringSubmatch(out); m != nil && m[1] != "" {
		return map[string]string{"had": "1", "url": m[1]}, nil
	}
	return map[string]string{"had": "0"}, nil
}

func (w windowsProxy) set(url string) error {
	if out, err := w.run("reg", "add", winKey, "/v", "AutoConfigURL", "/t", "REG_SZ", "/d", url, "/f"); err != nil {
		return fmt.Errorf("reg add failed: %v %s", err, tidy(out))
	}
	return nil
}

func (w windowsProxy) Apply(pacURL string) error {
	if err := w.set(pacURL); err != nil {
		return err
	}
	w.notify()
	return nil
}

func (w windowsProxy) Verify(pacURL string) error {
	got, err := w.Capture()
	if err != nil {
		return err
	}
	if got["had"] != "1" || got["url"] != pacURL {
		return fmt.Errorf("Windows reports %q instead", got["url"])
	}
	return nil
}

func (w windowsProxy) Restore(saved map[string]string) error {
	defer w.notify()
	if saved["had"] == "1" {
		return w.set(saved["url"])
	}
	if out, err := w.run("reg", "delete", winKey, "/v", "AutoConfigURL", "/f"); err != nil && !strings.Contains(strings.ToLower(out), "unable to find") {
		return fmt.Errorf("reg delete failed: %v %s", err, tidy(out))
	}
	return nil
}

// ---------------------------------------------------------------- macOS: Automatic Proxy Configuration, per network service

type macProxy struct{ run runner }

func (m macProxy) Name() string { return "macos-network-services" }

var (
	macURLRe     = regexp.MustCompile(`(?m)^URL:\s*(.*?)\s*$`)
	macEnabledRe = regexp.MustCompile(`(?m)^Enabled:\s*(\w+)`)
)

func (m macProxy) services() ([]string, error) {
	out, err := m.run("networksetup", "-listallnetworkservices")
	if err != nil {
		return nil, fmt.Errorf("networksetup failed: %v %s", err, tidy(out))
	}
	var list []string
	for _, line := range strings.Split(out, "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "*") || strings.HasPrefix(line, "An asterisk") { // a leading * marks a disabled service
			continue
		}
		list = append(list, line)
	}
	if len(list) == 0 {
		return nil, errors.New("no active network service found")
	}
	return list, nil
}

func (m macProxy) Capture() (map[string]string, error) {
	svcs, err := m.services()
	if err != nil {
		return nil, err
	}
	saved := map[string]string{}
	for _, s := range svcs {
		out, err := m.run("networksetup", "-getautoproxyurl", s)
		if err != nil {
			return nil, fmt.Errorf("networksetup failed: %v %s", err, tidy(out))
		}
		url, enabled := "", "No"
		if u := macURLRe.FindStringSubmatch(out); u != nil && u[1] != "(null)" {
			url = u[1]
		}
		if e := macEnabledRe.FindStringSubmatch(out); e != nil {
			enabled = e[1]
		}
		saved[s] = enabled + "\t" + url
	}
	return saved, nil
}

func (m macProxy) Apply(pacURL string) error {
	svcs, err := m.services()
	if err != nil {
		return err
	}
	done := 0
	var last error
	for _, s := range svcs {
		if out, err := m.run("networksetup", "-setautoproxyurl", s, pacURL); err != nil {
			last = fmt.Errorf("networksetup failed for %q: %v %s", s, err, tidy(out))
			continue
		}
		if out, err := m.run("networksetup", "-setautoproxystate", s, "on"); err != nil {
			last = fmt.Errorf("networksetup failed for %q: %v %s", s, err, tidy(out))
			continue
		}
		done++
	}
	if done == 0 {
		return last
	}
	return nil
}

func (m macProxy) Verify(pacURL string) error {
	got, err := m.Capture()
	if err != nil {
		return err
	}
	for _, v := range got {
		if enabled, url, _ := strings.Cut(v, "\t"); enabled == "Yes" && url == pacURL {
			return nil // at least one network service now uses it
		}
	}
	return errors.New("no network service reports the new setting")
}

func (m macProxy) Restore(saved map[string]string) error {
	var last error
	for s, v := range saved {
		enabled, url, _ := strings.Cut(v, "\t")
		if url != "" {
			if out, err := m.run("networksetup", "-setautoproxyurl", s, url); err != nil {
				last = fmt.Errorf("networksetup failed for %q: %v %s", s, err, tidy(out))
			}
		}
		state := "off"
		if enabled == "Yes" && url != "" {
			state = "on"
		}
		if out, err := m.run("networksetup", "-setautoproxystate", s, state); err != nil {
			last = fmt.Errorf("networksetup failed for %q: %v %s", s, err, tidy(out))
		}
	}
	return last
}

// ---------------------------------------------------------------- Linux with GNOME (Ubuntu, Fedora and most desktops)

type gnomeProxy struct{ run runner }

func (g gnomeProxy) Name() string { return "gnome-gsettings" }

func unquote(s string) string { return strings.Trim(strings.TrimSpace(s), "'\"") }

func (g gnomeProxy) get(key string) (string, error) {
	out, err := g.run("gsettings", "get", "org.gnome.system.proxy", key)
	if err != nil {
		return "", fmt.Errorf("gsettings failed: %v %s", err, tidy(out))
	}
	return unquote(out), nil
}

func (g gnomeProxy) set(key, value string) error {
	if out, err := g.run("gsettings", "set", "org.gnome.system.proxy", key, "'"+value+"'"); err != nil {
		return fmt.Errorf("gsettings failed: %v %s", err, tidy(out))
	}
	return nil
}

func (g gnomeProxy) Capture() (map[string]string, error) {
	mode, err := g.get("mode")
	if err != nil {
		return nil, err
	}
	url, err := g.get("autoconfig-url")
	if err != nil {
		return nil, err
	}
	return map[string]string{"mode": mode, "url": url}, nil
}

func (g gnomeProxy) Apply(pacURL string) error {
	if err := g.set("autoconfig-url", pacURL); err != nil {
		return err
	}
	return g.set("mode", "auto")
}

func (g gnomeProxy) Verify(pacURL string) error {
	got, err := g.Capture()
	if err != nil {
		return err
	}
	if got["mode"] != "auto" || got["url"] != pacURL {
		return fmt.Errorf("the desktop reports mode %q instead of \"auto\"", got["mode"])
	}
	return nil
}

func (g gnomeProxy) Restore(saved map[string]string) error {
	if err := g.set("autoconfig-url", saved["url"]); err != nil {
		return err
	}
	mode := saved["mode"]
	if mode == "" {
		mode = "none"
	}
	return g.set("mode", mode)
}
