package main

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"net/http"
	"net/url"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

// ---------------------------------------------------------------- which sites, under which name

var ratingCCSLD = map[string]bool{"co": true, "com": true, "org": true, "net": true, "gov": true, "ac": true, "edu": true}
var ratingSkipLabel = regexp.MustCompile(`^(google|bing|duckduckgo|yahoo|ecosia|startpage|brave|trustpilot)$`)

func registrableDomain(host string) string {
	labels := strings.Split(strings.TrimSuffix(strings.ToLower(host), "."), ".")
	n := len(labels)
	if n <= 2 {
		return strings.Join(labels, ".")
	}
	if len(labels[n-1]) == 2 && ratingCCSLD[labels[n-2]] {
		return strings.Join(labels[n-3:], ".")
	}
	return strings.Join(labels[n-2:], ".")
}

// shouldLookup: public, named websites only.
func shouldLookup(host string) bool {
	h := normalizeHost(host)
	if isLocalHost(h) || !strings.Contains(h, ".") {
		return false
	}
	switch h[strings.LastIndexByte(h, '.')+1:] {
	case "test", "invalid", "example", "arpa":
		return false
	}
	return !ratingSkipLabel.MatchString(strings.Split(registrableDomain(h), ".")[0])
}

// ---------------------------------------------------------------- reading rating pages

type Parsed struct {
	Score   float64
	Reviews *int
	Name    string
}

func numOf(v any) (float64, bool) {
	switch x := v.(type) {
	case float64:
		return x, true
	case string:
		s := strings.TrimSpace(x)
		if s == "" {
			return 0, false
		}
		f, err := strconv.ParseFloat(strings.Replace(s, ",", ".", 1), 64)
		return f, err == nil
	}
	return 0, false
}

func intPtr(f float64, ok bool) *int {
	if !ok || f < 0 {
		return nil
	}
	n := int(math.Round(f))
	return &n
}

func makeParsed(score float64, ok bool, reviews *int, name string) *Parsed {
	if !ok || score < 0 || score > 5 {
		return nil
	}
	return &Parsed{Score: math.Round(score*10) / 10, Reviews: reviews, Name: name}
}

func normScore(value, best any) (float64, bool) {
	v, ok := numOf(value)
	if !ok {
		return 0, false
	}
	b, ok := numOf(best)
	if !ok || b == 0 {
		b = 5
	}
	if b == 5 {
		return v, true
	}
	return v / b * 5, true
}

func findAggregate(node any) map[string]any {
	switch n := node.(type) {
	case []any:
		for _, x := range n {
			if f := findAggregate(x); f != nil {
				return f
			}
		}
	case map[string]any:
		if n["@type"] == "AggregateRating" && n["ratingValue"] != nil {
			return n
		}
		if agg, ok := n["aggregateRating"]; ok {
			if f := findAggregate(agg); f != nil {
				out := map[string]any{}
				for k, v := range f {
					out[k] = v
				}
				out["name"] = n["name"]
				return out
			}
		}
		keys := make([]string, 0, len(n))
		for k := range n {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		for _, k := range keys {
			if f := findAggregate(n[k]); f != nil {
				return f
			}
		}
	}
	return nil
}

var (
	ldRe       = regexp.MustCompile(`(?is)<script[^>]*type="application/ld\+json"[^>]*>(.*?)</script>`)
	nextRe     = regexp.MustCompile(`(?is)<script[^>]*id="__NEXT_DATA__"[^>]*>(.*?)</script>`)
	scriptRe   = regexp.MustCompile(`(?is)<script.*?</script>|<style.*?</style>`)
	tagRe      = regexp.MustCompile(`<[^>]+>`)
	spaceRe    = regexp.MustCompile(`\s+`)
	tpScoreRe  = regexp.MustCompile(`"trustScore"\s*:\s*([0-9]+(?:\.[0-9]+)?)`)
	tpCountRe  = regexp.MustCompile(`"numberOfReviews"\s*:\s*(?:\{[^{}]*?"total"\s*:\s*)?([0-9]+)`)
	tpNameRe   = regexp.MustCompile(`"displayName"\s*:\s*"([^"]{1,80})"`)
	tpTextRe   = regexp.MustCompile(`(?i)TrustScore\s+([0-9]+(?:[.,][0-9]+)?)\s+out of\s+5`)
	tpExactRe  = regexp.MustCompile(`(?i)All reviews\s*\(\s*([0-9][0-9.,]*)\s*\)`)
	tpShortRe  = regexp.MustCompile(`(?i)([0-9][0-9.,]*)\s*(k)?\s+(?:total\s+)?reviews`)
	rioTextRe  = regexp.MustCompile(`(?i)is rated\s+([0-5](?:[.,][0-9]+)?)\s+based on\s+([0-9][0-9.,]*)\s+reviews`)
	nonDigitRe = regexp.MustCompile(`[.,]`)
)

func plainText(html string) string {
	t := scriptRe.ReplaceAllString(html, " ")
	t = tagRe.ReplaceAllString(t, " ")
	t = strings.ReplaceAll(t, "&nbsp;", " ")
	return strings.TrimSpace(spaceRe.ReplaceAllString(t, " "))
}

func microdata(html, name string) string {
	res := []*regexp.Regexp{
		regexp.MustCompile(`(?i)itemprop=["']` + name + `["'][^>]*?content=["']([^"']+)["']`),
		regexp.MustCompile(`(?i)content=["']([^"']+)["'][^>]*?itemprop=["']` + name + `["']`),
		regexp.MustCompile(`(?i)itemprop=["']` + name + `["'][^>]*>\s*([0-9][0-9.,]*)\s*<`),
	}
	for _, re := range res {
		if m := re.FindStringSubmatch(html); m != nil {
			return m[1]
		}
	}
	return ""
}

// parseStructured reads JSON-LD AggregateRating, then schema.org microdata. Used by every service.
func parseStructured(html string) *Parsed {
	for _, m := range ldRe.FindAllStringSubmatch(html, -1) {
		var doc any
		if json.Unmarshal([]byte(m[1]), &doc) != nil {
			continue
		}
		if f := findAggregate(doc); f != nil {
			score, ok := normScore(f["ratingValue"], f["bestRating"])
			count, cok := numOf(f["reviewCount"])
			if !cok {
				count, cok = numOf(f["ratingCount"])
			}
			name, _ := f["name"].(string)
			if p := makeParsed(score, ok, intPtr(count, cok), name); p != nil {
				return p
			}
		}
	}
	if rv := microdata(html, "ratingValue"); rv != "" {
		score, ok := normScore(rv, microdata(html, "bestRating"))
		count, cok := numOf(microdata(html, "reviewCount"))
		if !cok {
			count, cok = numOf(microdata(html, "ratingCount"))
		}
		return makeParsed(score, ok, intPtr(count, cok), "")
	}
	return nil
}

func parseTrustpilot(html string) *Parsed {
	if m := nextRe.FindStringSubmatch(html); m != nil {
		var doc map[string]any
		if json.Unmarshal([]byte(m[1]), &doc) == nil {
			props, _ := doc["props"].(map[string]any)
			page, _ := props["pageProps"].(map[string]any)
			if bu, ok := page["businessUnit"].(map[string]any); ok {
				score, sok := numOf(bu["trustScore"])
				var count float64
				var cok bool
				if nr, isObj := bu["numberOfReviews"].(map[string]any); isObj {
					count, cok = numOf(nr["total"])
				} else if count, cok = numOf(bu["numberOfReviews"]); !cok {
					count, cok = numOf(bu["reviewsCount"])
				}
				name, _ := bu["displayName"].(string)
				if p := makeParsed(score, sok, intPtr(count, cok), name); p != nil {
					return p
				}
			}
		}
	}
	if p := parseStructured(html); p != nil {
		return p
	}
	if m := tpScoreRe.FindStringSubmatch(html); m != nil { // same numbers, if the page data was reshaped
		score, _ := numOf(m[1])
		var reviews *int
		if c := tpCountRe.FindStringSubmatch(html); c != nil {
			f, ok := numOf(c[1])
			reviews = intPtr(f, ok)
		}
		name := ""
		if n := tpNameRe.FindStringSubmatch(html); n != nil {
			name = n[1]
		}
		if p := makeParsed(score, true, reviews, name); p != nil {
			return p
		}
	}
	text := plainText(html)
	if m := tpTextRe.FindStringSubmatch(text); m != nil {
		score, ok := numOf(m[1])
		var reviews *int
		if e := tpExactRe.FindStringSubmatch(text); e != nil {
			n, _ := strconv.Atoi(nonDigitRe.ReplaceAllString(e[1], ""))
			reviews = &n
		} else if s := tpShortRe.FindStringSubmatch(text); s != nil {
			if s[2] != "" {
				f, _ := numOf(s[1])
				n := int(math.Round(f * 1000))
				reviews = &n
			} else {
				n, _ := strconv.Atoi(nonDigitRe.ReplaceAllString(s[1], ""))
				reviews = &n
			}
		}
		return makeParsed(score, ok, reviews, "")
	}
	return nil
}

func parseReviewsIO(html string) *Parsed {
	if p := parseStructured(html); p != nil {
		return p
	}
	if m := rioTextRe.FindStringSubmatch(plainText(html)); m != nil {
		score, ok := numOf(m[1])
		n, _ := strconv.Atoi(nonDigitRe.ReplaceAllString(m[2], ""))
		return makeParsed(score, ok, &n, "")
	}
	return nil
}

// ---------------------------------------------------------------- services and lookups

type ServiceDef struct {
	ID, Name, PathPrefix string
	URLs                 func(domain string) []string
	Parse                func(html string) *Parsed
}

var defaultServices = []ServiceDef{
	{"trustpilot", "Trustpilot", "/review/", func(d string) []string {
		return []string{"https://www.trustpilot.com/review/" + d, "https://www.trustpilot.com/review/www." + d}
	}, parseTrustpilot},
	{"sitejabber", "Sitejabber", "/reviews/", func(d string) []string {
		return []string{"https://www.sitejabber.com/reviews/" + d}
	}, parseStructured}, // only trusted with structured data: a wrong number is never guessed from text
	{"reviewsio", "Reviews.io", "/company-reviews/store/", func(d string) []string {
		return []string{"https://www.reviews.io/company-reviews/store/" + strings.ReplaceAll(d, ".", "-"), "https://www.reviews.io/company-reviews/store/" + d}
	}, parseReviewsIO},
}

type RatingResult struct {
	Status  string  `json:"status"` // ok, none, error, nokey, badkey
	Score   float64 `json:"score,omitempty"`
	Reviews *int    `json:"reviews,omitempty"`
	Name    string  `json:"name,omitempty"`
	URL     string  `json:"url,omitempty"`
	Reason  string  `json:"reason,omitempty"`
	Note    string  `json:"note,omitempty"`
	Snippet string  `json:"snippet,omitempty"`
}

var challengeRe = regexp.MustCompile(`(?i)just a moment|cf-chl|challenge-platform|captcha|are you a robot|access denied`)

func fail(reason, note string) RatingResult {
	return RatingResult{Status: "error", Reason: reason, Note: note}
}

// lookupService looks a domain up on one service. Errors carry a short human reason so "unavailable" is never a mystery.
func lookupService(ctx context.Context, client *http.Client, svc ServiceDef, domain string) RatingResult {
	var failure *RatingResult
	for _, u := range svc.URLs(domain) {
		req, _ := http.NewRequestWithContext(ctx, http.MethodGet, u, nil)
		req.Header.Set("User-Agent", "ShieldKitLocal/1.0 (site rating lookup)")
		req.Header.Set("Accept", "text/html")
		resp, err := client.Do(req)
		if err != nil {
			f := fail("offline", "no connection")
			failure = &f
			break
		}
		body, _ := io.ReadAll(io.LimitReader(resp.Body, 4<<20))
		resp.Body.Close()
		switch {
		case resp.StatusCode == 404 || resp.StatusCode == 410:
			continue
		case resp.StatusCode/100 != 2:
			f := fail("http", fmt.Sprintf("HTTP %d", resp.StatusCode))
			if resp.StatusCode == 401 || resp.StatusCode == 403 || resp.StatusCode == 429 || resp.StatusCode == 503 {
				f = fail("blocked", fmt.Sprintf("blocked, HTTP %d", resp.StatusCode))
			}
			failure = &f
		}
		if failure != nil {
			break
		}
		if final := resp.Request.URL; final.String() != u && !strings.Contains(final.Path, svc.PathPrefix) {
			continue // bounced to a search or home page: no such company
		}
		if p := svc.Parse(string(body)); p != nil {
			return RatingResult{Status: "ok", Score: p.Score, Reviews: p.Reviews, Name: p.Name, URL: u}
		}
		text := plainText(string(body))
		if len(text) > 160 {
			text = text[:160]
		}
		f := fail("unreadable", "page layout not recognised")
		if challengeRe.MatchString(text) {
			f = fail("challenge", "bot check page")
		}
		f.Snippet = text
		failure = &f
		break
	}
	if failure != nil {
		return *failure
	}
	return RatingResult{Status: "none"}
}

// ---------------------------------------------------------------- Google (the user's own Places API key)

var placesURL = "https://places.googleapis.com/v1/places:searchText"

func lookupGoogle(ctx context.Context, client *http.Client, domain, key string) RatingResult {
	if key == "" {
		return RatingResult{Status: "nokey"}
	}
	body, _ := json.Marshal(map[string]any{"textQuery": domain, "pageSize": 5})
	req, _ := http.NewRequestWithContext(ctx, http.MethodPost, placesURL, bytes.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("X-Goog-Api-Key", key)
	req.Header.Set("X-Goog-FieldMask", "places.displayName,places.rating,places.userRatingCount,places.websiteUri,places.googleMapsUri")
	resp, err := client.Do(req)
	if err != nil {
		return fail("offline", "no connection")
	}
	defer resp.Body.Close()
	switch {
	case resp.StatusCode == 400 || resp.StatusCode == 401 || resp.StatusCode == 403:
		return RatingResult{Status: "badkey"}
	case resp.StatusCode/100 != 2:
		return fail("http", fmt.Sprintf("HTTP %d", resp.StatusCode))
	}
	var data struct {
		Places []struct {
			DisplayName struct{ Text string } `json:"displayName"`
			Rating      *float64              `json:"rating"`
			Count       *int                  `json:"userRatingCount"`
			Website     string                `json:"websiteUri"`
			MapsURI     string                `json:"googleMapsUri"`
		} `json:"places"`
	}
	if json.NewDecoder(resp.Body).Decode(&data) != nil {
		return fail("unreadable", "answer not understood")
	}
	for _, p := range data.Places {
		u, err := url.Parse(p.Website)
		if err != nil || p.Rating == nil {
			continue
		}
		if registrableDomain(strings.TrimPrefix(strings.ToLower(u.Hostname()), "www.")) == domain {
			return RatingResult{Status: "ok", Score: math.Round(*p.Rating*10) / 10, Reviews: p.Count, Name: p.DisplayName.Text, URL: p.MapsURI}
		}
	}
	return RatingResult{Status: "none"}
}

// ---------------------------------------------------------------- one combined rating

type Combined struct {
	Score   float64 `json:"score"`
	Label   string  `json:"label"`
	Sources int     `json:"sources"`
	Reviews int     `json:"reviews"`
	Low     bool    `json:"low"`
}

func ratingLabel(s float64) string {
	switch {
	case s >= 4.5:
		return "Excellent"
	case s >= 4:
		return "Great"
	case s >= 3.5:
		return "Good"
	case s >= 3:
		return "Average"
	case s >= 2:
		return "Poor"
	}
	return "Bad"
}

// combineRatings merges every service's 0-5 score into one number. Each source is first pulled toward a neutral 3.5 in
// proportion to how few reviews it has; the results are then averaged, weighted by the square root of the review count.
func combineRatings(items []RatingResult) *Combined {
	const prior, strength = 3.5, 10.0
	var sum, weight float64
	var total, sources int
	for _, it := range items {
		if it.Status != "ok" {
			continue
		}
		n := 25.0 // unknown review counts are treated as 25
		if it.Reviews != nil {
			n = math.Max(1, float64(*it.Reviews))
			total += *it.Reviews
		}
		shrunk := (n*it.Score + strength*prior) / (n + strength)
		w := math.Sqrt(n)
		sum += w * shrunk
		weight += w
		sources++
	}
	if sources == 0 {
		return nil
	}
	score := math.Round(sum/weight*10) / 10
	return &Combined{Score: score, Label: ratingLabel(score), Sources: sources, Reviews: total, Low: total < 10}
}

// ---------------------------------------------------------------- checking a site

type NamedResult struct {
	ID     string       `json:"id"`
	Name   string       `json:"name"`
	Result RatingResult `json:"result"`
}

type SiteRatings struct {
	Domain   string        `json:"domain"`
	Results  []NamedResult `json:"results"`
	Combined *Combined     `json:"combined"`
}

type Ratings struct {
	client   *http.Client
	services []ServiceDef
	mu       sync.Mutex
	cache    map[string]cachedRating
}

type cachedRating struct {
	at time.Time
	r  RatingResult
}

func NewRatings(client *http.Client) *Ratings {
	return &Ratings{client: client, services: defaultServices, cache: map[string]cachedRating{}}
}

func ratingTTL(status string) time.Duration {
	switch status {
	case "ok":
		return 7 * 24 * time.Hour
	case "none":
		return 48 * time.Hour
	case "error", "badkey":
		return 10 * time.Minute
	}
	return 0
}

func (r *Ratings) cached(key string, produce func() RatingResult) RatingResult {
	r.mu.Lock()
	if c, ok := r.cache[key]; ok && time.Since(c.at) < ratingTTL(c.r.Status) {
		r.mu.Unlock()
		return c.r
	}
	r.mu.Unlock()
	res := produce()
	r.mu.Lock()
	r.cache[key] = cachedRating{time.Now(), res}
	r.mu.Unlock()
	return res
}

func (r *Ratings) Check(ctx context.Context, host, googleKey string) SiteRatings {
	domain := registrableDomain(strings.TrimPrefix(normalizeHost(host), "www."))
	out := SiteRatings{Domain: domain, Results: make([]NamedResult, len(r.services)+1)}
	var wg sync.WaitGroup
	for i, svc := range r.services {
		wg.Add(1)
		go func(i int, svc ServiceDef) {
			defer wg.Done()
			res := r.cached(svc.ID+":"+domain, func() RatingResult { return lookupService(ctx, r.client, svc, domain) })
			out.Results[i] = NamedResult{svc.ID, svc.Name, res}
		}(i, svc)
	}
	wg.Add(1)
	go func() {
		defer wg.Done()
		var res RatingResult
		if googleKey == "" {
			res = RatingResult{Status: "nokey"}
		} else {
			res = r.cached("google:"+domain, func() RatingResult { return lookupGoogle(ctx, r.client, domain, googleKey) })
		}
		out.Results[len(r.services)] = NamedResult{"google", "Google", res}
	}()
	wg.Wait()
	flat := make([]RatingResult, len(out.Results))
	for i, nr := range out.Results {
		flat[i] = nr.Result
	}
	out.Combined = combineRatings(flat)
	return out
}

// Describe prints a result as plain text for the command line.
func (s SiteRatings) Describe() string {
	var b strings.Builder
	if s.Combined != nil {
		note := fmt.Sprintf("%d source", s.Combined.Sources)
		if s.Combined.Sources != 1 {
			note += "s"
		}
		if s.Combined.Low {
			note += ", few reviews"
		} else {
			note += fmt.Sprintf(", %d reviews", s.Combined.Reviews)
		}
		fmt.Fprintf(&b, "%s: ★ %.1f %s (%s)\n", s.Domain, s.Combined.Score, s.Combined.Label, note)
	} else {
		fmt.Fprintf(&b, "%s: no ratings found\n", s.Domain)
	}
	for _, nr := range s.Results {
		r := nr.Result
		switch r.Status {
		case "ok":
			if r.Reviews != nil {
				fmt.Fprintf(&b, "  %-11s ★ %.1f · %d reviews\n", nr.Name, r.Score, *r.Reviews)
			} else {
				fmt.Fprintf(&b, "  %-11s ★ %.1f\n", nr.Name, r.Score)
			}
		case "none":
			fmt.Fprintf(&b, "  %-11s not listed\n", nr.Name)
		case "nokey":
			fmt.Fprintf(&b, "  %-11s add a Google Places API key to include it\n", nr.Name)
		case "badkey":
			fmt.Fprintf(&b, "  %-11s key rejected\n", nr.Name)
		default:
			fmt.Fprintf(&b, "  %-11s unavailable (%s)\n", nr.Name, r.Note)
			if r.Snippet != "" {
				fmt.Fprintf(&b, "              page says: %q\n", r.Snippet)
			}
		}
	}
	return b.String()
}
