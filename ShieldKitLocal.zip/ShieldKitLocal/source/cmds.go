package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"os"
	"os/exec"
	"os/signal"
	"runtime"
	"strings"
	"time"
)

// exitError makes main exit with a code without printing "error:" (used by `status` and `run`).
type exitError int

func (e exitError) Error() string { return fmt.Sprintf("exit status %d", int(e)) }

var noProxyList = "localhost,127.0.0.1,::1,.local"

// proxyEnv is what command-line programs read to find a proxy.
func proxyEnv(listen string) []string {
	u := "http://" + listen
	return []string{"HTTP_PROXY=" + u, "HTTPS_PROXY=" + u, "http_proxy=" + u, "https_proxy=" + u, "NO_PROXY=" + noProxyList, "no_proxy=" + noProxyList}
}

// envLines prints those variables in the syntax of a shell: posix, powershell or cmd.
func envLines(listen, shell string) string {
	var b strings.Builder
	for _, kv := range proxyEnv(listen) {
		k, v, _ := strings.Cut(kv, "=")
		switch shell {
		case "powershell":
			fmt.Fprintf(&b, "$env:%s='%s'\n", k, v)
		case "cmd":
			fmt.Fprintf(&b, "set %s=%s\n", k, v)
		default:
			fmt.Fprintf(&b, "export %s='%s'\n", k, v)
		}
	}
	return b.String()
}

func defaultShell() string {
	if runtime.GOOS == "windows" {
		return "powershell"
	}
	return "posix"
}

func listenFromConfig(path string) (string, error) {
	store, err := LoadStore(path)
	if err != nil {
		return "", fmt.Errorf("cannot read settings %s: %w", path, err)
	}
	return store.Get().Listen, nil
}

func runEnv(args []string) error {
	fs := newFlags("env")
	cfgPath := fs.String("config", defaultConfigPath(), "settings file")
	shell := fs.String("shell", defaultShell(), "posix, powershell or cmd")
	if err := fs.Parse(args); err != nil {
		return err
	}
	if *shell != "posix" && *shell != "powershell" && *shell != "cmd" {
		return errors.New("--shell must be posix, powershell or cmd")
	}
	listen, err := listenFromConfig(*cfgPath)
	if err != nil {
		return err
	}
	fmt.Print(envLines(listen, *shell))
	return nil
}

// instanceState asks a running ShieldKit Local for its state.
func instanceState(listen string) (map[string]any, error) {
	c := &http.Client{Timeout: 2 * time.Second}
	resp, err := c.Get("http://" + listen + "/api/state")
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	var st map[string]any
	if resp.StatusCode != 200 || json.NewDecoder(resp.Body).Decode(&st) != nil || st["version"] == nil {
		return nil, errors.New("something else is answering on " + listen)
	}
	return st, nil
}

func runStatus(args []string) error {
	fs := newFlags("status")
	cfgPath := fs.String("config", defaultConfigPath(), "settings file")
	if err := fs.Parse(args); err != nil {
		return err
	}
	listen, err := listenFromConfig(*cfgPath)
	if err != nil {
		return err
	}
	st, err := instanceState(listen)
	if err != nil {
		fmt.Println("ShieldKit is NOT running. Start it with:  shieldkid")
		return exitError(1)
	}
	settings, _ := st["settings"].(map[string]any)
	protection := "protection on"
	if on, _ := settings["enabled"].(bool); !on {
		protection = "protection switched OFF in the control panel"
	}
	fmt.Printf("ShieldKit is ACTIVE on %s (%s)\n", listen, protection)
	counts, _ := st["counts"].(map[string]any)
	n := func(k string) int { f, _ := counts[k].(float64); return int(f) }
	fmt.Printf("  blocked so far: %d ads, %d trackers, %d malware, %d phishing, %d downloads\n", n("ads"), n("trackers"), n("malware"), n("phishing"), n("download"))
	loc := "direct connection (no location server)"
	if active, _ := st["active"].(string); active != "" {
		servers, _ := st["servers"].([]any)
		for _, s := range servers {
			if m, _ := s.(map[string]any); m != nil && m["id"] == active {
				cc, _ := m["country"].(string)
				nm, _ := m["name"].(string)
				loc = fmt.Sprintf("%s (%s)", name(cc), nm)
			}
		}
	}
	fmt.Println("  location:", loc)
	if on, _ := st["systemProxy"].(bool); on {
		fmt.Println("  apps that follow your system proxy settings are protected")
	} else {
		fmt.Println("  system settings not changed: use the proxy " + listen + " in an app, or:  shieldkid run <command>")
	}
	fmt.Printf("  control panel: http://%s/\n", listen)
	return nil
}

func runPanel(args []string) error {
	fs := newFlags("panel")
	cfgPath := fs.String("config", defaultConfigPath(), "settings file")
	if err := fs.Parse(args); err != nil {
		return err
	}
	listen, err := listenFromConfig(*cfgPath)
	if err != nil {
		return err
	}
	if _, err := instanceState(listen); err != nil {
		return errors.New("ShieldKit is not running. Start it with:  shieldkid")
	}
	openBrowser("http://" + listen + "/")
	fmt.Println("Opening http://" + listen + "/")
	return nil
}

// runOff restores the network settings saved by an earlier run. Use it if a run ever stopped without restoring them.
func runOff(args []string) error {
	fs := newFlags("off")
	cfgPath := fs.String("config", defaultConfigPath(), "settings file")
	if err := fs.Parse(args); err != nil {
		return err
	}
	sp := sysProxyFactory()
	if sp == nil {
		fmt.Println("Nothing to do: ShieldKit does not change system settings on this computer.")
		return nil
	}
	ok, err := restoreBackup(sp, backupPath(*cfgPath))
	if err != nil {
		return err
	}
	if ok {
		fmt.Println("Your earlier network settings are back.")
	} else {
		fmt.Println("Nothing to restore: ShieldKit has not changed your network settings.")
	}
	return nil
}

// runWrapped starts a program with the proxy already set, so ShieldKit protects exactly that program:
//
//	shieldkid run curl https://example.com
func runWrapped(args []string) error {
	fs := newFlags("run")
	cfgPath := fs.String("config", defaultConfigPath(), "settings file")
	if err := fs.Parse(args); err != nil {
		return err
	}
	rest := fs.Args()
	if len(rest) == 0 {
		return errors.New("usage: shieldkid run COMMAND [arguments]   (for example: shieldkid run git clone https://example.com/repo.git)")
	}
	if _, err := exec.LookPath(rest[0]); err != nil {
		return fmt.Errorf("cannot find the program %q", rest[0])
	}
	a, err := startApp(startOptions{configPath: *cfgPath, system: false})
	listen := ""
	switch {
	case err == nil:
		defer a.Stop()
		listen = a.cfg.Listen
	case errors.Is(err, errInUse):
		if listen, err = listenFromConfig(*cfgPath); err != nil {
			return err
		}
		if _, err := instanceState(listen); err != nil {
			return fmt.Errorf("%s is used by another program, not by ShieldKit", listen)
		}
	default:
		return err
	}
	cmd := exec.Command(rest[0], rest[1:]...)
	cmd.Env = append(os.Environ(), proxyEnv(listen)...)
	cmd.Stdin, cmd.Stdout, cmd.Stderr = os.Stdin, os.Stdout, os.Stderr
	sig := make(chan os.Signal, 1)
	signal.Notify(sig, os.Interrupt) // Ctrl+C goes to the program we started, not to us
	defer signal.Stop(sig)
	if err := cmd.Run(); err != nil {
		var ee *exec.ExitError
		if errors.As(err, &ee) {
			if a != nil {
				a.Stop()
			}
			return exitError(ee.ExitCode())
		}
		return err
	}
	return nil
}
