package main

import (
	"bufio"
	"context"
	"encoding/base64"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"
)

// ---------------------------------------------------------------- helpers

type rig struct {
	t       *testing.T
	proxy   *Proxy
	server  *httptest.Server // the proxy, listening on loopback
	origin  *httptest.Server // pretends to be every website
	mu      sync.Mutex
	dialled []string // every name the proxy asked to connect to (loopback addresses excluded)
	hits    int
	lastReq *http.Request
}

func newRig(t *testing.T, mutate func(*Config)) *rig {
	t.Helper()
	r := &rig{t: t}
	r.origin = httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		r.mu.Lock()
		r.hits++
		r.lastReq = req.Clone(context.Background())
		r.mu.Unlock()
		fmt.Fprintf(w, "origin saw %s %s", req.Host, req.URL.RequestURI())
	}))
	store, _ := LoadStore("")
	_ = store.Update(func(c *Config) error {
		if mutate != nil {
			mutate(c)
		}
		return nil
	})
	r.proxy = NewProxy(store, testEngine())
	r.proxy.dial = func(ctx context.Context, network, addr string) (net.Conn, error) {
		host, _, _ := net.SplitHostPort(addr)
		if net.ParseIP(host) != nil { // real loopback address (a fake upstream server, or the origin): connect as asked
			return netDialer.DialContext(ctx, network, addr)
		}
		r.mu.Lock()
		r.dialled = append(r.dialled, addr)
		r.mu.Unlock()
		return netDialer.DialContext(ctx, network, r.origin.Listener.Addr().String()) // any website name leads to the origin
	}
	r.proxy.Reload()
	r.server = httptest.NewServer(r.proxy)
	_ = store.Update(func(c *Config) error { c.Listen = strings.TrimPrefix(r.server.URL, "http://"); return nil })
	t.Cleanup(func() { r.server.Close(); r.origin.Close() })
	return r
}

func (r *rig) client() *http.Client {
	pu, _ := url.Parse(r.server.URL)
	return &http.Client{
		Transport:     &http.Transport{Proxy: http.ProxyURL(pu), DisableKeepAlives: true},
		Timeout:       5 * time.Second,
		CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse },
	}
}

func (r *rig) get(rawURL string) (*http.Response, string) {
	r.t.Helper()
	resp, err := r.client().Get(rawURL)
	if err != nil {
		r.t.Fatalf("GET %s: %v", rawURL, err)
	}
	defer resp.Body.Close()
	b, _ := io.ReadAll(resp.Body)
	return resp, string(b)
}

func (r *rig) originHits() int { r.mu.Lock(); defer r.mu.Unlock(); return r.hits }
func (r *rig) dials() []string {
	r.mu.Lock()
	defer r.mu.Unlock()
	return append([]string(nil), r.dialled...)
}

// connect sends a CONNECT request to the proxy and returns the raw connection and the status line.
func (r *rig) connect(target string) (net.Conn, string) {
	r.t.Helper()
	c, err := net.Dial("tcp", strings.TrimPrefix(r.server.URL, "http://"))
	if err != nil {
		r.t.Fatal(err)
	}
	_ = c.SetDeadline(time.Now().Add(5 * time.Second))
	fmt.Fprintf(c, "CONNECT %s HTTP/1.1\r\nHost: %s\r\n\r\n", target, target)
	br := bufio.NewReader(c)
	status, _ := br.ReadString('\n')
	for { // skip headers
		line, err := br.ReadString('\n')
		if err != nil || line == "\r\n" {
			break
		}
	}
	return &bufferedConn{Conn: c, r: br}, strings.TrimSpace(status)
}

// echoServer is a raw TCP server that sends back whatever it receives.
func echoServer(t *testing.T) string {
	t.Helper()
	l, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { l.Close() })
	go func() {
		for {
			c, err := l.Accept()
			if err != nil {
				return
			}
			go func() { defer c.Close(); io.Copy(c, c) }()
		}
	}()
	return l.Addr().String()
}

// ---------------------------------------------------------------- plain HTTP

func TestHTTPForwardsAndAddsPrivacyHeaders(t *testing.T) {
	r := newRig(t, nil)
	req, _ := http.NewRequest("GET", "http://shop.example/hello?a=1", nil)
	req.Header.Set("Proxy-Connection", "keep-alive")
	resp, err := r.client().Do(req)
	if err != nil {
		t.Fatal(err)
	}
	b, _ := io.ReadAll(resp.Body)
	resp.Body.Close()
	if resp.StatusCode != 200 || string(b) != "origin saw shop.example /hello?a=1" {
		t.Fatalf("got %d %q", resp.StatusCode, b)
	}
	if r.lastReq.Header.Get("Sec-GPC") != "1" || r.lastReq.Header.Get("DNT") != "1" {
		t.Error("privacy headers missing")
	}
	if r.lastReq.Header.Get("Proxy-Connection") != "" {
		t.Error("hop-by-hop header leaked to the website")
	}
}

func TestHTTPPostBodyPassesThrough(t *testing.T) {
	r := newRig(t, nil)
	r.origin.Config.Handler = http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		b, _ := io.ReadAll(req.Body)
		fmt.Fprintf(w, "%s:%s", req.Method, b)
	})
	resp, err := r.client().Post("http://api.example/submit", "text/plain", strings.NewReader("hello body"))
	if err != nil {
		t.Fatal(err)
	}
	b, _ := io.ReadAll(resp.Body)
	if string(b) != "POST:hello body" {
		t.Fatalf("got %q", b)
	}
}

func TestAdsAreAnsweredQuietly(t *testing.T) {
	r := newRig(t, nil)
	resp, _ := r.get("http://cdn.adnet.test/banner.js")
	if resp.StatusCode != 204 || resp.Header.Get("X-ShieldKit-Blocked") != "ads" {
		t.Fatalf("got %d %v", resp.StatusCode, resp.Header)
	}
	resp, _ = r.get("http://tracker.test/pixel.gif")
	if resp.StatusCode != 204 || resp.Header.Get("X-ShieldKit-Blocked") != "trackers" {
		t.Fatalf("tracker: got %d", resp.StatusCode)
	}
	if r.originHits() != 0 {
		t.Error("blocked requests must never reach the website")
	}
}

func TestMalwareShowsBlockPage(t *testing.T) {
	r := newRig(t, nil)
	resp, body := r.get("http://miner.test/x")
	if resp.StatusCode != 403 || !strings.Contains(body, "Malicious site blocked") || !strings.Contains(body, "miner.test") {
		t.Fatalf("got %d %s", resp.StatusCode, body)
	}
}

func TestPhishingPageHasContinueLinkWithToken(t *testing.T) {
	r := newRig(t, nil)
	resp, body := r.get("http://paypal-login.com/signin")
	if resp.StatusCode != 403 || !strings.Contains(body, "Continue anyway") || !strings.Contains(body, "token="+r.proxy.token) {
		t.Fatalf("got %d %s", resp.StatusCode, body)
	}
	if r.originHits() != 0 {
		t.Error("phishing site was contacted")
	}
}

func TestMasterSwitchAndTogglesLetTrafficThrough(t *testing.T) {
	r := newRig(t, func(c *Config) { c.Enabled = false })
	if resp, _ := r.get("http://adnet.test/x"); resp.StatusCode != 200 {
		t.Errorf("master switch off: got %d", resp.StatusCode)
	}
	r = newRig(t, func(c *Config) { c.Ads = false })
	if resp, _ := r.get("http://adnet.test/x"); resp.StatusCode != 200 {
		t.Errorf("ads off: got %d", resp.StatusCode)
	}
}

func TestDownloadsOverHTTP(t *testing.T) {
	r := newRig(t, nil)
	if resp, body := r.get("http://shop.example/setup.exe"); resp.StatusCode != 403 || !strings.Contains(body, "Risky download blocked") {
		t.Errorf("exe over http: %d", resp.StatusCode)
	}
	if resp, _ := r.get("http://shop.example/invoice.pdf.exe"); resp.StatusCode != 403 {
		t.Errorf("double extension: %d", resp.StatusCode)
	}
	if resp, _ := r.get("http://shop.example/report.pdf"); resp.StatusCode != 200 {
		t.Errorf("pdf: %d", resp.StatusCode)
	}
	if resp, _ := r.get("http://shop.example/archive.zip"); resp.StatusCode != 200 {
		t.Errorf("zip in relaxed mode: %d", resp.StatusCode)
	}
	if resp, _ := r.get("http://download.windowsupdate.com/patch.exe"); resp.StatusCode != 200 {
		t.Errorf("allow-listed update host: %d", resp.StatusCode)
	}
	strict := newRig(t, func(c *Config) { c.DownloadsStrict = true })
	if resp, _ := strict.get("http://shop.example/archive.zip"); resp.StatusCode != 403 {
		t.Errorf("zip in strict mode: %d", resp.StatusCode)
	}
	off := newRig(t, func(c *Config) { c.Downloads = false })
	if resp, _ := off.get("http://shop.example/setup.exe"); resp.StatusCode != 200 {
		t.Errorf("downloads off: %d", resp.StatusCode)
	}
}

func TestUpgradeAndStripParams(t *testing.T) {
	r := newRig(t, func(c *Config) { c.UpgradeHTTP = true })
	resp, _ := r.get("http://shop.example:80/page?x=1")
	if resp.StatusCode != 308 || resp.Header.Get("Location") != "https://shop.example/page?x=1" {
		t.Fatalf("got %d %q", resp.StatusCode, resp.Header.Get("Location"))
	}
	if resp, _ := r.get("http://localhost/page"); resp.StatusCode == 308 {
		t.Error("local addresses must not be upgraded")
	}
	s := newRig(t, func(c *Config) { c.StripParams = true })
	_, body := s.get("http://shop.example/p?keep=1&utm_source=x&fbclid=abc&other=%20z&gclid=q")
	if body != "origin saw shop.example /p?keep=1&other=%20z" {
		t.Fatalf("got %q", body)
	}
	if got := stripTrackingParams("a=1&b"); got != "a=1&b" {
		t.Errorf("unchanged query altered: %q", got)
	}
}

func TestStatsAndLog(t *testing.T) {
	r := newRig(t, nil)
	r.get("http://adnet.test/a")
	r.get("http://miner.test/b")
	counts, events := r.proxy.stats.Snapshot()
	if counts["ads"] != 1 || counts["malware"] != 1 || len(events) != 2 || events[0].Host != "miner.test" {
		t.Fatalf("counts=%v events=%v", counts, events)
	}
}

// ---------------------------------------------------------------- HTTPS tunnels

func TestConnectTunnelsBytes(t *testing.T) {
	r := newRig(t, nil)
	echo := echoServer(t)
	r.origin.Close()
	r.proxy.dial = func(ctx context.Context, network, addr string) (net.Conn, error) {
		return netDialer.DialContext(ctx, network, echo)
	}
	c, status := r.connect("secure.example:443")
	defer c.Close()
	if !strings.Contains(status, "200") {
		t.Fatalf("status %q", status)
	}
	fmt.Fprint(c, "ping-through-tunnel")
	buf := make([]byte, 19)
	if _, err := io.ReadFull(c, buf); err != nil || string(buf) != "ping-through-tunnel" {
		t.Fatalf("got %q err %v", buf, err)
	}
}

func TestConnectBlocksListedAndPhishingHosts(t *testing.T) {
	r := newRig(t, nil)
	for _, target := range []string{"adnet.test:443", "x.miner.test:443", "paypal-login.com:443"} {
		c, status := r.connect(target)
		c.Close()
		if !strings.Contains(status, "403") {
			t.Errorf("%s: %q", target, status)
		}
	}
	if len(r.dials()) != 0 {
		t.Errorf("blocked tunnels must not open connections: %v", r.dials())
	}
	c, status := r.connect("shop.example:443")
	c.Close()
	if !strings.Contains(status, "200") {
		t.Errorf("normal host: %q", status)
	}
}

func TestSafeSearchRoutesToSafeServers(t *testing.T) {
	cases := map[string]string{
		"www.google.com:443": "forcesafesearch.google.com:443", "google.co.uk:443": "forcesafesearch.google.com:443",
		"www.google.de:443": "forcesafesearch.google.com:443", "www.bing.com:443": "strict.bing.com:443",
		"duckduckgo.com:443": "safe.duckduckgo.com:443", "www.youtube.com:443": "restrictmoderate.youtube.com:443",
		"m.youtube.com:443": "restrictmoderate.youtube.com:443", "youtubei.googleapis.com:443": "restrictmoderate.youtube.com:443",
		// not search engines: must be untouched
		"mail.google.com:443": "mail.google.com:443", "docs.google.com:443": "docs.google.com:443",
		"www.bing.com.evil.net:443": "www.bing.com.evil.net:443", "shop.example:443": "shop.example:443",
	}
	r := newRig(t, nil)
	for from, want := range cases {
		before := len(r.dials())
		c, status := r.connect(from)
		c.Close()
		if !strings.Contains(status, "200") {
			t.Errorf("%s: %q", from, status)
			continue
		}
		time.Sleep(10 * time.Millisecond)
		d := r.dials()
		if len(d) != before+1 || d[len(d)-1] != want {
			t.Errorf("%s: connected to %v, want %s", from, d[before:], want)
		}
	}

	// a look-alike of Google is blocked as phishing; it is never "rescued" by the SafeSearch routing
	if c, status := r.connect("google.evil.com:443"); !strings.Contains(status, "403") {
		t.Errorf("google.evil.com: %q", status)
	} else {
		c.Close()
	}

	strict := newRig(t, func(c *Config) { c.YouTube = "strict" })
	c, _ := strict.connect("www.youtube.com:443")
	c.Close()
	if d := strict.dials(); len(d) != 1 || d[0] != "restrict.youtube.com:443" {
		t.Errorf("youtube strict: %v", d)
	}
	off := newRig(t, func(c *Config) { c.SafeSearch = false; c.YouTube = "off" })
	c, _ = off.connect("www.google.com:443")
	c.Close()
	c, _ = off.connect("www.youtube.com:443")
	c.Close()
	if d := off.dials(); len(d) != 2 || d[0] != "www.google.com:443" || d[1] != "www.youtube.com:443" {
		t.Errorf("safe search off: %v", d)
	}
	paused := newRig(t, func(c *Config) { c.Enabled = false })
	c, _ = paused.connect("www.google.com:443")
	c.Close()
	if d := paused.dials(); len(d) != 1 || d[0] != "www.google.com:443" {
		t.Errorf("master switch off: %v", d)
	}
}

// ---------------------------------------------------------------- upstream servers

// fakeSocks is a minimal SOCKS5 server. It records what was asked and connects every name to the echo/origin target.
type fakeSocks struct {
	l        net.Listener
	user     string
	pass     string
	mu       sync.Mutex
	targets  []string
	rejected int
}

func newFakeSocks(t *testing.T, user, pass string, to string) *fakeSocks {
	l, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	s := &fakeSocks{l: l, user: user, pass: pass}
	t.Cleanup(func() { l.Close() })
	go func() {
		for {
			c, err := l.Accept()
			if err != nil {
				return
			}
			go s.serve(c, to)
		}
	}()
	return s
}

func (s *fakeSocks) serve(c net.Conn, to string) {
	defer c.Close()
	head := make([]byte, 2)
	if _, err := io.ReadFull(c, head); err != nil {
		return
	}
	methods := make([]byte, head[1])
	io.ReadFull(c, methods)
	if s.user != "" {
		c.Write([]byte{5, 2})
		h := make([]byte, 2)
		io.ReadFull(c, h)
		u := make([]byte, h[1])
		io.ReadFull(c, u)
		pl := make([]byte, 1)
		io.ReadFull(c, pl)
		p := make([]byte, pl[0])
		io.ReadFull(c, p)
		if string(u) != s.user || string(p) != s.pass {
			c.Write([]byte{1, 1})
			s.mu.Lock()
			s.rejected++
			s.mu.Unlock()
			return
		}
		c.Write([]byte{1, 0})
	} else {
		c.Write([]byte{5, 0})
	}
	req := make([]byte, 4)
	if _, err := io.ReadFull(c, req); err != nil {
		return
	}
	var host string
	switch req[3] {
	case 1:
		b := make([]byte, 4)
		io.ReadFull(c, b)
		host = net.IP(b).String()
	case 3:
		l := make([]byte, 1)
		io.ReadFull(c, l)
		b := make([]byte, l[0])
		io.ReadFull(c, b)
		host = string(b)
	}
	pb := make([]byte, 2)
	io.ReadFull(c, pb)
	port := int(pb[0])<<8 | int(pb[1])
	s.mu.Lock()
	s.targets = append(s.targets, net.JoinHostPort(host, strconv.Itoa(port)))
	s.mu.Unlock()
	dst, err := net.Dial("tcp", to)
	if err != nil {
		c.Write([]byte{5, 5, 0, 1, 0, 0, 0, 0, 0, 0})
		return
	}
	defer dst.Close()
	c.Write([]byte{5, 0, 0, 1, 0, 0, 0, 0, 0, 0})
	go io.Copy(dst, c)
	io.Copy(c, dst)
}

func (s *fakeSocks) seen() []string {
	s.mu.Lock()
	defer s.mu.Unlock()
	return append([]string(nil), s.targets...)
}
func (s *fakeSocks) server(id string) Server {
	host, port, _ := net.SplitHostPort(s.l.Addr().String())
	p, _ := strconv.Atoi(port)
	return Server{ID: id, Country: "NL", Name: id, Scheme: "socks5", Host: host, Port: p, Username: s.user, Password: s.pass}
}

func TestUpstreamSocks5CarriesTunnelsAndHTTP(t *testing.T) {
	r := newRig(t, nil)
	socks := newFakeSocks(t, "", "", r.origin.Listener.Addr().String())
	_ = r.proxy.store.Update(func(c *Config) error {
		c.Servers = []Server{socks.server("s1")}
		c.Active = "s1"
		return nil
	})
	c, status := r.connect("secure.example:443")
	c.Close()
	if !strings.Contains(status, "200") {
		t.Fatalf("tunnel via socks5: %q", status)
	}
	resp, body := r.get("http://shop.example/page")
	if resp.StatusCode != 200 || !strings.Contains(body, "origin saw shop.example /page") {
		t.Fatalf("plain http via socks5: %d %q", resp.StatusCode, body)
	}
	seen := socks.seen()
	if len(seen) != 2 || seen[0] != "secure.example:443" || seen[1] != "shop.example:80" {
		t.Fatalf("upstream saw %v (names must be sent unresolved)", seen)
	}
	if len(r.dials()) != 0 {
		t.Errorf("the proxy resolved/dialled website names itself instead of the upstream: %v", r.dials())
	}
}

func TestUpstreamSocks5Login(t *testing.T) {
	r := newRig(t, nil)
	socks := newFakeSocks(t, "alice", "s3cret", r.origin.Listener.Addr().String())
	good := socks.server("good")
	bad := socks.server("bad")
	bad.Password = "wrong"
	_ = r.proxy.store.Update(func(c *Config) error { c.Servers = []Server{good, bad}; c.Active = "good"; return nil })
	c, status := r.connect("secure.example:443")
	c.Close()
	if !strings.Contains(status, "200") {
		t.Fatalf("with the right login: %q", status)
	}
	_ = r.proxy.store.Update(func(c *Config) error { c.Active = "bad"; return nil })
	c, status = r.connect("secure.example:443")
	c.Close()
	if !strings.Contains(status, "502") {
		t.Fatalf("wrong login must fail closed: %q", status)
	}
}

func TestLocalAddressesBypassTheUpstream(t *testing.T) {
	r := newRig(t, nil)
	socks := newFakeSocks(t, "", "", "127.0.0.1:1")
	_ = r.proxy.store.Update(func(c *Config) error { c.Servers = []Server{socks.server("s")}; c.Active = "s"; return nil })
	resp, body := r.get(r.origin.URL + "/local") // 127.0.0.1 origin
	if resp.StatusCode != 200 || !strings.Contains(body, "/local") {
		t.Fatalf("local request: %d %q", resp.StatusCode, body)
	}
	if len(socks.seen()) != 0 {
		t.Errorf("local traffic went through the upstream: %v", socks.seen())
	}
	echo := echoServer(t)
	c, status := r.connect(echo) // CONNECT to a loopback address
	if !strings.Contains(status, "200") {
		t.Fatalf("local tunnel: %q", status)
	}
	c.Close()
	if len(socks.seen()) != 0 {
		t.Errorf("local tunnel went through the upstream: %v", socks.seen())
	}
}

func TestHTTPUpstreamConnectWithLogin(t *testing.T) {
	r := newRig(t, nil)
	var mu sync.Mutex
	var connects []string
	var auths []string
	up := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		mu.Lock()
		auths = append(auths, req.Header.Get("Proxy-Authorization"))
		mu.Unlock()
		want := "Basic " + base64.StdEncoding.EncodeToString([]byte("bob:pw"))
		if req.Header.Get("Proxy-Authorization") != want {
			w.Header().Set("Proxy-Authenticate", `Basic realm="x"`)
			http.Error(w, "login needed", http.StatusProxyAuthRequired)
			return
		}
		if req.Method == http.MethodConnect {
			mu.Lock()
			connects = append(connects, req.Host)
			mu.Unlock()
			dst, err := net.Dial("tcp", r.origin.Listener.Addr().String())
			if err != nil {
				http.Error(w, err.Error(), 502)
				return
			}
			conn, _, _ := w.(http.Hijacker).Hijack()
			conn.Write([]byte("HTTP/1.1 200 OK\r\n\r\n"))
			go io.Copy(dst, conn)
			io.Copy(conn, dst)
			conn.Close()
			dst.Close()
			return
		}
		// plain request in absolute form
		mu.Lock()
		connects = append(connects, "GET "+req.URL.String())
		mu.Unlock()
		fmt.Fprint(w, "forwarded by upstream")
	}))
	defer up.Close()
	host, port, _ := net.SplitHostPort(strings.TrimPrefix(up.URL, "http://"))
	p, _ := strconv.Atoi(port)
	srv := Server{ID: "h", Scheme: "http", Host: host, Port: p, Username: "bob", Password: "pw"}
	_ = r.proxy.store.Update(func(c *Config) error { c.Servers = []Server{srv}; c.Active = "h"; return nil })

	c, status := r.connect("secure.example:443")
	c.Close()
	if !strings.Contains(status, "200") {
		t.Fatalf("CONNECT via http upstream: %q", status)
	}
	resp, body := r.get("http://shop.example/x")
	if resp.StatusCode != 200 || body != "forwarded by upstream" {
		t.Fatalf("plain via http upstream: %d %q", resp.StatusCode, body)
	}
	mu.Lock()
	got := strings.Join(connects, "|")
	mu.Unlock()
	if got != "secure.example:443|GET http://shop.example/x" {
		t.Fatalf("upstream saw %q", got)
	}

	bad := srv
	bad.ID, bad.Password = "hbad", "nope"
	_ = r.proxy.store.Update(func(c *Config) error { c.Servers = append(c.Servers, bad); c.Active = "hbad"; return nil })
	c, status = r.connect("secure.example:443")
	c.Close()
	if !strings.Contains(status, "502") {
		t.Fatalf("rejected login must fail: %q", status)
	}
}

func TestKillSwitch(t *testing.T) {
	dead := Server{ID: "dead", Scheme: "socks5", Host: "127.0.0.1", Port: 1} // nothing listens here
	r := newRig(t, func(c *Config) { c.Servers = []Server{dead}; c.Active = "dead"; c.KillSwitch = true })
	c, status := r.connect("secure.example:443")
	c.Close()
	if !strings.Contains(status, "502") {
		t.Errorf("kill switch on, tunnel: %q", status)
	}
	if resp, _ := r.get("http://shop.example/x"); resp.StatusCode != 502 {
		t.Errorf("kill switch on, http: %d", resp.StatusCode)
	}
	if r.originHits() != 0 {
		t.Error("traffic leaked around the dead upstream while the kill switch was on")
	}

	open := newRig(t, func(c *Config) { c.Servers = []Server{dead}; c.Active = "dead"; c.KillSwitch = false })
	c, status = open.connect("secure.example:443")
	c.Close()
	if !strings.Contains(status, "200") {
		t.Errorf("kill switch off, tunnel should fall back to direct: %q", status)
	}
	if resp, body := open.get("http://shop.example/x"); resp.StatusCode != 200 || !strings.Contains(body, "origin saw") {
		t.Errorf("kill switch off, http should fall back to direct: %d %q", resp.StatusCode, body)
	}
}
