package main

import "fmt"

// pacScript is the "automatic proxy configuration" file many apps and operating systems accept. Local and
// private addresses go direct. With strict set there is no DIRECT fallback: if ShieldKit Local is not running,
// nothing connects instead of silently skipping the protection.
func pacScript(listen string, strict bool) string {
	target := "PROXY " + listen
	if !strict {
		target += "; DIRECT"
	}
	return fmt.Sprintf(`function FindProxyForURL(url, host) {
  if (isPlainHostName(host) || host === "localhost" || shExpMatch(host, "*.local") || shExpMatch(host, "*.lan") ||
      shExpMatch(host, "*.internal") || shExpMatch(host, "*.home.arpa")) return "DIRECT";
  if (/^\d+\.\d+\.\d+\.\d+$/.test(host) && (isInNet(host, "10.0.0.0", "255.0.0.0") || isInNet(host, "127.0.0.0", "255.0.0.0") ||
      isInNet(host, "169.254.0.0", "255.255.0.0") || isInNet(host, "172.16.0.0", "255.240.0.0") ||
      isInNet(host, "192.168.0.0", "255.255.0.0"))) return "DIRECT";
  return "%s";
}
`, target)
}
