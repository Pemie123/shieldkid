package main

import (
	"bufio"
	"context"
	"crypto/tls"
	"encoding/base64"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"strconv"
	"time"
)

// DialFunc opens a TCP connection. The proxy uses net.Dialer; tests replace it.
type DialFunc func(ctx context.Context, network, addr string) (net.Conn, error)

var netDialer = &net.Dialer{Timeout: 15 * time.Second, KeepAlive: 30 * time.Second}

func baseDial(ctx context.Context, network, addr string) (net.Conn, error) {
	return netDialer.DialContext(ctx, network, addr)
}

// dialVia opens a tunnel to target ("host:port") through the upstream server s.
// The target name is sent to the server unresolved, so DNS happens at the far end.
func dialVia(ctx context.Context, s *Server, target string, base DialFunc) (net.Conn, error) {
	conn, err := base(ctx, "tcp", net.JoinHostPort(s.Host, strconv.Itoa(s.Port)))
	if err != nil {
		return nil, fmt.Errorf("cannot reach %s server %s:%d: %w", s.Scheme, s.Host, s.Port, err)
	}
	deadline := time.Now().Add(15 * time.Second)
	if d, ok := ctx.Deadline(); ok && d.Before(deadline) {
		deadline = d
	}
	_ = conn.SetDeadline(deadline)

	var out net.Conn = conn
	switch s.Scheme {
	case "socks5":
		err = socks5Connect(conn, s.Username, s.Password, target)
	case "http":
		out, err = httpConnect(conn, s, target)
	case "https":
		tc := tls.Client(conn, &tls.Config{ServerName: s.Host, MinVersion: tls.VersionTLS12})
		if err = tc.HandshakeContext(ctx); err == nil {
			out, err = httpConnect(tc, s, target)
		}
	default:
		err = fmt.Errorf("unknown server type %q", s.Scheme)
	}
	if err != nil {
		conn.Close()
		return nil, err
	}
	_ = conn.SetDeadline(time.Time{})
	return out, nil
}

// ---- SOCKS5 (RFC 1928, with username/password from RFC 1929)

func socks5Connect(conn net.Conn, user, pass, target string) error {
	host, portStr, err := net.SplitHostPort(target)
	if err != nil {
		return err
	}
	port, err := strconv.Atoi(portStr)
	if err != nil || port < 1 || port > 65535 {
		return fmt.Errorf("bad port in %q", target)
	}
	methods := []byte{0x00}
	if user != "" {
		methods = []byte{0x00, 0x02}
	}
	if _, err := conn.Write(append([]byte{0x05, byte(len(methods))}, methods...)); err != nil {
		return err
	}
	reply := make([]byte, 2)
	if _, err := io.ReadFull(conn, reply); err != nil {
		return fmt.Errorf("socks5 greeting: %w", err)
	}
	if reply[0] != 0x05 {
		return errors.New("server is not a SOCKS5 proxy")
	}
	switch reply[1] {
	case 0x00:
	case 0x02:
		if user == "" || len(user) > 255 || len(pass) > 255 {
			return errors.New("socks5 server wants a login")
		}
		msg := append([]byte{0x01, byte(len(user))}, user...)
		msg = append(append(msg, byte(len(pass))), pass...)
		if _, err := conn.Write(msg); err != nil {
			return err
		}
		if _, err := io.ReadFull(conn, reply); err != nil {
			return fmt.Errorf("socks5 login: %w", err)
		}
		if reply[1] != 0x00 {
			return errors.New("socks5 login rejected")
		}
	case 0xFF:
		return errors.New("socks5 server accepts none of our login methods")
	default:
		return fmt.Errorf("socks5 server chose unsupported method %d", reply[1])
	}

	req := []byte{0x05, 0x01, 0x00}
	if ip := net.ParseIP(host); ip != nil {
		if v4 := ip.To4(); v4 != nil {
			req = append(append(req, 0x01), v4...)
		} else {
			req = append(append(req, 0x04), ip.To16()...)
		}
	} else {
		if len(host) > 255 {
			return errors.New("host name too long")
		}
		req = append(append(req, 0x03, byte(len(host))), host...)
	}
	req = binary.BigEndian.AppendUint16(req, uint16(port))
	if _, err := conn.Write(req); err != nil {
		return err
	}
	head := make([]byte, 4)
	if _, err := io.ReadFull(conn, head); err != nil {
		return fmt.Errorf("socks5 reply: %w", err)
	}
	if head[1] != 0x00 {
		return fmt.Errorf("socks5 server refused the connection: %s", socksReplyText(head[1]))
	}
	var skip int
	switch head[3] {
	case 0x01:
		skip = 4 + 2
	case 0x04:
		skip = 16 + 2
	case 0x03:
		l := make([]byte, 1)
		if _, err := io.ReadFull(conn, l); err != nil {
			return err
		}
		skip = int(l[0]) + 2
	default:
		return errors.New("socks5 reply has an unknown address type")
	}
	_, err = io.CopyN(io.Discard, conn, int64(skip))
	return err
}

func socksReplyText(code byte) string {
	switch code {
	case 1:
		return "general failure"
	case 2:
		return "not allowed by ruleset"
	case 3:
		return "network unreachable"
	case 4:
		return "host unreachable"
	case 5:
		return "connection refused"
	case 6:
		return "TTL expired"
	case 7:
		return "command not supported"
	case 8:
		return "address type not supported"
	}
	return "code " + strconv.Itoa(int(code))
}

// ---- HTTP / HTTPS proxies (CONNECT)

type bufferedConn struct {
	net.Conn
	r io.Reader
}

func (b *bufferedConn) Read(p []byte) (int, error) { return b.r.Read(p) }

func httpConnect(conn net.Conn, s *Server, target string) (net.Conn, error) {
	req := "CONNECT " + target + " HTTP/1.1\r\nHost: " + target + "\r\nUser-Agent: ShieldKitLocal\r\n"
	if s.Username != "" {
		req += "Proxy-Authorization: Basic " + base64.StdEncoding.EncodeToString([]byte(s.Username+":"+s.Password)) + "\r\n"
	}
	if _, err := io.WriteString(conn, req+"\r\n"); err != nil {
		return nil, err
	}
	br := bufio.NewReader(conn)
	resp, err := http.ReadResponse(br, &http.Request{Method: http.MethodConnect})
	if err != nil {
		return nil, fmt.Errorf("proxy did not answer: %w", err)
	}
	resp.Body.Close()
	if resp.StatusCode == http.StatusProxyAuthRequired {
		return nil, errors.New("proxy login rejected (HTTP 407)")
	}
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("proxy refused the tunnel: %s", resp.Status)
	}
	if br.Buffered() > 0 {
		return &bufferedConn{Conn: conn, r: io.MultiReader(br, conn)}, nil
	}
	return conn, nil
}

// proxyURL turns a server into the URL Go's http.Transport understands, for plain-HTTP requests.
func proxyURL(s *Server) *url.URL {
	u := &url.URL{Scheme: s.Scheme, Host: net.JoinHostPort(s.Host, strconv.Itoa(s.Port))}
	if s.Username != "" {
		u.User = url.UserPassword(s.Username, s.Password)
	}
	return u
}
