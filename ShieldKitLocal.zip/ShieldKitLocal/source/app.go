package main

import (
	"context"
	"errors"
	"fmt"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"
)

var errInUse = errors.New("address already in use")

type startOptions struct {
	configPath string
	listen     string
	system     bool // also point the operating system's proxy setting at ShieldKit Local
	log        func(string)
}

// app is a running ShieldKit Local: the proxy, the control panel, and (optionally) the system settings.
type app struct {
	cfg        Config
	cfgPath    string
	firstRun   bool
	store      *Store
	engine     *Engine
	proxy      *Proxy
	mgr        *Manager
	srv        *http.Server
	serveErr   chan error
	restore    func()
	systemNote string // why the system settings were not changed, if they were not
}

func startApp(o startOptions) (*app, error) {
	if o.log == nil {
		o.log = func(string) {}
	}
	_, statErr := os.Stat(o.configPath)
	store, err := LoadStore(o.configPath)
	if err != nil {
		return nil, fmt.Errorf("cannot read settings %s: %w", o.configPath, err)
	}
	if o.listen != "" {
		_ = store.Update(func(c *Config) error { c.Listen = o.listen; return nil })
	} else {
		_ = store.Update(func(c *Config) error { return nil }) // writes the settings file on the very first run
	}
	cfg := store.Get()
	if err := loopbackOnly(cfg.Listen); err != nil {
		return nil, err
	}
	engine := NewEngine()
	proxy := NewProxy(store, engine)
	mgr := NewManager(store, proxy)
	proxy.panel = NewPanel(store, proxy, engine, mgr, NewRatings(directClient())).Handler()

	ln, err := net.Listen("tcp", cfg.Listen)
	if err != nil {
		if strings.Contains(err.Error(), "address already in use") || strings.Contains(err.Error(), "Only one usage") {
			return nil, fmt.Errorf("%w: %s is taken. Is ShieldKit Local already running? Otherwise choose another port: shieldkid --listen 127.0.0.1:8898", errInUse, cfg.Listen)
		}
		return nil, err
	}
	a := &app{cfg: cfg, cfgPath: o.configPath, firstRun: statErr != nil, store: store, engine: engine, proxy: proxy, mgr: mgr, serveErr: make(chan error, 1)}
	a.srv = &http.Server{Handler: proxy, ReadHeaderTimeout: 20 * time.Second, IdleTimeout: 120 * time.Second}
	go func() { a.serveErr <- a.srv.Serve(ln) }()
	go mgr.Resume(context.Background())

	if o.system {
		// Only now, with the proxy really listening: a second copy that failed to start never touches the settings.
		if sp := sysProxyFactory(); sp == nil {
			a.systemNote = "automatic system settings are not available on this computer"
		} else if restore, err := activateSystemProxy(sp, backupPath(o.configPath), "http://"+cfg.Listen+"/proxy.pac", o.log); err != nil {
			a.systemNote = err.Error()
		} else {
			a.restore = restore
			proxy.SystemOn.Store(true)
		}
	}
	return a, nil
}

func backupPath(configPath string) string {
	return filepath.Join(filepath.Dir(configPath), "system-proxy-backup.json")
}

// Stop puts the system settings back first, then closes the server.
func (a *app) Stop() {
	if a.restore != nil {
		a.restore()
		a.proxy.SystemOn.Store(false)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	_ = a.srv.Shutdown(ctx)
}
