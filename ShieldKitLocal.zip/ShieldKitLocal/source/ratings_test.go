package main

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestRegistrableAndLookup(t *testing.T) {
	for in, want := range map[string]string{"shop.bol.com": "bol.com", "www.example.co.uk": "example.co.uk", "bol.com": "bol.com", "a.b.c.example.org": "example.org"} {
		if got := registrableDomain(in); got != want {
			t.Errorf("registrableDomain(%q) = %q, want %q", in, got, want)
		}
	}
	for _, h := range []string{"www.bol.com", "coolblue.be", "shop.example.co.uk", "github.com"} {
		if !shouldLookup(h) {
			t.Errorf("should look up %s", h)
		}
	}
	for _, h := range []string{"localhost", "192.168.1.5", "printer", "nas.local", "www.google.com", "www.google.be", "duckduckgo.com", "www.trustpilot.com", "foo.internal", "x.test", ""} {
		if shouldLookup(h) {
			t.Errorf("should not look up %q", h)
		}
	}
}

func ldPage(value, count any) string {
	b, _ := json.Marshal(map[string]any{"@type": "Organization", "name": "Shop", "aggregateRating": map[string]any{"@type": "AggregateRating", "ratingValue": value, "reviewCount": count}})
	return `<script type="application/ld+json">` + string(b) + `</script>`
}

func nextPage(bu map[string]any) string {
	b, _ := json.Marshal(map[string]any{"props": map[string]any{"pageProps": map[string]any{"businessUnit": bu}}})
	return `<script id="__NEXT_DATA__" type="application/json">` + string(b) + `</script>`
}

func TestParseTrustpilotFormats(t *testing.T) {
	p := parseTrustpilot(nextPage(map[string]any{"displayName": "Bol", "trustScore": 4.3, "numberOfReviews": 2041}))
	if p == nil || p.Score != 4.3 || *p.Reviews != 2041 || p.Name != "Bol" {
		t.Fatalf("NEXT_DATA: %+v", p)
	}
	p = parseTrustpilot(nextPage(map[string]any{"trustScore": 4.0, "numberOfReviews": map[string]any{"total": 55000}}))
	if p == nil || *p.Reviews != 55000 {
		t.Fatalf("nested total: %+v", p)
	}
	if p := parseTrustpilot(nextPage(map[string]any{"displayName": "X"})); p != nil {
		t.Errorf("a missing score must never become 0.0: %+v", p)
	}
	if p := parseTrustpilot(nextPage(map[string]any{"trustScore": 9.7})); p != nil {
		t.Error("out-of-range score accepted")
	}
	p = parseTrustpilot(ldPage("3.9", "812"))
	if p == nil || p.Score != 3.9 || *p.Reviews != 812 {
		t.Fatalf("json-ld: %+v", p)
	}
	p = parseTrustpilot(`<script>window.__D__={"businessUnit":{"displayName":"Bol","trustScore":4.1,"numberOfReviews":{"total":777}}}</script>`)
	if p == nil || p.Score != 4.1 || *p.Reviews != 777 || p.Name != "Bol" {
		t.Fatalf("regex fallback: %+v", p)
	}
	p = parseTrustpilot(`<div><span>TrustScore 4.5 out of 5</span><span>2k reviews</span></div>`)
	if p == nil || p.Score != 4.5 || *p.Reviews != 2000 {
		t.Fatalf("visible text: %+v", p)
	}
	p = parseTrustpilot(`<p>TrustScore 3,2 out of 5</p><p>All reviews (2,041)</p><p>9 reviews in the last 12 months</p>`)
	if p == nil || p.Score != 3.2 || *p.Reviews != 2041 {
		t.Fatalf("exact count: %+v", p)
	}
	p = parseTrustpilot(`<p>TrustScore 4.5 out of 5</p><p>2k reviews</p><p>All reviews (2.041)</p>`)
	if p == nil || *p.Reviews != 2041 {
		t.Fatalf("exact beats rounded: %+v", p)
	}
	for _, bad := range []string{"<html>Hello</html>", `<script id="__NEXT_DATA__">{oops</script>`, `<script type="application/ld+json">{"@type":"Review","reviewRating":{"ratingValue":1}}</script>`} {
		if parseTrustpilot(bad) != nil {
			t.Errorf("should not parse: %s", bad)
		}
	}
}

func TestParseStructuredAndOthers(t *testing.T) {
	if p := parseStructured(ldPage(8.6, 40) + ""); p != nil {
		// no bestRating given: 8.6 is out of range for a /5 scale and must be rejected, not clamped
		t.Errorf("8.6 without bestRating: %+v", p)
	}
	doc := `<script type="application/ld+json">{"aggregateRating":{"@type":"AggregateRating","ratingValue":8.6,"bestRating":10,"reviewCount":40}}</script>`
	if p := parseStructured(doc); p == nil || p.Score != 4.3 {
		t.Errorf("/10 scale: %+v", p)
	}
	doc = `<script type="application/ld+json">{"aggregateRating":{"@type":"AggregateRating","ratingValue":"90","bestRating":"100","ratingCount":"12"}}</script>`
	if p := parseStructured(doc); p == nil || p.Score != 4.5 || *p.Reviews != 12 {
		t.Errorf("/100 scale: %+v", p)
	}
	if p := parseStructured(`<meta itemprop="ratingValue" content="4.2"><meta itemprop="reviewCount" content="318">`); p == nil || *p.Reviews != 318 {
		t.Errorf("microdata content: %+v", p)
	}
	if p := parseStructured(`<span itemprop="ratingValue">3.7</span><span itemprop="reviewCount">50</span>`); p == nil || p.Score != 3.7 {
		t.Errorf("microdata text: %+v", p)
	}
	if parseStructured("<html>nothing</html>") != nil {
		t.Error("nothing -> nil")
	}
	if p := parseReviewsIO(`<p>Shop is rated 4.9 based on 585 reviews</p>`); p == nil || p.Score != 4.9 || *p.Reviews != 585 {
		t.Errorf("reviews.io text: %+v", p)
	}
	if p := parseReviewsIO(ldPage("3.1", "9") + "is rated 4.9 based on 585 reviews"); p == nil || p.Score != 3.1 {
		t.Errorf("structured data preferred: %+v", p)
	}
	if parseStructured(`<p>Overall rating 4.5 out of 5 from 3 reviews</p>`) != nil {
		t.Error("Sitejabber text must not be guessed")
	}
}

// ---------------------------------------------------------------- lookups against a fake website

func fakeSite(status int, body string, redirectTo string) (*httptest.Server, ServiceDef) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if redirectTo != "" && r.URL.Path != redirectTo {
			http.Redirect(w, r, redirectTo, http.StatusFound)
			return
		}
		w.WriteHeader(status)
		fmt.Fprint(w, body)
	}))
	svc := ServiceDef{ID: "fake", Name: "Fake", PathPrefix: "/reviews/", Parse: parseStructured,
		URLs: func(d string) []string { return []string{srv.URL + "/reviews/" + d} }}
	return srv, svc
}

func TestLookupServiceOutcomes(t *testing.T) {
	ctx := context.Background()
	check := func(status int, body, redirect string) RatingResult {
		srv, svc := fakeSite(status, body, redirect)
		defer srv.Close()
		return lookupService(ctx, srv.Client(), svc, "x.com")
	}
	if r := check(200, ldPage("4.0", "120"), ""); r.Status != "ok" || r.Score != 4 || *r.Reviews != 120 || !strings.HasSuffix(r.URL, "/reviews/x.com") {
		t.Errorf("ok: %+v", r)
	}
	if r := check(404, "", ""); r.Status != "none" {
		t.Errorf("404: %+v", r)
	}
	if r := check(200, "<p>Home</p>", "/"); r.Status != "none" {
		t.Errorf("redirect to home must be 'none': %+v", r)
	}
	for _, c := range []struct {
		status int
		reason string
		note   string
	}{{403, "blocked", "blocked, HTTP 403"}, {429, "blocked", "blocked, HTTP 429"}, {500, "http", "HTTP 500"}} {
		if r := check(c.status, "", ""); r.Status != "error" || r.Reason != c.reason || r.Note != c.note {
			t.Errorf("%d: %+v", c.status, r)
		}
	}
	if r := check(200, `<html><head><title>Just a moment...</title></head><body>Checking your browser</body></html>`, ""); r.Reason != "challenge" || r.Note != "bot check page" {
		t.Errorf("challenge: %+v", r)
	}
	if r := check(200, `<html><head><title>Acme reviews</title></head><body>new layout</body></html>`, ""); r.Reason != "unreadable" || !strings.Contains(r.Snippet, "Acme reviews") {
		t.Errorf("unreadable: %+v", r)
	}
	srv, svc := fakeSite(200, "", "")
	srv.Close()
	if r := lookupService(ctx, http.DefaultClient, svc, "x.com"); r.Reason != "offline" || r.Note != "no connection" {
		t.Errorf("offline: %+v", r)
	}
}

func TestLookupGoogle(t *testing.T) {
	var gotKey, gotMask, gotQuery string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		gotKey, gotMask = r.Header.Get("X-Goog-Api-Key"), r.Header.Get("X-Goog-FieldMask")
		var b struct{ TextQuery string }
		json.NewDecoder(r.Body).Decode(&b)
		gotQuery = b.TextQuery
		switch gotKey {
		case "BADKEY":
			http.Error(w, "no", 403)
		case "LIMITED":
			http.Error(w, "slow down", 429)
		default:
			fmt.Fprint(w, `{"places":[{"displayName":{"text":"Other"},"rating":2,"userRatingCount":3,"websiteUri":"https://other.com/"},{"displayName":{"text":"Bol"},"rating":4.14,"userRatingCount":1234,"websiteUri":"https://www.bol.com/nl/","googleMapsUri":"https://maps.google.com/?cid=1"}]}`)
		}
	}))
	defer srv.Close()
	saved := placesURL
	placesURL = srv.URL
	defer func() { placesURL = saved }()
	ctx := context.Background()
	r := lookupGoogle(ctx, srv.Client(), "bol.com", "KEY")
	if r.Status != "ok" || r.Score != 4.1 || *r.Reviews != 1234 || !strings.Contains(r.URL, "maps.google") {
		t.Fatalf("%+v", r)
	}
	if gotQuery != "bol.com" || !strings.Contains(gotMask, "rating") || gotKey != "KEY" {
		t.Errorf("request: query=%q mask=%q key=%q", gotQuery, gotMask, gotKey)
	}
	if lookupGoogle(ctx, srv.Client(), "nomatch.com", "KEY").Status != "none" {
		t.Error("no place with that website -> none")
	}
	if lookupGoogle(ctx, srv.Client(), "bol.com", "").Status != "nokey" || lookupGoogle(ctx, srv.Client(), "bol.com", "BADKEY").Status != "badkey" || lookupGoogle(ctx, srv.Client(), "bol.com", "LIMITED").Status != "error" {
		t.Error("key statuses")
	}
}

func ok(score float64, reviews int) RatingResult {
	return RatingResult{Status: "ok", Score: score, Reviews: &reviews}
}

func TestCombine(t *testing.T) {
	c := combineRatings([]RatingResult{ok(4.3, 2041)})
	if c.Score != 4.3 || c.Label != "Great" || c.Sources != 1 || c.Low {
		t.Errorf("one big source: %+v", c)
	}
	if c := combineRatings([]RatingResult{ok(5, 1)}); c.Score <= 3.5 || c.Score >= 4.2 || !c.Low {
		t.Errorf("one 5-star review: %+v", c)
	}
	c = combineRatings([]RatingResult{ok(4.3, 2041), ok(2.6, 11103)})
	if c.Score <= 2.6 || c.Score >= 4.3 || c.Reviews != 13144 || c.Sources != 2 {
		t.Errorf("disagreeing: %+v", c)
	}
	hi := combineRatings([]RatingResult{ok(4.5, 500)}).Score
	lo := combineRatings([]RatingResult{ok(4.5, 500), ok(2.0, 500)}).Score
	if lo >= hi {
		t.Errorf("a bad rating must lower it: %v %v", hi, lo)
	}
	if combineRatings(nil) != nil || combineRatings([]RatingResult{{Status: "none"}, {Status: "error"}}) != nil {
		t.Error("nothing rated -> nil")
	}
	if c := combineRatings([]RatingResult{{Status: "ok", Score: 4}}); c == nil || c.Score <= 3.5 {
		t.Errorf("unknown review count: %+v", c)
	}
	for score, want := range map[float64]string{4.7: "Excellent", 4.2: "Great", 3.6: "Good", 3.1: "Average", 2.4: "Poor", 1.2: "Bad"} {
		if ratingLabel(score) != want {
			t.Errorf("%v -> %s", score, ratingLabel(score))
		}
	}
}

func TestCheckSiteEndToEnd(t *testing.T) {
	calls := 0
	site := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		calls++
		switch {
		case strings.HasPrefix(r.URL.Path, "/tp/"):
			fmt.Fprint(w, nextPage(map[string]any{"trustScore": 4.3, "numberOfReviews": 2041}))
		case strings.HasPrefix(r.URL.Path, "/sj/"):
			fmt.Fprint(w, ldPage("2.6", "11103"))
		default:
			http.NotFound(w, r)
		}
	}))
	defer site.Close()
	rt := NewRatings(site.Client())
	rt.services = []ServiceDef{
		{"trustpilot", "Trustpilot", "/tp/", func(d string) []string { return []string{site.URL + "/tp/" + d} }, parseTrustpilot},
		{"sitejabber", "Sitejabber", "/sj/", func(d string) []string { return []string{site.URL + "/sj/" + d} }, parseStructured},
		{"reviewsio", "Reviews.io", "/rio/", func(d string) []string { return []string{site.URL + "/rio/" + d} }, parseReviewsIO},
	}
	res := rt.Check(context.Background(), "https://shop.bol.com", "") // a full host: only the registrable domain is looked up
	res = rt.Check(context.Background(), "shop.bol.com", "")
	if res.Domain != "bol.com" || len(res.Results) != 4 || res.Combined == nil || res.Combined.Sources != 2 {
		t.Fatalf("%+v", res)
	}
	if res.Results[2].Result.Status != "none" || res.Results[3].Result.Status != "nokey" {
		t.Errorf("statuses: %+v", res.Results)
	}
	before := calls
	rt.Check(context.Background(), "www.bol.com", "")
	if calls != before {
		t.Errorf("second check should come from the cache: %d vs %d", calls, before)
	}
	text := res.Describe()
	for _, want := range []string{"bol.com: ★", "Trustpilot  ★ 4.3 · 2041 reviews", "Reviews.io  not listed", "Google"} {
		if !strings.Contains(text, want) {
			t.Errorf("Describe missing %q:\n%s", want, text)
		}
	}
}
