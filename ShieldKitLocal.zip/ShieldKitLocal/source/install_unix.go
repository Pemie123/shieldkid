//go:build !windows

package main

import (
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"runtime"
	"strings"
)

const (
	pathStart = "# >>> shieldkid >>>"
	pathEnd   = "# <<< shieldkid <<<"
)

func platformInstallDir() (string, error) {
	home, err := os.UserHomeDir()
	if err != nil {
		return "", err
	}
	return filepath.Join(home, ".local", "bin"), nil
}

func onPath(dir string) bool {
	for _, p := range filepath.SplitList(os.Getenv("PATH")) {
		if filepath.Clean(p) == filepath.Clean(dir) {
			return true
		}
	}
	return false
}

// startupFiles are the files a terminal reads when it opens, for the user's shell.
func startupFiles(home string) []string {
	shell := os.Getenv("SHELL")
	var names []string
	switch {
	case strings.Contains(shell, "zsh"):
		names = []string{".zshrc"}
	case strings.Contains(shell, "bash"):
		names = []string{".bashrc"}
		if runtime.GOOS == "darwin" {
			names = []string{".bash_profile"}
		}
	default:
		names = []string{".profile"}
	}
	files := make([]string, 0, len(names))
	for _, n := range names {
		files = append(files, filepath.Join(home, n))
	}
	return files
}

func platformEnsureOnPath(dir string) (string, error) {
	if onPath(dir) {
		return dir + " is already on your PATH.", nil
	}
	home, err := os.UserHomeDir()
	if err != nil {
		return "", err
	}
	line := fmt.Sprintf("export PATH=%q:\"$PATH\"", dir)
	if dir == filepath.Join(home, ".local", "bin") {
		line = `export PATH="$HOME/.local/bin:$PATH"`
	}
	block := "\n" + pathStart + "\n" + line + "\n" + pathEnd + "\n"
	var edited []string
	for _, f := range startupFiles(home) {
		data, _ := os.ReadFile(f)
		if strings.Contains(string(data), pathStart) {
			edited = append(edited, f)
			continue
		}
		fh, err := os.OpenFile(f, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o644)
		if err != nil {
			return "", err
		}
		_, err = fh.WriteString(block)
		fh.Close()
		if err != nil {
			return "", err
		}
		edited = append(edited, f)
	}
	return "Added " + dir + " to your PATH in: " + strings.Join(edited, ", "), nil
}

var pathBlockRe = regexp.MustCompile(`(?s)\n?` + regexp.QuoteMeta(pathStart) + `.*?` + regexp.QuoteMeta(pathEnd) + `\n?`)

func platformRemoveFromPath(dir string) error {
	home, err := os.UserHomeDir()
	if err != nil {
		return err
	}
	for _, n := range []string{".profile", ".bashrc", ".bash_profile", ".zshrc"} {
		f := filepath.Join(home, n)
		data, err := os.ReadFile(f)
		if err != nil || !strings.Contains(string(data), pathStart) {
			continue
		}
		if err := os.WriteFile(f, []byte(pathBlockRe.ReplaceAllString(string(data), "\n")), 0o644); err != nil {
			return err
		}
	}
	return nil
}
