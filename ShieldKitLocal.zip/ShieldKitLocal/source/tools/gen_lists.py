#!/usr/bin/env python3
"""Builds lists/*.txt (one domain per line) from the ShieldKit browser extension's rule files.
Usage: python3 tools/gen_lists.py PATH/TO/shieldkit/rules
The browser extension matches URLs; this program only sees host names, so only whole-domain rules are used."""
import json, os, re, sys

src = sys.argv[1] if len(sys.argv) > 1 else '../shieldkit/rules'
out = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'lists')
os.makedirs(out, exist_ok=True)
DOMAIN = re.compile(r'^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$')

def request_domains(name):
    ds = set()
    for r in json.load(open(os.path.join(src, name))):
        if r['action']['type'] == 'block':
            ds.update(d.lower() for d in r['condition'].get('requestDomains', []))
    return {d for d in ds if DOMAIN.match(d)}

def adguard_domains():
    pure = re.compile(r'^\|\|([a-z0-9][a-z0-9.-]*\.[a-z]{2,})\^$')
    ds = set()
    for r in json.load(open(os.path.join(src, 'adguard.json'))):
        c = r['condition']
        if r['action']['type'] != 'block' or any(k in c for k in ('initiatorDomains', 'excludedInitiatorDomains', 'requestMethods', 'tabIds', 'excludedRequestDomains')):
            continue
        if 'resourceTypes' in c and len(c['resourceTypes']) < 10:    # only blocks some kinds of request: skip, would over-block
            continue
        m = pure.match(c.get('urlFilter') or '')
        if m and DOMAIN.match(m.group(1)):
            ds.add(m.group(1))
    return ds

lists = {
    'ads': request_domains('ads.json') | adguard_domains(),
    'trackers': request_domains('trackers.json'),
    'malware': request_domains('malware.json'),
}
for name, ds in lists.items():
    with open(os.path.join(out, name + '.txt'), 'w') as f:
        f.write('\n'.join(sorted(ds)) + '\n')
    print(f'{name}: {len(ds)} domains')
