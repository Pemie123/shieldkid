package main

import (
	"net/url"
	"path"
	"regexp"
	"strings"
)

var dangerousExt = map[string]bool{}
var archiveExt = map[string]bool{}

func init() {
	for _, e := range strings.Fields(`exe msi scr bat cmd com pif cpl dll vbs vbe jse wsf wsh ps1 psm1 hta lnk jar reg inf msix appx apk docm xlsm pptm vhd vhdx`) {
		dangerousExt[e] = true
	}
	for _, e := range strings.Fields(`zip rar 7z iso img dmg pkg gz tar`) {
		archiveExt[e] = true
	}
}

var doubleExt = regexp.MustCompile(`(?i)\.(pdf|docx?|xlsx?|pptx?|jpe?g|png|gif|txt|mp3|mp4|rtf)\.(exe|scr|bat|cmd|com|vbs|js|jse|msi|jar|ps1|lnk|hta|pif)$`)

// assessDownloadURL looks at a plain-HTTP address. HTTPS downloads cannot be inspected without decrypting them.
// Relaxed (default): disguised files, and programs sent over unencrypted HTTP.
// Strict: also every program or script and archives over HTTP.
func assessDownloadURL(u *url.URL, strict bool) []string {
	name := path.Base(u.Path)
	if name == "/" || name == "." {
		return nil
	}
	ext := ""
	if i := strings.LastIndexByte(name, '.'); i >= 0 && i < len(name)-1 {
		ext = strings.ToLower(name[i+1:])
	}
	dangerous := dangerousExt[ext]
	var reasons []string
	if doubleExt.MatchString(name) {
		reasons = append(reasons, "disguised as a document or image (double extension)")
	}
	if dangerous {
		reasons = append(reasons, "program sent over an insecure HTTP connection")
	}
	if strict && archiveExt[ext] {
		reasons = append(reasons, "archive sent over an insecure HTTP connection")
	}
	return reasons
}
