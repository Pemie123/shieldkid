//go:build windows

package main

import "syscall"

func newSysProxy() sysProxy { return windowsProxy{run: execRun, notify: notifyProxyChange} }

// notifyProxyChange asks Windows to tell running programs that the internet settings changed.
func notifyProxyChange() {
	proc := syscall.NewLazyDLL("wininet.dll").NewProc("InternetSetOptionW")
	proc.Call(0, 39, 0, 0) // INTERNET_OPTION_SETTINGS_CHANGED
	proc.Call(0, 37, 0, 0) // INTERNET_OPTION_REFRESH
}
