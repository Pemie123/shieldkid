package main

import (
	"context"
	"crypto/subtle"
	"embed"
	"encoding/json"
	"errors"
	"io/fs"
	"net"
	"net/http"
	"net/url"
	"strings"
	"time"
)

//go:embed web
var webFiles embed.FS

const version = "1.0.0"

// Panel is the control panel and its JSON API. It only answers requests addressed to the proxy itself.
type Panel struct {
	store   *Store
	proxy   *Proxy
	engine  *Engine
	mgr     *Manager
	ratings *Ratings
}

func NewPanel(store *Store, proxy *Proxy, engine *Engine, mgr *Manager, ratings *Ratings) *Panel {
	return &Panel{store: store, proxy: proxy, engine: engine, mgr: mgr, ratings: ratings}
}

func (pn *Panel) Handler() http.Handler {
	static, _ := fs.Sub(webFiles, "web")
	files := http.FileServer(http.FS(static))
	mux := http.NewServeMux()
	mux.Handle("GET /{$}", files)
	mux.Handle("GET /app.js", files)
	mux.Handle("GET /style.css", files)
	mux.HandleFunc("GET /proxy.pac", func(w http.ResponseWriter, r *http.Request) { pn.pac(w, false) })
	mux.HandleFunc("GET /proxy-strict.pac", func(w http.ResponseWriter, r *http.Request) { pn.pac(w, true) })
	mux.HandleFunc("GET /__shieldkit/allow", pn.allowLink)
	mux.HandleFunc("GET /api/state", pn.state)
	mux.HandleFunc("GET /api/log", pn.log)
	mux.HandleFunc("POST /api/settings", pn.settings)
	mux.HandleFunc("POST /api/allow", pn.allow)
	mux.HandleFunc("POST /api/servers", pn.servers)
	mux.HandleFunc("POST /api/connect", pn.connect)
	mux.HandleFunc("POST /api/disconnect", pn.disconnect)
	mux.HandleFunc("POST /api/retest", pn.retest)
	mux.HandleFunc("POST /api/bridge/load", pn.bridgeLoad)
	mux.HandleFunc("POST /api/bridge/clear", pn.bridgeClear)
	mux.HandleFunc("POST /api/check", pn.check)
	return pn.guard(mux)
}

// guard protects against web pages that try to control the program:
//   - the Host header must be this computer on our port (stops DNS-rebinding attacks);
//   - changes must be JSON with a custom header, which a web page cannot send to another origin without permission;
//   - if the browser says where the request came from, it must be us.
func (pn *Panel) guard(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if !pn.hostOK(r.Host) {
			http.Error(w, "ShieldKit Local only answers on its own address", http.StatusForbidden)
			return
		}
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			if r.Header.Get("X-ShieldKit") != "1" {
				http.Error(w, "missing X-ShieldKit header", http.StatusForbidden)
				return
			}
			if origin := r.Header.Get("Origin"); origin != "" {
				u, err := url.Parse(origin)
				if err != nil || !pn.hostOK(u.Host) {
					http.Error(w, "cross-origin request refused", http.StatusForbidden)
					return
				}
			}
			if ct := r.Header.Get("Content-Type"); !strings.HasPrefix(ct, "application/json") {
				http.Error(w, "expected application/json", http.StatusUnsupportedMediaType)
				return
			}
		}
		w.Header().Set("Cache-Control", "no-store")
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("Content-Security-Policy", "default-src 'self'; style-src 'self' 'unsafe-inline'; frame-ancestors 'none'")
		next.ServeHTTP(w, r)
	})
}

func (pn *Panel) hostOK(hostport string) bool {
	_, listenPort, err := net.SplitHostPort(pn.store.Get().Listen)
	if err != nil {
		return false
	}
	host, port, err := net.SplitHostPort(hostport)
	if err != nil {
		return false
	}
	h := strings.ToLower(strings.Trim(host, "[]"))
	return port == listenPort && (h == "127.0.0.1" || h == "localhost" || h == "::1")
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}

func fail400(w http.ResponseWriter, msg string) {
	writeJSON(w, http.StatusBadRequest, map[string]string{"error": msg})
}

func readJSON(w http.ResponseWriter, r *http.Request, v any) bool {
	r.Body = http.MaxBytesReader(w, r.Body, 1<<20)
	if err := json.NewDecoder(r.Body).Decode(v); err != nil {
		fail400(w, "bad request: "+err.Error())
		return false
	}
	return true
}

func (pn *Panel) pac(w http.ResponseWriter, strict bool) {
	w.Header().Set("Content-Type", "application/x-ns-proxy-autoconfig")
	_, _ = w.Write([]byte(pacScript(pn.store.Get().Listen, strict)))
}

// allowLink is the "Continue anyway" button of the phishing page. The secret token proves the click came from that page.
func (pn *Panel) allowLink(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()
	if subtle.ConstantTimeCompare([]byte(q.Get("token")), []byte(pn.proxy.token)) != 1 {
		http.Error(w, "invalid link", http.StatusForbidden)
		return
	}
	host := q.Get("host")
	next, err := url.Parse(q.Get("next"))
	if host == "" || err != nil || (next.Scheme != "http" && next.Scheme != "https") || normalizeHost(next.Hostname()) != normalizeHost(host) {
		http.Error(w, "invalid link", http.StatusBadRequest)
		return
	}
	pn.proxy.sess.Add(host)
	http.Redirect(w, r, next.String(), http.StatusSeeOther)
}

// ---------------------------------------------------------------- state

type pubServer struct {
	ID       string `json:"id"`
	Country  string `json:"country"`
	Name     string `json:"name"`
	Scheme   string `json:"scheme"`
	Host     string `json:"host"`
	Port     int    `json:"port"`
	HasLogin bool   `json:"hasLogin"`
	Bridge   bool   `json:"bridge"`
}

func (pn *Panel) state(w http.ResponseWriter, r *http.Request) {
	cfg := pn.store.Get()
	servers := make([]pubServer, 0, len(cfg.Servers))
	for _, s := range cfg.Servers {
		servers = append(servers, pubServer{s.ID, s.Country, s.Name, s.Scheme, s.Host, s.Port, s.Username != "", s.Bridge})
	}
	counts, _ := pn.proxy.stats.Snapshot()
	ads, trackers, malware := pn.engine.Counts()
	writeJSON(w, 200, map[string]any{
		"version": version, "listen": cfg.Listen, "pac": "http://" + cfg.Listen + "/proxy.pac", "pacStrict": "http://" + cfg.Listen + "/proxy-strict.pac",
		"settings": map[string]any{
			"enabled": cfg.Enabled, "ads": cfg.Ads, "trackers": cfg.Trackers, "malware": cfg.Malware, "phishing": cfg.Phishing,
			"downloads": cfg.Downloads, "downloadsStrict": cfg.DownloadsStrict, "safeSearch": cfg.SafeSearch, "youtube": cfg.YouTube,
			"upgradeHttp": cfg.UpgradeHTTP, "stripParams": cfg.StripParams, "privacyHeaders": cfg.PrivacyHeaders, "killSwitch": cfg.KillSwitch,
			"openBrowser": cfg.OpenBrowser, "bridgeApi": cfg.BridgeAPI, "bridgePort": cfg.BridgePort,
		},
		"hasGoogleKey": cfg.GoogleKey != "", "allow": cfg.Allow, "servers": servers, "active": cfg.Active,
		"connection": pn.mgr.Last(), "systemProxy": pn.proxy.SystemOn.Load(), "counts": counts, "countries": countryCodes,
		"lists": map[string]int{"ads": ads, "trackers": trackers, "malware": malware},
	})
}

func (pn *Panel) log(w http.ResponseWriter, r *http.Request) {
	counts, events := pn.proxy.stats.Snapshot()
	writeJSON(w, 200, map[string]any{"counts": counts, "events": events})
}

// ---------------------------------------------------------------- changes

func (pn *Panel) settings(w http.ResponseWriter, r *http.Request) {
	var in map[string]any
	if !readJSON(w, r, &in) {
		return
	}
	err := pn.store.Update(func(c *Config) error {
		bools := map[string]*bool{
			"enabled": &c.Enabled, "ads": &c.Ads, "trackers": &c.Trackers, "malware": &c.Malware, "phishing": &c.Phishing,
			"downloads": &c.Downloads, "downloadsStrict": &c.DownloadsStrict, "safeSearch": &c.SafeSearch, "upgradeHttp": &c.UpgradeHTTP,
			"stripParams": &c.StripParams, "privacyHeaders": &c.PrivacyHeaders, "killSwitch": &c.KillSwitch, "openBrowser": &c.OpenBrowser,
		}
		for k, v := range in {
			if dst, ok := bools[k]; ok {
				b, isBool := v.(bool)
				if !isBool {
					return errors.New(k + " must be true or false")
				}
				*dst = b
				continue
			}
			switch k {
			case "youtube":
				s, _ := v.(string)
				if s != "off" && s != "moderate" && s != "strict" {
					return errors.New("youtube must be off, moderate or strict")
				}
				c.YouTube = s
			case "googleKey":
				s, ok := v.(string)
				if !ok || len(s) > 200 || strings.ContainsAny(s, " \r\n\t") {
					return errors.New("that does not look like an API key")
				}
				c.GoogleKey = s
			case "bridgeApi":
				s, _ := v.(string)
				api, ok := validAPI(s)
				if !ok {
					return errors.New("the local client address must be on this computer, for example http://127.0.0.1:9090")
				}
				c.BridgeAPI = api
			case "bridgePort":
				f, ok := v.(float64)
				if !ok || f < 1 || f > 65535 || f != float64(int(f)) {
					return errors.New("the port must be a number from 1 to 65535")
				}
				c.BridgePort = int(f)
			default:
				return errors.New("unknown setting " + k)
			}
		}
		return nil
	})
	if err != nil {
		fail400(w, err.Error())
		return
	}
	writeJSON(w, 200, map[string]bool{"ok": true})
}

func (pn *Panel) allow(w http.ResponseWriter, r *http.Request) {
	var in struct{ Action, Host string }
	if !readJSON(w, r, &in) {
		return
	}
	host := normalizeHost(strings.TrimPrefix(strings.TrimPrefix(in.Host, "https://"), "http://"))
	if i := strings.IndexAny(host, "/:"); i >= 0 {
		host = host[:i]
	}
	if !hostRe.MatchString(host) || !strings.Contains(host, ".") {
		fail400(w, "enter a domain such as example.com")
		return
	}
	_ = pn.store.Update(func(c *Config) error {
		kept := c.Allow[:0:0]
		for _, a := range c.Allow {
			if normalizeHost(a) != host {
				kept = append(kept, a)
			}
		}
		if in.Action == "add" {
			kept = append(kept, host)
		}
		c.Allow = kept
		return nil
	})
	writeJSON(w, 200, map[string]bool{"ok": true})
}

func (pn *Panel) servers(w http.ResponseWriter, r *http.Request) {
	var in struct {
		Action string    `json:"action"`
		ID     string    `json:"id"`
		Text   string    `json:"text"`
		Server rawServer `json:"server"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	merge := func(list []Server) (added, updated int) {
		_ = pn.store.Update(func(c *Config) error {
			for _, s := range list {
				found := false
				for i := range c.Servers {
					if c.Servers[i].ID == s.ID {
						c.Servers[i], found = s, true
						updated++
					}
				}
				if !found {
					c.Servers = append(c.Servers, s)
					added++
				}
			}
			return nil
		})
		return
	}
	switch in.Action {
	case "add":
		s, err := validateServer(in.Server)
		if err != nil {
			fail400(w, err.Error())
			return
		}
		merge([]Server{s})
		writeJSON(w, 200, map[string]any{"ok": true})
	case "import":
		list, errs := parseServers(in.Text)
		added, updated := merge(list)
		writeJSON(w, 200, map[string]any{"ok": len(list) > 0, "added": added, "updated": updated, "errors": errs})
	case "remove":
		if pn.store.Get().Active == in.ID {
			pn.mgr.Disconnect()
		}
		_ = pn.store.Update(func(c *Config) error {
			kept := c.Servers[:0:0]
			for _, s := range c.Servers {
				if s.ID != in.ID {
					kept = append(kept, s)
				}
			}
			c.Servers = kept
			return nil
		})
		writeJSON(w, 200, map[string]bool{"ok": true})
	default:
		fail400(w, "unknown action")
	}
}

func (pn *Panel) connect(w http.ResponseWriter, r *http.Request) {
	var in struct{ ID string }
	if !readJSON(w, r, &in) {
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 90*time.Second)
	defer cancel()
	info, err := pn.mgr.Connect(ctx, in.ID)
	if err != nil {
		fail400(w, err.Error())
		return
	}
	writeJSON(w, 200, info)
}

func (pn *Panel) disconnect(w http.ResponseWriter, r *http.Request) {
	pn.mgr.Disconnect()
	writeJSON(w, 200, map[string]bool{"ok": true})
}

func (pn *Panel) retest(w http.ResponseWriter, r *http.Request) {
	ctx, cancel := context.WithTimeout(r.Context(), 30*time.Second)
	defer cancel()
	info, err := pn.mgr.Retest(ctx)
	if err != nil {
		fail400(w, err.Error())
		return
	}
	writeJSON(w, 200, info)
}

func (pn *Panel) bridgeLoad(w http.ResponseWriter, r *http.Request) {
	var in struct {
		API  string `json:"api"`
		Port int    `json:"port"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	cfg := pn.store.Get()
	if in.API == "" {
		in.API = cfg.BridgeAPI
	}
	if in.Port == 0 {
		in.Port = cfg.BridgePort
	}
	api, ok := validAPI(in.API)
	if !ok {
		fail400(w, "the local client address must be on this computer, for example http://127.0.0.1:9090")
		return
	}
	if in.Port < 1 || in.Port > 65535 {
		fail400(w, "the port must be a number from 1 to 65535")
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 10*time.Second)
	defer cancel()
	countries, err := bridgeCountries(ctx, api)
	if err != nil {
		fail400(w, err.Error())
		return
	}
	if s := cfg.activeServer(); s != nil && s.Bridge {
		pn.mgr.Disconnect()
	}
	_ = pn.store.Update(func(c *Config) error {
		kept := c.Servers[:0:0]
		for _, s := range c.Servers {
			if !s.Bridge {
				kept = append(kept, s)
			}
		}
		c.Servers = append(kept, bridgeServers(countries, in.Port)...)
		c.BridgeAPI, c.BridgePort = api, in.Port
		return nil
	})
	writeJSON(w, 200, map[string]any{"ok": true, "countries": len(countries)})
}

func (pn *Panel) bridgeClear(w http.ResponseWriter, r *http.Request) {
	if s := pn.store.Get().activeServer(); s != nil && s.Bridge {
		pn.mgr.Disconnect()
	}
	_ = pn.store.Update(func(c *Config) error {
		kept := c.Servers[:0:0]
		for _, s := range c.Servers {
			if !s.Bridge {
				kept = append(kept, s)
			}
		}
		c.Servers = kept
		return nil
	})
	writeJSON(w, 200, map[string]bool{"ok": true})
}

func (pn *Panel) check(w http.ResponseWriter, r *http.Request) {
	var in struct{ Domain string }
	if !readJSON(w, r, &in) {
		return
	}
	host := normalizeHost(strings.TrimPrefix(strings.TrimPrefix(in.Domain, "https://"), "http://"))
	if i := strings.IndexAny(host, "/:?#"); i >= 0 {
		host = host[:i]
	}
	if !hostRe.MatchString(host) || !strings.Contains(host, ".") {
		fail400(w, "enter a domain such as bol.com")
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 30*time.Second)
	defer cancel()
	writeJSON(w, 200, pn.ratings.Check(ctx, host, pn.store.Get().GoogleKey))
}
