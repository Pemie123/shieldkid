package main

import (
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"sync"
)

// Server is one place traffic can be sent through (an upstream proxy or a sing-box country group).
type Server struct {
	ID       string `json:"id"`
	Country  string `json:"country"`
	Name     string `json:"name"`
	Scheme   string `json:"scheme"` // https, http or socks5
	Host     string `json:"host"`
	Port     int    `json:"port"`
	Username string `json:"username,omitempty"`
	Password string `json:"password,omitempty"`
	Bridge   bool   `json:"bridge,omitempty"` // a country group of a local sing-box client
	Group    string `json:"group,omitempty"`
}

// Config is everything the user can change. It is saved as JSON and contains server passwords, so the file is private (0600).
type Config struct {
	Listen          string   `json:"listen"`
	Enabled         bool     `json:"enabled"`
	Ads             bool     `json:"ads"`
	Trackers        bool     `json:"trackers"`
	Malware         bool     `json:"malware"`
	Phishing        bool     `json:"phishing"`
	Downloads       bool     `json:"downloads"`
	DownloadsStrict bool     `json:"downloadsStrict"`
	SafeSearch      bool     `json:"safeSearch"`
	YouTube         string   `json:"youtube"` // off, moderate or strict
	UpgradeHTTP     bool     `json:"upgradeHttp"`
	StripParams     bool     `json:"stripParams"`
	PrivacyHeaders  bool     `json:"privacyHeaders"`
	KillSwitch      bool     `json:"killSwitch"`
	Allow           []string `json:"allow"`
	GoogleKey       string   `json:"googleKey,omitempty"`
	Servers         []Server `json:"servers"`
	Active          string   `json:"active"`
	BridgeAPI       string   `json:"bridgeApi"`
	BridgePort      int      `json:"bridgePort"`
	OpenBrowser     bool     `json:"openBrowser"`
}

// Hosts that are never filtered by default: operating-system updates and a few developer essentials.
var defaultAllow = []string{
	"windowsupdate.com", "microsoft.com", "windows.com", "apple.com", "icloud.com",
	"ubuntu.com", "debian.org", "github.com", "githubusercontent.com",
}

func DefaultConfig() Config {
	return Config{
		Listen: "127.0.0.1:8899", Enabled: true,
		Ads: true, Trackers: true, Malware: true, Phishing: true, Downloads: true,
		SafeSearch: true, YouTube: "moderate", PrivacyHeaders: true, KillSwitch: true,
		Allow:     append([]string(nil), defaultAllow...),
		BridgeAPI: "http://127.0.0.1:9090", BridgePort: 2080,
	}
}

func (c Config) clone() Config {
	c.Allow = append([]string(nil), c.Allow...)
	c.Servers = append([]Server(nil), c.Servers...)
	return c
}

func (c Config) activeServer() *Server {
	if c.Active == "" {
		return nil
	}
	for i := range c.Servers {
		if c.Servers[i].ID == c.Active {
			s := c.Servers[i]
			return &s
		}
	}
	return nil
}

// Store keeps the config in memory, saves every change, and tells the proxy to reload.
type Store struct {
	mu       sync.RWMutex
	cfg      Config
	path     string // empty = do not save (tests)
	onChange func()
}

func defaultConfigPath() string {
	dir, err := os.UserConfigDir()
	if err != nil {
		dir = "."
	}
	return filepath.Join(dir, "ShieldKitLocal", "config.json")
}

func LoadStore(path string) (*Store, error) {
	s := &Store{cfg: DefaultConfig(), path: path}
	if path == "" {
		return s, nil
	}
	data, err := os.ReadFile(path)
	if errors.Is(err, os.ErrNotExist) {
		return s, nil
	}
	if err != nil {
		return nil, err
	}
	if err := json.Unmarshal(data, &s.cfg); err != nil { // fields missing from an older file keep their defaults
		return nil, err
	}
	return s, nil
}

func (s *Store) Get() Config {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.cfg.clone()
}

func (s *Store) Update(fn func(*Config) error) error {
	s.mu.Lock()
	next := s.cfg.clone()
	if err := fn(&next); err != nil {
		s.mu.Unlock()
		return err
	}
	s.cfg = next
	err := s.saveLocked()
	cb := s.onChange
	s.mu.Unlock()
	if cb != nil {
		cb()
	}
	return err
}

func (s *Store) saveLocked() error {
	if s.path == "" {
		return nil
	}
	if err := os.MkdirAll(filepath.Dir(s.path), 0o700); err != nil {
		return err
	}
	data, err := json.MarshalIndent(s.cfg, "", "  ")
	if err != nil {
		return err
	}
	tmp := s.path + ".tmp"
	if err := os.WriteFile(tmp, data, 0o600); err != nil {
		return err
	}
	return os.Rename(tmp, s.path)
}
