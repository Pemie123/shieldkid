package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"strings"
)

type IPInfo struct {
	IP      string `json:"ip"`
	Country string `json:"country"`
	City    string `json:"city,omitempty"`
	Org     string `json:"org,omitempty"`
}

type ipProvider struct {
	URL   string
	parse func(map[string]any) (IPInfo, error)
}

func str(m map[string]any, k string) string { s, _ := m[k].(string); return s }

// Variable so tests can point it at local servers.
var ipProviders = []ipProvider{
	{"https://ipinfo.io/json", func(m map[string]any) (IPInfo, error) {
		return IPInfo{IP: str(m, "ip"), Country: str(m, "country"), City: str(m, "city"), Org: str(m, "org")}, nil
	}},
	{"https://ipwho.is/", func(m map[string]any) (IPInfo, error) {
		if ok, present := m["success"].(bool); present && !ok {
			return IPInfo{}, errors.New("lookup refused")
		}
		org := ""
		if c, ok := m["connection"].(map[string]any); ok {
			org = str(c, "isp")
		}
		return IPInfo{IP: str(m, "ip"), Country: str(m, "country_code"), City: str(m, "city"), Org: org}, nil
	}},
}

// lookupIP asks a public service which address (and country) it sees when the given client connects.
func lookupIP(ctx context.Context, client *http.Client) (IPInfo, error) {
	var last error
	for _, p := range ipProviders {
		req, _ := http.NewRequestWithContext(ctx, http.MethodGet, p.URL, nil)
		req.Header.Set("User-Agent", "ShieldKitLocal")
		resp, err := client.Do(req)
		if err != nil {
			last = err
			continue
		}
		var m map[string]any
		err = json.NewDecoder(resp.Body).Decode(&m)
		resp.Body.Close()
		if err == nil && resp.StatusCode/100 != 2 {
			err = fmt.Errorf("HTTP %d", resp.StatusCode)
		}
		if err != nil {
			last = err
			continue
		}
		info, err := p.parse(m)
		if err != nil || info.IP == "" {
			if err == nil {
				err = errors.New("no IP in the answer")
			}
			last = err
			continue
		}
		info.Country = strings.ToUpper(info.Country)
		return info, nil
	}
	if last == nil {
		last = errors.New("lookup failed")
	}
	return IPInfo{}, last
}

type Verdict struct {
	Level string `json:"level"` // ok, warn or fail
	Text  string `json:"text"`
}

func name(code string) string {
	if n, ok := countryNames[code]; ok {
		return n
	}
	return code
}

// judge compares your address before connecting (baseline) with the one seen through the server.
func judge(baseline, via *IPInfo, expected string) Verdict {
	switch {
	case via == nil:
		return Verdict{"fail", "No response through the server."}
	case baseline != nil && baseline.IP == via.IP:
		return Verdict{"fail", fmt.Sprintf("Your IP address did not change (%s), so traffic is not going through the server.", via.IP)}
	case via.Country == expected:
		return Verdict{"ok", "Verified: traffic exits in " + name(expected) + "."}
	}
	where := "an unknown place"
	if via.Country != "" {
		where = name(via.Country)
	}
	return Verdict{"warn", fmt.Sprintf("Your IP changed, but it geolocates to %s, not %s. IP databases sometimes disagree, or the server may not be where it claims.", where, name(expected))}
}
