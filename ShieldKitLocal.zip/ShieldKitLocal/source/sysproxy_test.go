package main

import (
	"errors"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
)

// ---------------------------------------------------------------- the safety logic, with a fake operating system

type fakeSys struct {
	name       string
	current    map[string]string
	applyErr   error
	forget     bool // pretends the system accepted the command but did not keep it (like gsettings without a desktop)
	captureErr error
	restoreErr error
	applied    []string
	restores   int
}

func newFake() *fakeSys { return &fakeSys{name: "fake", current: map[string]string{"pac": "original"}} }

func (f *fakeSys) Name() string { return f.name }
func (f *fakeSys) Capture() (map[string]string, error) {
	if f.captureErr != nil {
		return nil, f.captureErr
	}
	return map[string]string{"pac": f.current["pac"]}, nil
}
func (f *fakeSys) Apply(url string) error {
	f.applied = append(f.applied, url)
	if !f.forget {
		f.current["pac"] = url
	}
	return f.applyErr
}
func (f *fakeSys) Verify(url string) error {
	if f.current["pac"] != url {
		return errors.New("setting is " + f.current["pac"])
	}
	return nil
}
func (f *fakeSys) Restore(saved map[string]string) error {
	f.restores++
	if f.restoreErr != nil {
		return f.restoreErr
	}
	f.current["pac"] = saved["pac"]
	return nil
}

func quiet(string) {}

func TestActivateBacksUpAppliesAndRestores(t *testing.T) {
	sp, state := newFake(), filepath.Join(t.TempDir(), "backup.json")
	sawBackupBeforeApply := false
	orig := sp.applied
	_ = orig
	restore, err := activateSystemProxy(sp, state, "http://127.0.0.1:8899/proxy.pac", quiet)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(state); err == nil {
		sawBackupBeforeApply = true
	}
	if !sawBackupBeforeApply || sp.current["pac"] != "http://127.0.0.1:8899/proxy.pac" {
		t.Fatal("backup must exist and the setting must be applied")
	}
	if fi, _ := os.Stat(state); fi.Mode().Perm() != 0o600 {
		t.Errorf("backup permissions %v", fi.Mode().Perm())
	}
	restore()
	restore() // calling twice is harmless
	if sp.current["pac"] != "original" || sp.restores != 1 {
		t.Errorf("not restored: %v restores=%d", sp.current, sp.restores)
	}
	if _, err := os.Stat(state); err == nil {
		t.Error("backup must be removed after a clean restore")
	}
}

func TestBackupIsWrittenBeforeAnythingChanges(t *testing.T) {
	state := filepath.Join(t.TempDir(), "backup.json")
	sp := &orderSys{fakeSys: newFake(), state: state}
	if _, err := activateSystemProxy(sp, state, "u", quiet); err != nil {
		t.Fatal(err)
	}
	if !sp.backupExistedAtApply {
		t.Error("the backup must exist before Apply runs")
	}
}

type orderSys struct {
	*fakeSys
	state                string
	backupExistedAtApply bool
}

func (o *orderSys) Apply(u string) error {
	_, err := os.Stat(o.state)
	o.backupExistedAtApply = err == nil
	return o.fakeSys.Apply(u)
}

func TestFailedApplyLeavesNothingChanged(t *testing.T) {
	sp, state := newFake(), filepath.Join(t.TempDir(), "backup.json")
	sp.applyErr = errors.New("permission denied")
	if _, err := activateSystemProxy(sp, state, "u", quiet); err == nil {
		t.Fatal("expected an error")
	}
	if sp.current["pac"] != "original" {
		t.Errorf("half-applied change not undone: %v", sp.current)
	}
	if _, err := os.Stat(state); err == nil {
		t.Error("no backup should remain after a failed apply")
	}
}

func TestFailedCaptureChangesNothing(t *testing.T) {
	sp, state := newFake(), filepath.Join(t.TempDir(), "backup.json")
	sp.captureErr = errors.New("cannot read settings")
	if _, err := activateSystemProxy(sp, state, "u", quiet); err == nil || len(sp.applied) != 0 {
		t.Fatalf("must not apply when the current settings cannot be read: %v %v", err, sp.applied)
	}
}

func TestUnwritableBackupMeansNoChange(t *testing.T) {
	dir := t.TempDir()
	blocker := filepath.Join(dir, "file")
	os.WriteFile(blocker, []byte("x"), 0o600)
	sp := newFake()
	if _, err := activateSystemProxy(sp, filepath.Join(blocker, "backup.json"), "u", quiet); err == nil || len(sp.applied) != 0 {
		t.Fatalf("without a backup the settings must not be changed: %v %v", err, sp.applied)
	}
}

func TestCrashRecovery(t *testing.T) {
	sp, state := newFake(), filepath.Join(t.TempDir(), "backup.json")
	if _, err := activateSystemProxy(sp, state, "http://pac", quiet); err != nil { // run 1 starts...
		t.Fatal(err)
	}
	// ...and dies without restoring (kill -9, power cut). The system still points at our PAC, the backup is on disk.
	if sp.current["pac"] != "http://pac" {
		t.Fatal("setup")
	}
	var messages []string
	restore, err := activateSystemProxy(sp, state, "http://pac", func(m string) { messages = append(messages, m) }) // run 2
	if err != nil {
		t.Fatal(err)
	}
	if len(messages) == 1 && !strings.Contains(messages[0], "did not close cleanly") {
		t.Errorf("message: %v", messages)
	}
	restore()
	if sp.current["pac"] != "original" {
		t.Errorf("the user's ORIGINAL setting must come back, not our own address: %v", sp.current)
	}
}

func TestOffCommandRestoresBackup(t *testing.T) {
	sp, state := newFake(), filepath.Join(t.TempDir(), "backup.json")
	if ok, err := restoreBackup(sp, state); ok || err != nil {
		t.Errorf("nothing to restore: %v %v", ok, err)
	}
	activateSystemProxy(sp, state, "http://pac", quiet) // crash: never restored
	if ok, err := restoreBackup(sp, state); !ok || err != nil || sp.current["pac"] != "original" {
		t.Fatalf("%v %v %v", ok, err, sp.current)
	}
	if _, err := os.Stat(state); err == nil {
		t.Error("backup should be gone")
	}
}

func TestRestoreFailureKeepsBackupForLater(t *testing.T) {
	sp, state := newFake(), filepath.Join(t.TempDir(), "backup.json")
	activateSystemProxy(sp, state, "http://pac", quiet)
	sp.restoreErr = errors.New("busy")
	if ok, err := restoreBackup(sp, state); ok || err == nil {
		t.Fatal("expected an error")
	}
	if _, err := os.Stat(state); err != nil {
		t.Error("the backup must be kept when the restore failed, so `shieldkid off` can try again")
	}
	sp.restoreErr = nil
	if ok, _ := restoreBackup(sp, state); !ok || sp.current["pac"] != "original" {
		t.Error("second attempt should succeed")
	}
}

func TestBackupFromAnotherSystemIsIgnored(t *testing.T) {
	sp, state := newFake(), filepath.Join(t.TempDir(), "backup.json")
	writeState(state, sysState{Platform: "somewhere-else", Saved: map[string]string{"pac": "x"}})
	if ok, err := restoreBackup(sp, state); ok || err != nil || sp.restores != 0 {
		t.Error("a backup made for a different platform must not be applied")
	}
	os.WriteFile(state, []byte("not json"), 0o600)
	if ok, _ := restoreBackup(sp, state); ok {
		t.Error("garbage backup")
	}
}

// ---------------------------------------------------------------- the real commands, checked with a fake runner

type call struct{ name, args string }

func fakeRunner(replies map[string]string, fail map[string]error) (runner, *[]call) {
	var calls []call
	return func(name string, args ...string) (string, error) {
		joined := strings.Join(args, " ")
		calls = append(calls, call{name, joined})
		key := name + " " + joined
		for prefix, err := range fail {
			if strings.HasPrefix(key, prefix) {
				return replies[prefix], err
			}
		}
		for prefix, out := range replies {
			if strings.HasPrefix(key, prefix) {
				return out, nil
			}
		}
		return "", nil
	}, &calls
}

func TestWindowsCommands(t *testing.T) {
	const key = `HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings`
	notified := 0
	// value exists
	run, calls := fakeRunner(map[string]string{"reg query": "\r\nHKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings\r\n    AutoConfigURL    REG_SZ    http://corp.example/wpad.pac\r\n\r\n"}, nil)
	w := windowsProxy{run: run, notify: func() { notified++ }}
	saved, err := w.Capture()
	if err != nil || saved["had"] != "1" || saved["url"] != "http://corp.example/wpad.pac" {
		t.Fatalf("capture: %v %v", saved, err)
	}
	if (*calls)[0] != (call{"reg", "query " + key + " /v AutoConfigURL"}) {
		t.Errorf("query command: %+v", (*calls)[0])
	}
	if err := w.Apply("http://127.0.0.1:8899/proxy.pac"); err != nil || notified != 1 {
		t.Fatalf("apply: %v notified=%d", err, notified)
	}
	if (*calls)[1] != (call{"reg", "add " + key + " /v AutoConfigURL /t REG_SZ /d http://127.0.0.1:8899/proxy.pac /f"}) {
		t.Errorf("add command: %+v", (*calls)[1])
	}
	if err := w.Restore(saved); err != nil || notified != 2 {
		t.Fatalf("restore: %v", err)
	}
	if (*calls)[2] != (call{"reg", "add " + key + " /v AutoConfigURL /t REG_SZ /d http://corp.example/wpad.pac /f"}) {
		t.Errorf("restore must put the old value back: %+v", (*calls)[2])
	}

	// value did not exist: reg query exits 1; restore deletes it
	run, calls = fakeRunner(map[string]string{"reg query": "ERROR: The system was unable to find the specified registry key or value."}, map[string]error{"reg query": errors.New("exit status 1")})
	w = windowsProxy{run: run, notify: func() {}}
	saved, err = w.Capture()
	if err != nil || saved["had"] != "0" {
		t.Fatalf("absent value: %v %v", saved, err)
	}
	if err := w.Restore(saved); err != nil || (*calls)[len(*calls)-1] != (call{"reg", "delete " + key + " /v AutoConfigURL /f"}) {
		t.Errorf("restore of an absent value must delete ours: %+v %v", *calls, err)
	}
	// deleting a value that is already gone is not an error
	run, _ = fakeRunner(map[string]string{"reg delete": "ERROR: The system was unable to find the specified registry key or value."}, map[string]error{"reg delete": errors.New("exit status 1")})
	if err := (windowsProxy{run: run, notify: func() {}}).Restore(map[string]string{"had": "0"}); err != nil {
		t.Errorf("already deleted: %v", err)
	}
	// reg.exe missing / add refused
	run, _ = fakeRunner(nil, map[string]error{"reg query": exec.ErrNotFound})
	if _, err := (windowsProxy{run: run, notify: func() {}}).Capture(); err == nil {
		t.Error("a missing reg.exe must be an error, not 'no value'")
	}
	run, _ = fakeRunner(map[string]string{"reg add": "ERROR: Access is denied."}, map[string]error{"reg add": errors.New("exit status 1")})
	if err := (windowsProxy{run: run, notify: func() {}}).Apply("u"); err == nil || !strings.Contains(err.Error(), "Access is denied") {
		t.Errorf("apply failure: %v", err)
	}
}

const macServices = "An asterisk (*) denotes that a network service is disabled.\nWi-Fi\n*Thunderbolt Bridge\nUSB 10/100/1000 LAN\n"

func TestMacCommands(t *testing.T) {
	run, calls := fakeRunner(map[string]string{
		"networksetup -listallnetworkservices":              macServices,
		"networksetup -getautoproxyurl Wi-Fi":               "URL: (null)\nEnabled: No\n",
		"networksetup -getautoproxyurl USB 10/100/1000 LAN": "URL: http://corp.example/proxy.pac\nEnabled: Yes\n",
	}, nil)
	m := macProxy{run: run}
	saved, err := m.Capture()
	if err != nil || len(saved) != 2 || saved["Wi-Fi"] != "No\t" || saved["USB 10/100/1000 LAN"] != "Yes\thttp://corp.example/proxy.pac" {
		t.Fatalf("capture (disabled services must be skipped): %v %v", saved, err)
	}
	*calls = nil
	if err := m.Apply("http://127.0.0.1:8899/proxy.pac"); err != nil {
		t.Fatal(err)
	}
	want := []call{
		{"networksetup", "-listallnetworkservices"},
		{"networksetup", "-setautoproxyurl Wi-Fi http://127.0.0.1:8899/proxy.pac"}, {"networksetup", "-setautoproxystate Wi-Fi on"},
		{"networksetup", "-setautoproxyurl USB 10/100/1000 LAN http://127.0.0.1:8899/proxy.pac"}, {"networksetup", "-setautoproxystate USB 10/100/1000 LAN on"},
	}
	if len(*calls) != len(want) {
		t.Fatalf("calls: %+v", *calls)
	}
	for i := range want {
		if (*calls)[i] != want[i] {
			t.Errorf("call %d: %+v want %+v", i, (*calls)[i], want[i])
		}
	}
	*calls = nil
	if err := m.Restore(saved); err != nil {
		t.Fatal(err)
	}
	got := map[string]bool{}
	for _, c := range *calls {
		got[c.args] = true
	}
	for _, w := range []string{
		"-setautoproxystate Wi-Fi off",                                                                                    // was off with no address: just switch it off again
		"-setautoproxyurl USB 10/100/1000 LAN http://corp.example/proxy.pac", "-setautoproxystate USB 10/100/1000 LAN on", // the user's own script comes back
	} {
		if !got[w] {
			t.Errorf("restore missing %q in %+v", w, *calls)
		}
	}
	if got["-setautoproxyurl Wi-Fi http://127.0.0.1:8899/proxy.pac"] {
		t.Error("restore must never re-apply our address")
	}
	// permission problem: all services fail => error; one fails => still fine
	run, _ = fakeRunner(map[string]string{"networksetup -listallnetworkservices": macServices, "networksetup -setautoproxyurl": "You must be an administrator"}, map[string]error{"networksetup -setautoproxyurl": errors.New("exit status 14")})
	if err := (macProxy{run: run}).Apply("u"); err == nil || !strings.Contains(err.Error(), "administrator") {
		t.Errorf("all failing: %v", err)
	}
	run, _ = fakeRunner(map[string]string{"networksetup -listallnetworkservices": "An asterisk (*) denotes that a network service is disabled.\n"}, nil)
	if _, err := (macProxy{run: run}).Capture(); err == nil {
		t.Error("no active service must be an error")
	}
}

func TestGnomeCommands(t *testing.T) {
	run, calls := fakeRunner(map[string]string{
		"gsettings get org.gnome.system.proxy mode":           "'manual'\n",
		"gsettings get org.gnome.system.proxy autoconfig-url": "'http://old.example/p.pac'\n",
	}, nil)
	g := gnomeProxy{run: run}
	saved, err := g.Capture()
	if err != nil || saved["mode"] != "manual" || saved["url"] != "http://old.example/p.pac" {
		t.Fatalf("%v %v", saved, err)
	}
	*calls = nil
	if err := g.Apply("http://127.0.0.1:8899/proxy.pac"); err != nil {
		t.Fatal(err)
	}
	if len(*calls) != 2 || (*calls)[0] != (call{"gsettings", "set org.gnome.system.proxy autoconfig-url 'http://127.0.0.1:8899/proxy.pac'"}) || (*calls)[1] != (call{"gsettings", "set org.gnome.system.proxy mode 'auto'"}) {
		t.Errorf("apply: %+v", *calls)
	}
	*calls = nil
	g.Restore(saved)
	if len(*calls) != 2 || (*calls)[1] != (call{"gsettings", "set org.gnome.system.proxy mode 'manual'"}) || (*calls)[0].args != "set org.gnome.system.proxy autoconfig-url 'http://old.example/p.pac'" {
		t.Errorf("restore: %+v", *calls)
	}
	run, _ = fakeRunner(map[string]string{"gsettings": "No such schema"}, map[string]error{"gsettings": errors.New("exit status 1")})
	if _, err := (gnomeProxy{run: run}).Capture(); err == nil {
		t.Error("a missing schema (not GNOME) must be an error, so nothing is changed")
	}
}

func TestSettingThatIsNotKeptIsNotClaimed(t *testing.T) {
	sp, state := newFake(), filepath.Join(t.TempDir(), "backup.json")
	sp.forget = true // the command "succeeds" but the system does not keep the value
	_, err := activateSystemProxy(sp, state, "http://pac", quiet)
	if err == nil || !strings.Contains(err.Error(), "did not keep the change") {
		t.Fatalf("must not claim success: %v", err)
	}
	if _, e := os.Stat(state); e == nil {
		t.Error("no backup should remain")
	}
}

func TestVerifyWindows(t *testing.T) {
	const url = "http://127.0.0.1:8899/proxy.pac"
	good, _ := fakeRunner(map[string]string{"reg query": "    AutoConfigURL    REG_SZ    " + url + "\r\n"}, nil)
	if err := (windowsProxy{run: good, notify: func() {}}).Verify(url); err != nil {
		t.Errorf("good: %v", err)
	}
	other, _ := fakeRunner(map[string]string{"reg query": "    AutoConfigURL    REG_SZ    http://something.else/x.pac\r\n"}, nil)
	if err := (windowsProxy{run: other, notify: func() {}}).Verify(url); err == nil {
		t.Error("a different address must fail")
	}
	none, _ := fakeRunner(nil, map[string]error{"reg query": errors.New("exit status 1")})
	if err := (windowsProxy{run: none, notify: func() {}}).Verify(url); err == nil {
		t.Error("an absent value must fail")
	}
}

func TestVerifyMac(t *testing.T) {
	const url = "http://127.0.0.1:8899/proxy.pac"
	run, _ := fakeRunner(map[string]string{"networksetup -listallnetworkservices": macServices,
		"networksetup -getautoproxyurl Wi-Fi": "URL: " + url + "\nEnabled: Yes\n", "networksetup -getautoproxyurl USB 10/100/1000 LAN": "URL: (null)\nEnabled: No\n"}, nil)
	if err := (macProxy{run: run}).Verify(url); err != nil {
		t.Errorf("one service using it is enough: %v", err)
	}
	run, _ = fakeRunner(map[string]string{"networksetup -listallnetworkservices": macServices, "networksetup -getautoproxyurl": "URL: " + url + "\nEnabled: No\n"}, nil)
	if err := (macProxy{run: run}).Verify(url); err == nil {
		t.Error("an address that is set but not enabled must fail")
	}
}

func TestVerifyGnome(t *testing.T) {
	const url = "http://127.0.0.1:8899/proxy.pac"
	run, _ := fakeRunner(map[string]string{"gsettings get org.gnome.system.proxy mode": "'auto'\n", "gsettings get org.gnome.system.proxy autoconfig-url": "'" + url + "'\n"}, nil)
	if err := (gnomeProxy{run: run}).Verify(url); err != nil {
		t.Errorf("good: %v", err)
	}
	run, _ = fakeRunner(map[string]string{"gsettings get org.gnome.system.proxy mode": "'none'\n", "gsettings get org.gnome.system.proxy autoconfig-url": "''\n"}, nil)
	if err := (gnomeProxy{run: run}).Verify(url); err == nil || !strings.Contains(err.Error(), "none") {
		t.Errorf("setting that was not kept (gsettings without a desktop): %v", err)
	}
}
