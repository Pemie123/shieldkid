package main

import (
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"runtime"
)

func exeName() string {
	if runtime.GOOS == "windows" {
		return "shieldkid.exe"
	}
	return "shieldkid"
}

func copyExecutable(src, dst string) error {
	if err := os.MkdirAll(filepath.Dir(dst), 0o755); err != nil {
		return err
	}
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()
	tmp := dst + ".new"
	out, err := os.OpenFile(tmp, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o755)
	if err != nil {
		return err
	}
	if _, err := io.Copy(out, in); err != nil {
		out.Close()
		os.Remove(tmp)
		return err
	}
	if err := out.Close(); err != nil {
		return err
	}
	_ = os.Remove(dst) // Windows cannot rename over an existing file
	return os.Rename(tmp, dst)
}

func sameFile(a, b string) bool {
	x, err1 := os.Stat(a)
	y, err2 := os.Stat(b)
	return err1 == nil && err2 == nil && os.SameFile(x, y)
}

// runInstall copies this program to a per-user folder and puts that folder on the PATH, so that typing
// `shieldkid` works in any NEW terminal. No administrator rights are needed.
func runInstall(args []string) error {
	exe, err := os.Executable()
	if err != nil {
		return err
	}
	if resolved, err := filepath.EvalSymlinks(exe); err == nil {
		exe = resolved
	}
	dir, err := platformInstallDir()
	if err != nil {
		return err
	}
	dst := filepath.Join(dir, exeName())
	if sameFile(exe, dst) {
		fmt.Println("Already installed at", dst)
	} else {
		if err := copyExecutable(exe, dst); err != nil {
			return fmt.Errorf("cannot install to %s: %w", dst, err)
		}
		fmt.Println("Installed to", dst)
	}
	note, err := platformEnsureOnPath(dir)
	if err != nil {
		return fmt.Errorf("installed, but could not add %s to your PATH: %w\nAdd it yourself, or run the program by its full path", dir, err)
	}
	fmt.Println(note)
	fmt.Println("\nOpen a NEW terminal window and type:  shieldkid")
	return nil
}

func runUninstall(args []string) error {
	dir, err := platformInstallDir()
	if err != nil {
		return err
	}
	if err := platformRemoveFromPath(dir); err != nil {
		fmt.Println("Could not clean the PATH setting:", err)
	} else {
		fmt.Println("Removed ShieldKit from your PATH settings.")
	}
	dst := filepath.Join(dir, exeName())
	if err := os.Remove(dst); err != nil && !errors.Is(err, os.ErrNotExist) {
		fmt.Printf("Could not delete %s (%v). Delete it by hand after closing this window.\n", dst, err)
	} else if err == nil {
		fmt.Println("Deleted", dst)
	}
	fmt.Println("Your settings folder was left alone:", filepath.Dir(defaultConfigPath()))
	return nil
}
