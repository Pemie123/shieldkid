package main

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/url"
	"regexp"
	"strconv"
	"time"
)

// A local sing-box client speaks VLESS / VMess / Trojan / Shadowsocks. ShieldKit Local sends traffic to its SOCKS5
// port and uses its controller API to pick a country group ("country-BE").

type BridgeCountry struct {
	Code  string `json:"code"`
	Group string `json:"group"`
	Nodes int    `json:"nodes"`
}

var bridgeClient = &http.Client{Timeout: 4 * time.Second, Transport: &http.Transport{Proxy: nil}}
var groupRe = regexp.MustCompile(`^country-([A-Z]{2})$`)

// validAPI accepts only controller addresses on this computer, so nothing is ever sent to a remote machine.
func validAPI(s string) (string, bool) {
	u, err := url.Parse(s)
	if err != nil || u.Scheme != "http" || (u.Hostname() != "127.0.0.1" && u.Hostname() != "localhost") {
		return "", false
	}
	return u.Scheme + "://" + u.Host, true
}

func bridgeCountries(ctx context.Context, api string) ([]BridgeCountry, error) {
	req, _ := http.NewRequestWithContext(ctx, http.MethodGet, api+"/proxies", nil)
	resp, err := bridgeClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("cannot reach the local client at %s. Start it first", api)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("the local client answered with HTTP %d", resp.StatusCode)
	}
	var data struct {
		Proxies map[string]struct {
			All []string `json:"all"`
		} `json:"proxies"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&data); err != nil {
		return nil, errors.New("the local client sent an answer ShieldKit Local does not understand")
	}
	var out []BridgeCountry
	for name, p := range data.Proxies {
		if m := groupRe.FindStringSubmatch(name); m != nil && len(p.All) > 0 {
			if _, ok := countryNames[m[1]]; ok {
				out = append(out, BridgeCountry{Code: m[1], Group: name, Nodes: len(p.All)})
			}
		}
	}
	if len(out) == 0 {
		return nil, errors.New("the local client has no country groups. Create its config with tools/subscription_to_singbox.py (included with ShieldKit Local)")
	}
	sortCountries(out)
	return out, nil
}

func sortCountries(c []BridgeCountry) {
	for i := 1; i < len(c); i++ {
		for j := i; j > 0 && c[j].Code < c[j-1].Code; j-- {
			c[j], c[j-1] = c[j-1], c[j]
		}
	}
}

func bridgeSelect(ctx context.Context, api, group string) error {
	body, _ := json.Marshal(map[string]string{"name": group})
	req, _ := http.NewRequestWithContext(ctx, http.MethodPut, api+"/proxies/proxy", bytes.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	resp, err := bridgeClient.Do(req)
	if err != nil {
		return fmt.Errorf("cannot reach the local client at %s", api)
	}
	defer resp.Body.Close()
	if resp.StatusCode/100 != 2 {
		return fmt.Errorf("the local client refused %s (HTTP %d)", group, resp.StatusCode)
	}
	return nil
}

func bridgeServers(countries []BridgeCountry, port int) []Server {
	out := make([]Server, 0, len(countries))
	for _, c := range countries {
		out = append(out, Server{
			ID: "BRIDGE-" + c.Code, Country: c.Code, Scheme: "socks5", Host: "127.0.0.1", Port: port,
			Name: "Free server (" + strconv.Itoa(c.Nodes) + " available)", Bridge: true, Group: c.Group,
		})
	}
	return out
}
